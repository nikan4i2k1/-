/* OK personal-post extractor. Reads DOM only; no API, fetch, account data or clicks. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.OkPostParser = api;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  const CARD = '.feed, [data-feed-id], [id^="hook_Block_mediatopic_"]';
  const PAIR = '[data-l*="ownerUserId"], [data-l*="ownerGroupId"]';
  const RESERVED = /^(group|profile|feed|search|video|photo|help|dk|topic|statuses|settings)$/i;

  function personalURL(value) {
    try {
      const u = new URL(value, 'https://ok.ru');
      if (!/^https?:$/.test(u.protocol) || !/^(?:m\.|www\.)?ok\.ru$/i.test(u.hostname) || u.port || u.username || u.password) return null;
      const m = /^\/(profile\/\d+|[a-z\d_.-]+)\/statuses\/(\d+)\/?$/i.exec(u.pathname);
      if (!m || RESERVED.test(m[1])) return null;
      return `https://ok.ru/${m[1]}/statuses/${m[2]}`;
    } catch (_) { return null; }
  }

  function pair(value) {
    const tokens = String(value || '').split(',').map(s => s.trim());
    const get = key => { const i = tokens.indexOf(key); return i >= 0 && /^\d+$/.test(tokens[i + 1] || '') ? tokens[i + 1] : null; };
    const topic = get('topicId');
    const user = get('ownerUserId'), group = get('ownerGroupId');
    if (!topic || (!user && !group) || (user && group)) return null;
    return { topic, user, group };
  }

  function opener(value) {
    const m = /showTopicInLayerOnClick\([^,]*,[^,]*,\s*['"](\d+)['"]\s*,\s*['"](USER|GROUP_THEME|GROUP_TOPIC)['"]/.exec(String(value || ''));
    return m ? { topic: m[1], type: m[2] } : null;
  }

  function renderPair(value) {
    try {
      const r = JSON.parse(value);
      if (!r || r.entity !== 'CONTENT' || !['USER_CONTENT_CARD', 'GROUP_CONTENT_CARD'].includes(r.card)) return null;
      const id = value => {
        if (typeof value === 'number' && !Number.isSafeInteger(value)) return null;
        return /^(?:[1-9]\d*)$/.test(String(value)) ? String(value) : null;
      };
      const topic = id(r.entityId), owner = id(r.ownerId);
      if (!topic || !owner) return null;
      return r.card === 'USER_CONTENT_CARD' ? { topic, user: owner, group: null }
        : { topic, user: null, group: owner };
    } catch (_) { return null; }
  }

  // Descriptor boundary makes real browser observations usable as regression fixtures.
  function extractCard({ id = '', feedId = '', metadata = [], links = [], authors = [], openers = [], renderLogs = [] }) {
    const topic = /^hook_Block_mediatopic_(\d+)$/.exec(id)?.[1];
    const pairs = [...metadata.map(pair), ...renderLogs.map(renderPair)].filter(Boolean);
    const candidates = topic ? pairs.filter(p => p.topic === topic) : pairs;
    const identities = new Set(candidates.map(p => `${p.user ? 'user' : 'group'}:${p.user || p.group}:${p.topic}`));
    if (identities.size > 1) return { links: [], group: false, key: id || feedId || JSON.stringify(metadata) };
    const primary = candidates[0];
    if (primary?.group) return { links: [], group: true, key: `group:${primary.group}:${primary.topic}` };
    if (primary?.user) {
      const url = `https://ok.ru/profile/${primary.user}/statuses/${primary.topic}`;
      return { links: [url], group: false, key: url };
    }
    const urls = [...new Set(links.map(personalURL).filter(Boolean))]
      .filter(url => !topic || url.split('/').pop() === topic);
    // Unknown cards with several unrelated personal URLs need a primary identity, not a guess.
    let own = topic && urls.length === 1 ? urls : [];
    if (!own.length) {
      const actions = openers.map(opener).filter(Boolean).filter(p => !topic || p.topic === topic);
      const actionIds = new Set(actions.map(p => `${p.type}:${p.topic}`));
      const users = new Set(authors.map(href => {
        try {
          const u = new URL(href, 'https://ok.ru');
          return /^(?:www\.)?ok\.ru$/i.test(u.hostname) ? /^\/profile\/(\d+)\/?$/.exec(u.pathname)?.[1] : null;
        } catch (_) { return null; }
      }).filter(Boolean));
      // Public OK markup confirms the USER opener's third argument is a status ID.
      // Bind it only to one numeric author from this card's header, never to image IDs.
      if (actionIds.size === 1 && actions[0]?.type === 'USER' && users.size === 1)
        own = [`https://ok.ru/profile/${[...users][0]}/statuses/${actions[0].topic}`];
    }
    return { links: own, group: false, key: own[0] || id || feedId || JSON.stringify({ metadata, links }) };
  }

  function cardNodes(document) {
    document = document.querySelector?.('#hook_Loader_ContentSearchResultsLoader') || document;
    let cards = [...document.querySelectorAll(CARD)];
    if (!cards.length) cards = [...document.querySelectorAll('[data-l*="ownerUserId"][data-l*="topicId"], [data-l*="ownerGroupId"][data-l*="topicId"]')];
    const claims = new Map();
    const signature = c => {
      const topic = /^hook_Block_mediatopic_(\d+)$/.exec(c.id || '')?.[1];
      if (topic) return topic;
      const values = [c.getAttribute('data-l'), ...[...c.querySelectorAll(PAIR)]
        .filter(e => e.closest(CARD) === c).map(e => e.getAttribute('data-l'))];
      const pairs = values.map(pair).filter(Boolean);
      claims.set(c, pairs.length);
      const topics = new Set(pairs.map(p => p.topic));
      return topics.size === 1 ? [...topics][0] : null;
    };
    const signatures = new Map(cards.map(c => [c, signature(c)]));
    // A feed wrapper may contain the real card. Keeping only the outer wrapper
    // while rejecting all inner-owned attributes made 49 wrappers produce zero links.
    cards = cards.filter(c => signatures.get(c) || claims.get(c) || !c.querySelectorAll(CARD).length);
    let boundaries = new Set(cards);
    cards = cards.filter(c => {
      for (let a = c.parentElement; a; a = a.parentElement) {
        if (boundaries.has(a)) return !signatures.get(c) || signatures.get(a) !== signatures.get(c);
      }
      return true;
    });
    boundaries = new Set(cards);
    const nearest = e => {
      for (let n = e; n; n = n.parentElement) if (boundaries.has(n)) return n;
      return null;
    };
    return { cards: cards.filter(c => !nearest(c.parentElement)), nearest };
  }

  function descriptor(c, nearest) {
    const owned = e => { const root = nearest(e); return !root || root === c; };
    const headers = [...c.querySelectorAll('.feed_top, .feed_author, .feed_ava, .feed-user-avatar, .feed-header')].filter(owned);
    // Authenticated content-search cards expose owner/entity IDs on the surrounding
    // feed-w wrapper, not on the inner .feed. Do not borrow a different parent post.
    const renderLogs = [];
    for (let e = c; e; e = e.parentElement) {
      if (e !== c && nearest(e) && nearest(e) !== c) break;
      if (e.matches('.feed-w') && e.getAttribute('data-render-log')) {
        renderLogs.push(e.getAttribute('data-render-log')); break;
      }
    }
    return { id: c.id, feedId: c.getAttribute('data-feed-id') || '',
      metadata: [c.getAttribute('data-l'), ...[...c.querySelectorAll(PAIR)].filter(owned).map(e => e.getAttribute('data-l'))].filter(Boolean),
      links: [...c.querySelectorAll('a[href]')].filter(owned).map(a => a.getAttribute('href')),
      authors: headers.flatMap(h => [...(h.matches('a[href]') ? [h] : []), ...h.querySelectorAll('a[href]')]
        .filter(owned).map(a => a.getAttribute('href'))),
      openers: [...c.querySelectorAll('[onclick]')].filter(owned).map(e => e.getAttribute('onclick')), renderLogs };
  }

  function scan(document) {
    const { cards, nearest } = cardNodes(document);
    const rows = cards.map(c => extractCard(descriptor(c, nearest)));
    return { cards: cards.length, groups: rows.filter(r => r.group).length,
      unresolved: rows.filter(r => !r.group && !r.links.length).length,
      links: [...new Set(rows.flatMap(r => r.links))], rows };
  }

  function diagnose(document) {
    const { cards, nearest } = cardNodes(document);
    const summary = scan(document);
    const href = value => {
      try {
        const u = new URL(value, 'https://ok.ru');
        if (!/^(?:m\.|www\.)?ok\.ru$/i.test(u.hostname)) return '(external)';
        const ids = [...u.searchParams].filter(([k, v]) => /^(?:st\.)?(?:friendId|userId|ownerId|statusId|topicId|groupId)$/i.test(k) && /^\d+$/.test(v));
        return u.pathname + (ids.length ? '?' + new URLSearchParams(ids) : '');
      } catch (_) { return '(invalid)'; }
    };
    const samples = [];
    for (const c of cards) {
      const d = descriptor(c, nearest), result = extractCard(d);
      if (result.links.length || result.group) continue;
      const nodes = [c, ...c.querySelectorAll('[data-l], [data-tid], [onclick], a[href]')].slice(0, 35);
      samples.push({ id: d.id, feedId: d.feedId,
        metadata: d.metadata.map(pair).filter(Boolean), renderClaims: d.renderLogs.map(renderPair).filter(Boolean),
        links: d.links.slice(0, 12).map(href), authors: d.authors.map(href),
        openers: d.openers.map(opener).filter(Boolean).slice(0, 8),
        structure: nodes.map(e => ({ tag: e.tagName || '', id: e.id || '', class: e.getAttribute('class') || '',
          attributeNames: [...(e.attributes || [])].map(a => a.name),
          dataLKeys: String(e.getAttribute('data-l') || '').split(',')
            .filter(s => /^(?:ownerUserId|ownerGroupId|topicId|userId|groupId|friendId|statusId|ownerId|entityId|entityType|type|t|mB|gA)$/.test(s)),
          dataTid: /^\d+$/.test(e.getAttribute('data-tid') || '') ? e.getAttribute('data-tid') : null })) });
      if (samples.length === 5) break;
    }
    return { version: '1.4.2', cards: summary.cards, recognized: summary.links.length,
      groups: summary.groups, unresolved: summary.unresolved, samples };
  }

  async function collect(options) {
    const { document, scroll, sleep, stop = () => false, state = () => null,
      loading = () => false, progress = () => {}, excluded = new Set() } = options;
    const limit = Math.max(1, Math.min(10000, Number(options.limit) || 300));
    const maxIdle = options.maxIdle ?? 12, maxRounds = options.maxRounds ?? 1800;
    const links = new Set(), seen = new Set(), skipped = new Set(), groups = new Set(), unresolved = new Set();
    let idle = 0, rounds = 0, reason = 'timeout', lastScan;
    const snapshot = () => ({ links: [...links], reason, rounds, scanned: seen.size,
      groupsSkipped: groups.size, unresolved: unresolved.size, dbSkipped: skipped.size, cards: lastScan?.cards || 0 });
    while (rounds <= maxRounds) {
      lastScan = scan(typeof document === 'function' ? document() : document);
      let fresh = 0;
      for (const row of lastScan.rows) {
        if (!seen.has(row.key)) { seen.add(row.key); fresh++; }
        if (row.group) groups.add(row.key);
        else if (!row.links.length) unresolved.add(row.key);
      }
      for (const url of lastScan.links) {
        if (excluded.has(url)) { skipped.add(url); continue; }
        if (links.size < limit) links.add(url);
      }
      progress(snapshot());
      if (stop()) { reason = 'stopped'; break; }
      if (links.size >= limit) { reason = 'limit'; break; }
      const status = state();
      if (status) { reason = status; break; }
      idle = fresh || loading() ? 0 : idle + 1;
      if (idle >= maxIdle) { reason = 'idle'; break; }
      if (rounds >= maxRounds) break;
      await scroll();
      await sleep(options.delay ?? 1000);
      rounds++;
    }
    return snapshot();
  }
  return { version: '1.4.2', personalURL, extractCard, scan, collect, diagnose };
});
