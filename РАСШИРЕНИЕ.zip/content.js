/* ============================================================
   VK Parser & Uploader — контентный скрипт (изолированный мир)
   Живёт на вкладке ВК и выполняет задачи по команде из попапа:
     - parse:  парсер ссылок друзей (автопрокрутка)
     - upload: автозаливка ссылок в форму на странице события
   Не слетает в фоне: таймеры через Web Worker + stealth + keep-awake.
   ============================================================ */

/* ---------- состояние / статус ---------- */
let STOP = false;
let STATUS = { running: false, mode: null, phase: 'idle', line: '', ok: 0, fail: 0, total: 0, skipped: 0, limitSkipped: 0, firstSuccessPerNetwork: false, error: null };
let hideTimer = null;

/* статус пишется в два ключа: парсеры (parse/search) и заливка (upload)
   могут работать одновременно на разных вкладках и не затирают друг друга */
const statusKey = () => STATUS.mode === 'upload' ? 'vkExtStatusUpload'
  : STATUS.mode === 'okSearch' ? 'okParseStatus'
  : STATUS.mode === 'screens' ? 'vkExtStatusScreens'
  : 'vkExtStatus';
const setStatus = patch => {
  STATUS = { ...STATUS, ts: Date.now(), ...patch };
  try { chrome.storage.local.set({ [statusKey()]: STATUS }); } catch (e) {}
  if (STATUS.running && STATUS.mode !== 'okSearch') stealthOn(); // ОК читает DOM без MAIN-перехватов
  renderPanel();
};

const statusCounts = st => `успешно: ${st.ok || 0}` +
  (st.mode === 'upload' ? ` | уже загружено: ${st.skipped || 0}` : '') +
  (st.mode === 'upload' && st.firstSuccessPerNetwork ? ` | по лимиту: ${st.limitSkipped || 0}` : '') +
  ` | ошибок: ${st.fail || 0} | всего: ${st.total || 0}`;

/* ---------- плавающая панель прогресса ---------- */
let panel = null;
const renderPanel = () => {
  const show = STATUS.running || STATUS.phase === 'done';
  if (!show) { if (panel) { panel.remove(); panel = null; } return; }
  if (!panel) {
    panel = document.createElement('div');
    panel.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#1c1c1e;color:#eee;' +
      'font:12px/1.5 Segoe UI,Arial,sans-serif;padding:10px 12px;border-radius:10px;' +
      'box-shadow:0 4px 16px rgba(0,0,0,.4);min-width:230px;max-width:340px';
    panel.innerHTML =
      '<div class="p-title" style="font-weight:600;margin-bottom:4px"></div>' +
      '<div class="p-line" style="white-space:pre-wrap;word-break:break-all;max-height:90px;overflow:auto"></div>' +
      '<div class="p-stats" style="margin-top:4px;opacity:.85"></div>' +
      '<button class="p-stop" style="margin-top:8px;background:#e64646;color:#fff;border:0;border-radius:6px;' +
      'padding:4px 10px;cursor:pointer">Стоп</button>';
    document.documentElement.appendChild(panel);
    panel.querySelector('.p-stop').onclick = () => { STOP = true; window.__stop = true; stopLikeCursor(); screenStopClick(); };
  }
  panel.querySelector('.p-title').textContent =
    STATUS.mode === 'parse' ? 'VK Parser — парсер друзей'
    : STATUS.mode === 'search' ? 'VK Parser — посты из поиска'
    : STATUS.mode === 'okSearch' ? 'OK Parser — посты людей'
    : STATUS.mode === 'like' ? 'VK Liker — автолайк на стене'
    : STATUS.mode === 'screens' ? 'VK Screenshots — загрузка скринов'
    : 'VK Uploader — заливка ссылок';
  panel.querySelector('.p-line').textContent = STATUS.line || '';
  panel.querySelector('.p-stats').textContent =
    STATUS.total ? statusCounts(STATUS) : '';
};

const schedulePanelHide = () => {
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => { if (!STATUS.running) { STATUS.phase = 'idle'; renderPanel(); } }, 15000);
};

/* ---------- сон через Web Worker (не троттлится в фоновой вкладке) ---------- */
let worker = null, wid = 0;
const waiters = new Map();
const sleep = ms => {
  if (worker === null) {
    try {
      const blob = new Blob(['onmessage=e=>{const{id,ms}=e.data;setTimeout(()=>postMessage(id),ms)}'],
        { type: 'text/javascript' });
      worker = new Worker(URL.createObjectURL(blob));
      worker.onmessage = e => { const r = waiters.get(e.data); if (r) { waiters.delete(e.data); r(); } };
    } catch (e) { worker = false; }
  }
  if (worker === false) return new Promise(r => setTimeout(r, ms));
  return new Promise(res => { const id = ++wid; waiters.set(id, res); worker.postMessage({ id, ms }); });
};

/* ---------- stealth (через MAIN-мир) ---------- */
const stealthOn  = () => { try { window.dispatchEvent(new CustomEvent('vkext-stealth-on'));  } catch (e) {} };
const stealthOff = () => { try { window.dispatchEvent(new CustomEvent('vkext-stealth-off')); } catch (e) {} };

/* сетевые события страницы: stealth.js (MAIN мир) перехватывает fetch/XHR и
   шлёт vkext-net. Нужны для честного подтверждения POST'а при заливке. */
const netEvents = [];
window.addEventListener('vkext-net', e => {
  const d = e.detail || {};
  netEvents.push({ t: +d.t || Date.now(), method: String(d.method || 'GET'), url: String(d.url || ''), ok: !!d.ok, status: Number(d.status) || 0 });
  if (netEvents.length > 100) netEvents.shift();
});

/* ---------- keep-awake: тихий звук, чтобы вкладку не замораживали ---------- */
let audio = null;
const keepAwakeOn = () => {
  if (audio) return;
  try {
    audio = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audio.createOscillator(), g = audio.createGain();
    g.gain.value = 0.0001; osc.connect(g); g.connect(audio.destination); osc.start();
    if (audio.state === 'suspended') audio.resume();
  } catch (e) { audio = null; }
};
const keepAwakeOff = () => { try { audio && audio.close(); } catch (e) {} audio = null; };

/* ---------- общие хелперы ---------- */
const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
const visible = e => e.offsetParent !== null || e.getClientRects().length;
const POLL = 150;

const waitFor = async (fn, timeout = 20000) => {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    if (STOP) return null;
    const v = fn(); if (v) return v;
    await sleep(POLL);
  }
  return null;
};

const download = (name, data) => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([data], { type: 'text/plain;charset=utf-8' }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
};

/* ============================================================
   БАЗА УЖЕ ЗАЛИТЫХ ССЫЛОК (общая для всех событий)
   Хранится в chrome.storage.local['vkUploadedDb'].
   Парсер пропускает такие ссылки; база включает новые успешные,
   уже видимые в событии и подтверждённые сайтом дубли.
   Скачать / очистить — кнопки в попапе.
   ============================================================ */
const DB_KEY = 'vkUploadedDb';
const UPLOAD_PROGRESS_PREFIX = 'uploadDone_';
/* eventId = null — сбросить прогресс всех событий (и старый формат в localStorage) */
const resetUploadProgress = async (eventId = null) => {
  try {
    Object.keys(localStorage)
      .filter(k => k === 'uploader_progress' || (eventId ? k.startsWith('uploader_done_' + eventId + '_') : k.startsWith('uploader_done_')))
      .forEach(k => localStorage.removeItem(k));
  } catch (e) {}
  try {
    if (eventId) await chrome.storage.local.remove(UPLOAD_PROGRESS_PREFIX + eventId);
    else {
      const all = await chrome.storage.local.get(null);
      const keys = Object.keys(all || {}).filter(k => k.startsWith(UPLOAD_PROGRESS_PREFIX));
      if (keys.length) await chrome.storage.local.remove(keys);
    }
  } catch (e) {}
};
const dbNorm = u => String(u || '').trim().toLowerCase()
  .replace(/^http:/, 'https:').replace(/[?#].*$/, '').replace(/\/+$/, '');
let DB = null;
const dbLoad = () => new Promise(res => {
  try { chrome.storage.local.get(DB_KEY, o => { DB = new Set((o && o[DB_KEY]) || []); res(DB); }); }
  catch (e) { DB = new Set(); res(DB); }
});
const dbSave = () => { try { chrome.storage.local.set({ [DB_KEY]: [...DB] }); } catch (e) {} };
const dbHas = u => !!DB && DB.has(dbNorm(u));
const dbAdd = u => {
  if (!DB) DB = new Set();
  const k = dbNorm(u);
  if (!k || DB.has(k)) return false;
  DB.add(k); dbSave(); return true;
};

/* ============================================================
   ЗАДАЧА 1: ПАРСЕР ДРУЗЕЙ
   ============================================================ */
const BAD = /^(write\d*|call\d*|im|id0|account|feed|friends|groups|clubs?|club\d+|public\d+|event\d+|photos?|videos?|audios?|apps|market|away|search|settings|support|dev|blog|press|ads|about|help|terms|privacy|legal|donut|vkpay|music|edu|team|jobs|widgets|share|reg|restore|login|logout|likes|fave|stories|mail|business|services|wall|topic|note|albums?)$/i;

const slugOf = a => {
  const h = (a.getAttribute('href') || '').replace(/^https?:\/\/(m\.)?vk\.(com|ru)/i, '');
  const m = /^\/([A-Za-z][A-Za-z0-9_.]{1,31}|id\d+)(?:[?#].*)?$/.exec(h);
  return m && !BAD.test(m[1]) ? m[1] : null;
};

const cardOf = w => {
  let n = w;
  while (n.parentElement && n.parentElement !== document.body) {
    if (n.parentElement.querySelectorAll('a[href^="/write"]').length > 1) return n;
    n = n.parentElement;
  }
  return n;
};

/* Скролл-контейнер ищем один раз: от якорного элемента вверх по родителям.
   Полный обход DOM — только запасной вариант, и его результат тоже кешируется. */
const makeScrollers = anchorFn => {
  let cache = [];
  const ok = e => e && e.isConnected && e.clientHeight > 200 && e.scrollHeight > e.clientHeight + 150;
  return () => {
    if (cache.length && cache.every(ok)) return cache;
    cache = [];
    const anchor = anchorFn && anchorFn();
    for (let e = anchor && anchor.parentElement; e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
      if (ok(e) && /auto|scroll/.test(getComputedStyle(e).overflowY)) { cache = [e]; break; }
    }
    if (!cache.length) cache = [...document.querySelectorAll('*')].filter(ok);
    return cache;
  };
};

/* Ждём подгрузку: выходим, как только DOM затих после изменений, но не дольше max. */
const watchDom = (root, onNode) => {
  let changedAt = 0;
  const mo = typeof MutationObserver === 'function' ? new MutationObserver(list => {
    changedAt = Date.now();
    if (onNode) for (const m of list) onNode(m.target);
  }) : null;
  try { mo && mo.observe(root || document.body, { childList: true, subtree: true }); } catch (e) {}
  const settle = async (max = 700, quiet = 150) => {
    const t0 = Date.now(); changedAt = 0;
    while (Date.now() - t0 < max) {
      await sleep(100);
      if (changedAt && Date.now() - changedAt >= quiet) return true;
    }
    return !!changedAt;
  };
  return { settle, close: () => { try { mo && mo.disconnect(); } catch (e) {} }, get active() { return !!mo; } };
};

const taskParse = async limit => {
  const store = new Map(); // id -> {slug, name}

  const scan = () => {
    let added = 0;
    for (const w of document.querySelectorAll('a[href^="/write"]')) {
      if (store.size >= limit) break;
      const m = (w.getAttribute('href') || '').match(/^\/write(\d+)/);
      if (!m) continue;
      const id = m[1];
      if (store.has(id)) continue;
      const card = cardOf(w);
      const nameLine = (card.innerText || '').split('\n')[0].trim();
      const cands = [...card.querySelectorAll('a[href]')].map(a => ({ a, slug: slugOf(a) })).filter(x => x.slug);
      const exact  = cands.find(x => x.slug.toLowerCase() === 'id' + id);
      const byName = cands.find(x => norm(x.a.innerText) === norm(nameLine) && norm(nameLine).length > 2);
      const byAva  = cands.find(x => x.a.querySelector('img'));
      store.set(id, { slug: exact?.slug || byName?.slug || byAva?.slug || null, name: nameLine });
      added++;
    }
    return added;
  };

  const scrollers = makeScrollers(() => document.querySelector('a[href^="/write"]'));
  const dom = watchDom(document.body);

  scan();
  let idle = 0;
  try {
    while (store.size < limit && idle < 6 && !STOP) {
      window.scrollTo(0, document.body.scrollHeight);
      for (const s of scrollers()) s.scrollTop = s.scrollHeight;
      if (dom.active) await dom.settle(1200); else await sleep(600);
      const added = scan();
      setStatus({ total: limit, ok: store.size, line: `друзей: ${store.size} / ${limit} (+${added})` });
      if (added === 0) idle++; else idle = 0;
    }
  } finally { dom.close(); }
  if (STOP && !store.size) return { line: '⏹ остановлено' };
  const stopped = STOP;

  // один и тот же адрес у разных ID = паблик из статуса -> заменяем на id-ссылку
  const cnt = {};
  for (const v of store.values()) if (v.slug) cnt[v.slug] = (cnt[v.slug] || 0) + 1;

  const entries = [...store.entries()].slice(0, limit).map(([id, v]) => {
    const ok = v.slug && cnt[v.slug] === 1 && /^([A-Za-z][A-Za-z0-9_.]{1,31}|id\d+)$/.test(v.slug);
    const slug = ok ? v.slug : 'id' + id;
    return { id, name: v.name, url: 'https://vk.ru/' + slug };
  }).filter(e => /^https:\/\/vk\.ru\/([A-Za-z][A-Za-z0-9_.]{1,31}|id\d+)$/.test(e.url));

  const links = entries.map(e => e.url).sort();
  if (!links.length) {
    return { line: 'Не найдено кнопок «Написать сообщение» — открой vk.ru/friends?section=all' };
  }

  await chrome.storage.local.set({ vkFriendsResult: { links, ts: Date.now() } });
  try { await navigator.clipboard.writeText(links.join('\n')); } catch (e) {}

  const line = (stopped ? `⏹ остановлено — сохранено ${links.length} ссылок`
                        : `✅ Готово: ${links.length} ссылок`) + ' — скопировано в буфер и добавлено в поле заливки';
  setStatus({ ok: links.length, line });
  console.log(`\n=== Друзей: ${links.length} ===\n` + links.join('\n'));
  window.uploadOk = links; // чтобы можно было забрать из консоли
  return { line };
};

/* ============================================================
   ЗАДАЧА 1b: ПАРСЕР ПОСТОВ ИЗ ПОИСКА (только личные страницы)
   vk.ru/search/statuses?q=…&sort=0
   Пост: /wall{owner}_{post} или /id…?w=wall{owner}_{post};
   owner > 0 — человек, owner < 0 (wall-123_456) — группа/паблик/событие -> пропускаем.
   Сканируем только карточки выдачи (#results > .page_block), чтобы не собирать
   мусор из шапки/рекомендаций; .deleted-карточки пропускаем.
   ============================================================ */
/* wallInfo: разбирает любую ссылку/атрибут вида wall{owner}_{post}
   (в т.ч. /wall123_456?reply=1, ?w=wall123_456, #w=wall123_456, data-post-id) */
const wallInfo = src => {
  const s = String(src || '');
  let u; try { u = new URL(s, location.origin); } catch (e) { u = null; }
  const hay = u ? u.pathname + u.search + u.hash : s;
  const m = /wall(-?\d+)_(\d+)/.exec(hay);
  return m ? { owner: +m[1], key: m[1] + '_' + m[2] } : null;
};
const wallIdOf = href => { const w = wallInfo(href); return w && w.owner > 0 ? w.key : null; };

const resultsRoot = () =>
  document.querySelector('#results') ||
  document.querySelector('[data-testid="search_results"], .SearchResults, #page_wrap, #wrap3') ||
  document.body || document;

/* карточки выдачи; селекторы старого и нового дизайна, а если ничего не
   подошло — вся область результатов (лучше немного мусора, чем 0 постов) */
const CARD_SEL = '.page_block, .Post--redesign, .Post--redesignV3, .post, .wall_item, ' +
  '[data-post-id], [id^="post"][id*="_"], [data-testid="post"], article';
const searchCards = () => {
  const root = document.querySelector('#results');
  let cards = root ? [...root.querySelectorAll(':scope > .page_block')] : [];
  if (!cards.length) cards = [...(root || document).querySelectorAll(CARD_SEL)];
  cards = cards.filter(c => !c.classList.contains('deleted') && !c.closest('.deleted'));
  return cards.length ? cards : [resultsRoot()];
};

/* диагностика из консоли: __vkDiag() покажет, что видит парсер на странице */
window.__vkDiag = () => {
  const cards = searchCards();
  const all = [...document.querySelectorAll('a[href*="wall"], [data-post-id], [id^="post"][id*="_"]')]
    .map(el => wallInfo(el.getAttribute('href') || el.getAttribute('data-post-id') || el.id)).filter(Boolean);
  const keys = [...new Set(all.map(w => w.key))];
  const people = keys.filter(k => +k.split('_')[0] > 0);
  const d = { url: location.href, hasResults: !!document.querySelector('#results'),
    cards: cards.length, postsTotal: keys.length, fromPeople: people.length,
    fromGroups: keys.length - people.length, sample: keys.slice(0, 5) };
  console.log('[vkDiag]', d); return d;
};

const vkBlocked = () => {
  if (/^\/(login|security)/i.test(location.pathname)) return 'ВК требует вход/подтверждение — разберитесь и запустите снова';
  if (/подтвердите действие|введите код|капча/i.test((resultsRoot().innerText || ''))) return 'ВК показал капчу — разберитесь и запустите снова';
  return null;
};
const vkLoading  = () => !!document.querySelector('.result_placeholder, .ui_loader, .ui-loader');
const vkEnded    = () => /ничего не найдено|нет результатов|по запросу.{0,40}не найдено/i.test((resultsRoot().innerText || ''));

const taskSearch = async (limit, opts = {}) => {
  if (!/^\/search/i.test(location.pathname)) {
    throw new Error('Парсинг постов работает на странице поиска ВК — открой vk.ru/search/statuses?q=… (вкладка «Посты»)');
  }
  const store = new Map(); // "owner_post" -> url

  const seen = new Set();   // все найденные посты (и люди, и сообщества) — для диагностики
  let groupsSkipped = 0;
  let dbSkipped = 0;        // уже есть в базе залитых
  await dbLoad();

  const processed = new WeakSet(); // карточки, уже разобранные; мутация внутри карточки снимает отметку
  const scan = () => {
    let added = 0;
    const cards = searchCards();
    const fallback = cards.length === 1 && cards[0] === resultsRoot();
    for (const card of cards) {
      if (store.size >= limit) break;
      if (!fallback && processed.has(card)) continue;
      if (!fallback) processed.add(card);
      const srcs = [...card.querySelectorAll('a[href]')].map(a => a.getAttribute('href'));
      for (const el of card.querySelectorAll('[data-post-id]')) srcs.push('wall' + el.getAttribute('data-post-id'));
      for (const el of card.querySelectorAll('[id^="post"][id*="_"]')) srcs.push(el.id);
      if (card.id) srcs.push(card.id);
      if (card.getAttribute && card.getAttribute('data-post-id')) srcs.push('wall' + card.getAttribute('data-post-id'));
      for (const s of srcs) {
        const w = wallInfo(s);
        if (!w) continue;
        const url = 'https://vk.ru/wall' + w.key;
        const inDb = dbHas(url);
        if (!seen.has(w.key)) {
          seen.add(w.key);
          if (w.owner < 0) groupsSkipped++; else if (inDb) dbSkipped++;
        }
        if (w.owner < 0 || inDb || store.has(w.key) || store.size >= limit) continue;
        store.set(w.key, url);
        added++;
      }
    }
    return added;
  };

  const scrollers = makeScrollers(() => searchCards()[0]);
  const dom = watchDom(resultsRoot(), node => {
    const el = node && node.nodeType === 1 ? node : node && node.parentElement;
    const card = el && el.closest && el.closest(CARD_SEL);
    if (card) processed.delete(card); // в карточку догрузились ссылки — разобрать заново
  });

  scan();
  let idle = 0, note = '';
  try {
    while (store.size < limit && idle < 8 && !STOP) {
      const blocked = vkBlocked();
      if (blocked) { note = '⛔ ' + blocked; break; }
      window.scrollTo(0, document.body.scrollHeight);
      for (const s of scrollers()) s.scrollTop = s.scrollHeight;
      if (dom.active) await dom.settle(1400); else await sleep(700);
      const added = scan();
      setStatus({ total: limit, ok: store.size, line: `постов: ${store.size} / ${limit} (+${added})` });
      if (added === 0 && !vkLoading()) idle++; else idle = 0; // загрузка идёт — тик не «холостой»
      if (vkEnded()) { note = 'выдача дошла до конца'; break; }
    }
  } finally { dom.close(); }

  const links = [...store.values()].slice(0, limit);
  if (!links.length) {
    const diag = ` (карточек: ${searchCards().length}, постов найдено: ${seen.size}, из них от сообществ: ${groupsSkipped})`;
    const why = STOP ? '⏹ остановлено — ничего не собрано'
      : seen.size ? 'В выдаче только посты сообществ — постов от людей нет'
      : 'Посты не распознаны на странице — открой vk.ru/search/statuses?q=… (вкладка «Посты») и выполни __vkDiag() в консоли';
    console.log('[vkSearch] пусто', { note, seen: [...seen].slice(0, 10), groupsSkipped, cards: searchCards().length });
    return { line: (note || why) + diag };
  }

  await chrome.storage.local.set({ vkSearchResult: { links, ts: Date.now() } });
  try { await navigator.clipboard.writeText(links.join('\n')); } catch (e) {}

  let line = (STOP ? `⏹ остановлено — сохранено ${links.length} постов`
                   : `✅ Готово: ${links.length} постов${note ? ' (' + note + ')' : ''}`) +
             ' — скопировано в буфер и добавлено в поле заливки';
  if (dbSkipped) line += `; пропущено по базе залитых: ${dbSkipped}`;

  if (opts.thenUpload) {
    try {
      chrome.runtime.sendMessage(
        { type: 'uploadToEvent', links, eventUrl: String(opts.eventUrl || '').trim(), delay: Math.max(100, opts.delay | 0 || 800), category: opts.category, firstSuccessPerNetwork: opts.firstSuccessPerNetwork === true },
        r => {
          if (!r || !r.ok) {
            const err = 'Автозаливка не запущена: ' + ((r && r.error) || 'нет ответа от расширения');
            console.error(err);
            setStatus({ error: err });
          }
        });
      line += ' → запускаю заливку в событие';
    } catch (e) { line += ' (заливка не запущена)'; }
  }

  setStatus({ ok: links.length, line });
  console.log(`\n=== Постов: ${links.length} ===\n` + links.join('\n'));
  window.searchOk = links; // чтобы можно было забрать из консоли
  return { line };
};

/* ОК: собственные ссылки людей, включая их репосты, без API и кликов по реакциям. */
const taskOkSearch = async limit => {
  if (location.hostname !== 'ok.ru') throw new Error('Открой ленту, поиск публикаций или профиль человека на ok.ru');
  if (!globalThis.OkPostParser) throw new Error('Обнови расширение и вкладку ОК: модуль парсера ещё не подключён');
  await dbLoad();
  const shown = el => !!el && visible(el);
  const state = () => {
    const text = document.body?.innerText || '';
    if (/подтвердите,? что вы не робот|пройдите проверку|доступ (?:временно )?ограничен/i.test(text)) return 'blocked';
    if (/войдите в ОК,? чтобы посмотреть всю ленту|присоединяйтесь к ОК, чтобы посмотреть больше/i.test(text)) return 'login';
    if (/больше (?:публикаций|записей) нет|публикации не найдены/i.test(text)) return 'end';
    return null;
  };
  const loading = () => [...document.querySelectorAll('[aria-busy="true"], .loader, .loading, .feed-loader')].some(shown);
  const scroll = () => {
    const step = Math.max(300, Math.floor(window.innerHeight * 0.8));
    window.scrollBy(0, step);
    // Only scroll containers holding the feed, never sidebars or the progress panel.
    const containers = new Set();
    const zone = document.querySelector?.('#hook_Loader_ContentSearchResultsLoader') || document;
    for (const c of zone.querySelectorAll('.feed, [data-feed-id], [id^="hook_Block_mediatopic_"]')) {
      for (let e = c.parentElement; e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
        if (e.clientHeight > 200 && e.scrollHeight > e.clientHeight + 100 &&
          /auto|scroll/.test(getComputedStyle(e).overflowY)) { containers.add(e); break; }
      }
    }
    for (const e of containers) e.scrollTop += Math.max(200, Math.floor(e.clientHeight * 0.8));
  };
  await chrome.storage.local.set({ okParseResult: { links: [], running: true, source: location.href } });
  let persist = Promise.resolve();
  const result = await globalThis.OkPostParser.collect({ document, limit, sleep, scroll, state, loading,
    stop: () => STOP, excluded: DB, progress: r => {
      setStatus({ total: limit, ok: r.links.length,
        line: `ОК: ${r.links.length}/${limit}; карточек просмотрено: ${r.scanned}; групп пропущено: ${r.groupsSkipped}; не распознано: ${r.unresolved}` });
      // Serialize writes: a delayed checkpoint must never overwrite the final result.
      persist = persist.then(() => chrome.storage.local.set({ okParseResult: {
        ...r, reason: null, running: true, source: location.href, ts: Date.now() } })).catch(console.error);
    } });
  await persist;
  await chrome.storage.local.set({ okParseResult: { ...result, running: false, source: location.href, ts: Date.now() } });
  if (!result.links.length && result.unresolved && !STOP) {
    const diagnostics = globalThis.OkPostParser.diagnose(document);
    await chrome.storage.local.set({ okParseDiagnostics: diagnostics });
    setStatus({ error: 'Карточки есть, но адреса не распознаны. Открой диагностику ОК в панели.' });
  }
  const reasons = { limit: 'достигнут лимит', stopped: 'остановлено пользователем',
    idle: 'новые карточки не появились — полнота не подтверждена', timeout: 'достигнут предел ожидания — результат частичный',
    login: 'ОК предлагает вход для просмотра всей ленты — результат частичный',
    blocked: 'ОК показал проверку или ограничение — результат частичный', end: 'ОК сообщил конец выдачи' };
  const line = `ОК: сохранено ${result.links.length} ссылок; ${reasons[result.reason] || result.reason}` +
    (result.unresolved ? `; не распознано карточек: ${result.unresolved}` : '') +
    (result.dbSkipped ? `; уже в базе залитых: ${result.dbSkipped}` : '') +
    (!result.links.length && result.unresolved && !STOP ? '; диагностика: ok_parser_diagnostics.json' : '');
  console.log('[okParser]', result);
  return { line };
};

/* ============================================================
   ОБЩИЕ UI-ХЕЛПЕРЫ (используются заливкой ссылок и загрузкой скринов)
   ============================================================ */
const isNoiseNet = u => /metric|analytics|beacon|stat|track|log|counter|mc\.yandex|googletag/i.test(u);
const netOkSince = t0 => netEvents.some(e => e.t >= t0 && e.ok && e.method === 'POST' && !isNoiseNet(e.url));

const inPath = (href, p) => { try { const u = new URL(href, location.href); return u.origin === location.origin && u.pathname.startsWith(p); } catch (e) { return false; } };
const CLICKABLE = 'button, [role="button"], input[type="submit"], [class*="btn"], [class*="button"], a';
const findBtn = (txt, zonePath = '/events/') => {
  const t = norm(txt);
  const c = [...document.querySelectorAll(CLICKABLE)].filter(e => {
    if (!visible(e)) return false;
    if (e.tagName === 'A') {
      const h = e.getAttribute('href') || '';
      if (h && h !== '#' && !h.startsWith('javascript:') && !inPath(h, zonePath)) return false;
    }
    return norm(e.innerText || e.value).includes(t);
  });
  c.sort((a, b) => {
    const ea = norm(a.innerText || a.value) === t ? 0 : 1, eb = norm(b.innerText || b.value) === t ? 0 : 1;
    return ea - eb || (a.innerText || '').length - (b.innerText || '').length;
  });
  return c[0];
};
/* Поиск кнопки по тексту БЕЗ опоры на теги/классы: сайт может рендерить кнопку
   <div>/<span> с обработчиком клика — тогда findBtn её не видит. Берём самый
   глубокий видимый элемент с нужным текстом; при равенстве — с cursor:pointer. */
const findTextEl = (txt, scope, exact = false) => {
  const t = norm(txt);
  if (!t) return null;
  const hasScope = !!(scope && scope.querySelectorAll);
  const root = hasScope ? scope : document;
  const hits = [];
  for (const el of root.querySelectorAll(hasScope ? '*' : 'body *')) {
    if (!visible(el)) continue;
    const own = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!own || own.length > 60) continue;
    const n = norm(own);
    if (exact ? n === t : n.includes(t)) hits.push(el);
  }
  if (!hits.length) return null;
  const deep = hits.filter(h => !hits.some(o => o !== h && h.contains(o)));
  deep.sort((a, b) => {
    const ca = /pointer/.test(getComputedStyle(a).cursor) ? 0 : 1, cb = /pointer/.test(getComputedStyle(b).cursor) ? 0 : 1;
    return ca - cb || (a.innerText || '').length - (b.innerText || '').length;
  });
  return deep[0];
};
const dead = el => !el || el.disabled || el.getAttribute('aria-disabled') === 'true' ||
  /disabled|inactive/i.test(typeof el.className === 'string' ? el.className : '') ||
  getComputedStyle(el).pointerEvents === 'none';

/* «настоящий» клик: React/шторки часто слушают pointer/mouse, а не el.click() */
const realClick = el => {
  try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
  const r = el.getBoundingClientRect();
  const o = { bubbles: true, cancelable: true, composed: true, view: window,
    clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0, buttons: 1,
    pointerId: 1, pointerType: 'mouse', isPrimary: true };
  try { el.focus(); } catch (e) {}
  for (const [Ctor, type] of [[window.PointerEvent, 'pointerover'], [window.PointerEvent, 'pointerenter'],
    [MouseEvent, 'mouseover'], [window.PointerEvent, 'pointerdown'], [MouseEvent, 'mousedown'],
    [window.PointerEvent, 'pointerup'], [MouseEvent, 'mouseup'], [MouseEvent, 'click']]) {
    try { if (Ctor) el.dispatchEvent(new Ctor(type, o)); } catch (e) {}
  }
};

const SKIP_OPT = /^(закрыть|отмена|cancel|close|назад)$/i;
const OPT_RE = /ЕДГ[_\s]|единомышленник|личные посты/i;
/* варианты типа действия ищем по тексту по всей странице (без опоры на классы шторки) */
const sheetOptions = want => {
  const w = norm(want || '');
  const hits = [];
  for (const el of document.querySelectorAll('body *')) {
    if (el.children.length > 4 || !visible(el)) continue;
    const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!txt || txt.length > 120) continue;
    if (!OPT_RE.test(txt) && !(w && norm(txt).includes(w))) continue;
    if (SKIP_OPT.test(norm(txt))) continue;
    hits.push({ el, txt });
  }
  // оставляем самые глубокие элементы с текстом варианта
  return hits.filter(h => !hits.some(o => o !== h && h.el.contains(o.el)));
};
window.__vkSheet = () => { const o = sheetOptions(String(window.vkActionType || '')); console.log('[vkSheet]', o.map(x => x.txt)); return o; };

/* возвращает true, если вариант выбран; false — если шторки не было.
   want — текст типа действия, soft — запасной ключевик, readyFn — форма открылась? */
const chooseActionType = async (want, soft, readyFn) => {
  const opts = await waitFor(() => { const o = sheetOptions(want); return o.length ? o : null; }, 6000);
  if (!opts) return false;
  const w = norm(want || '');
  const pick = opts.find(o => norm(o.txt) === w)
            || opts.find(o => w && norm(o.txt).includes(w))
            || (soft ? opts.find(o => norm(o.txt).includes(norm(soft))) : null)
            || opts[opts.length - 1];
  console.log('📋 варианты:', opts.map(o => o.txt), '→ выбран:', pick.txt);
  setStatus({ line: 'тип действия: ' + pick.txt });
  let el = pick.el;
  for (let up = 0; up < 3 && !STOP; up++) {
    realClick(el);
    await sleep(600);
    if ((readyFn && readyFn()) || !sheetOptions(want).length) return true;
    const p = el.parentElement;
    if (!p || /закрыть/i.test((p.innerText || ''))) break;  // не кликаем по всей шторке/фону
    el = p;
    console.warn('↩ пробую родительский элемент варианта');
  }
  return true;
};


/* Категории ссылок: отдельный строгий выбор, без запасного «последнего варианта».
   Существующая очередь скриншотов использует свои хелперы без изменений. */
const LINK_CATEGORIES = {
  vk: 'Посты из ВК (общее)', ok: 'Посты из ОК (общее)',
  tg: 'Посты из ТГ (общее)', max: 'Посты в МАКС',
  zen: 'ДЗЕН (общая)', vkclip: 'вк_клип'
};
const categoryError = message => Object.assign(new Error(message), { categoryError: true });
const categoryText = text => norm(String(text || '')).replace(/ё/g, 'е').replace(/[^a-zа-я0-9]+/gi, ' ').replace(/\s+/g, ' ').trim();
const linkCategory = (link, settings = {}) => {
  const { mode = 'auto', custom = '' } = settings || {};
  let u;
  try { u = new URL(link); } catch (e) { throw categoryError('Некорректная ссылка: ' + link); }
  if (!/^https?:$/.test(u.protocol)) throw categoryError('Нужна ссылка http(s): ' + link);
  if (mode === 'custom') {
    const want = String(custom).trim();
    if (!want) throw categoryError('Введи точное название категории действия');
    return { key: 'custom', want };
  }
  if (mode !== 'auto') {
    if (!Object.hasOwn(LINK_CATEGORIES, mode)) throw categoryError('Неизвестная категория: ' + mode);
    return { key: mode, want: LINK_CATEGORIES[mode] };
  }
  const host = u.hostname.toLowerCase();
  const isHost = domain => host === domain || host.endsWith('.' + domain);
  let key;
  if (isHost('ok.ru')) key = 'ok';
  else if (isHost('vk.ru') || isHost('vk.com')) {
    const target = u.searchParams.get('z') || u.searchParams.get('w') || '';
    key = /^\/clips?(?:[-\d/]|$)/i.test(u.pathname) || /^clip[-\d]/i.test(target) ? 'vkclip' : 'vk';
  } else if (isHost('t.me') || isHost('telegram.me')) key = 'tg';
  else if (isHost('max.ru')) key = 'max';
  else if (isHost('dzen.ru') || isHost('zen.yandex.ru')) key = 'zen';
  if (!key) throw categoryError('Соцсеть ссылки не распознана — выбери категорию вручную: ' + host);
  return { key, want: LINK_CATEGORIES[key] };
};
// Лимит относится к домену ссылки, а не к выбранной вручную категории.
const uploadNetworkKey = link => {
  try {
    const key = linkCategory(link).key;
    return key === 'vkclip' ? 'vk' : key;
  } catch (e) { return 'host:' + new URL(link).hostname.toLowerCase(); }
};
const categoryMatch = (text, requested) => {
  const t = categoryText(text);
  if (requested.key === 'custom') return t === categoryText(requested.want);
  if (/скрин|screenshot|фотоотчет|лайк|лик[еи]|like|подпис|комментар/.test(t)) return false;
  const tokens = t.split(' ');
  const has = (...words) => words.some(w => tokens.includes(w));
  const vk = has('вк', 'vk', 'вконтакте');
  const clip = /клип|clips?/.test(t);
  const bareNetwork = /^(вк|vk|вконтакте|ок|ok|одноклассники|тг|tg|телеграм|телеграмм|telegram|макс|max|дзен|dzen|zen)( общая| общее)?$/.test(t);
  if (!bareNetwork && !clip && !/пост|публикац|ссылк/.test(t)) return false;
  const networks = {
    vk: vk && !clip, vkclip: clip && (vk || /^(клипы?|clips?)$/.test(t)),
    ok: has('ок', 'ok', 'одноклассники', 'одноклассниках'),
    tg: has('тг', 'tg', 'телеграм', 'телеграмм', 'telegram'),
    max: has('макс', 'max'), zen: has('дзен', 'dzen', 'zen')
  };
  // Смешанные категории не маршрутизируем автоматически.
  const matches = Object.keys(networks).filter(k => networks[k]);
  return matches.length === 1 && matches[0] === requested.key;
};
const pickLinkCategory = (options, requested) => {
  const exact = options.filter(o => categoryText(o.txt) === categoryText(requested.want));
  const matches = exact.length ? exact : options.filter(o => categoryMatch(o.txt, requested));
  if (matches.length !== 1) throw categoryError(matches.length
    ? 'Найдено несколько категорий — укажи точное название: ' + matches.map(o => o.txt).join('; ')
    : 'Категория не найдена: ' + requested.want + '. Доступны: ' + options.map(o => o.txt).join('; '));
  return matches[0];
};
const linkSheetOptions = requested => {
  let elements = [...document.querySelectorAll('.van-action-sheet__item')].filter(visible);
  if (!elements.length) {
    const scopes = [...document.querySelectorAll('[role="dialog"], [role="menu"], .van-action-sheet, .van-popup')].filter(visible);
    elements = [...new Set(scopes.flatMap(scope => [...scope.querySelectorAll(CLICKABLE)]))].filter(visible);
  }
  if (!elements.length) {
    // Старые события могут не иметь Vant-шторки: только кнопки с именем категории.
    elements = [...document.querySelectorAll(CLICKABLE)].filter(el => visible(el) &&
      categoryMatch(el.innerText || el.textContent, requested));
  }
  const options = elements.map(el => ({ el, txt: (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim() }))
    .filter(o => o.txt && o.txt.length <= 120 && !SKIP_OPT.test(norm(o.txt)));
  return options.filter(o => !options.some(other => other !== o && o.el.contains(other.el)));
};
const chooseLinkCategory = async (requested, readyFn) => {
  const options = await waitFor(() => { const o = linkSheetOptions(requested); return o.length ? o : null; }, 6000);
  if (!options) throw categoryError('Меню категорий не появилось: ' + requested.want);
  const pick = pickLinkCategory(options, requested);
  if (dead(pick.el)) throw categoryError('Категория сейчас недоступна: ' + pick.txt);
  if (STOP) throw categoryError('Выбор категории остановлен');
  setStatus({ line: 'Категория: ' + pick.txt });
  realClick(pick.el);
  const f = await waitFor(() => !linkSheetOptions(requested).length && readyFn(), 15000);
  if (!f) throw categoryError('Форма выбранной категории не открылась: ' + pick.txt);
  return f;
};


/* HTTP 2xx, исчезновение формы и очистка поля — транспорт/навигация, не принятие.
   Запоминаем новые уведомления, включая кратковременно появившиеся, до конца попытки. */
const UPLOAD_NOTICE_SELECTOR = '.van-notify, .van-toast, [role="alert"], [role="status"], .alert, .notification';
const uploadNotice = text => {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  if (!t || t.length > 500) return null;
  if (/ссылка.{0,60}уже.{0,25}(?:загруж|добавл)|(?:такая|эта) ссылка уже|дубликат|уже существует/i.test(t))
    return { kind: 'duplicate', message: t };
  if (/ошибк|не удалось|неуспеш|безуспеш|не (?:принят|создан|добавлен|отправлен)|некорректн|недопустим|отклон[её]н|неверн/i.test(t))
    return { kind: 'rejected', message: t };
  if (/(?:действие|отч[её]т)\s+(?:успешно\s+)?(?:создан|добавлен|принят|отправлен|сохран[её]н)|успешно\s+(?:создан|добавлен|отправлен|загружен|сохран[её]н)/i.test(t))
    return { kind: 'success', message: t };
  return null;
};
const siteUploadNotices = () => [...document.querySelectorAll(UPLOAD_NOTICE_SELECTOR)]
  .filter(el => visible(el) && !(panel && (el === panel || panel.contains(el))));
const watchUploadFeedback = () => {
  const baseline = new Map(siteUploadNotices().map(el => [el, norm(el.innerText || el.textContent)]));
  const priority = { success: 1, rejected: 2, duplicate: 3 };
  let latest = null;
  const consider = (el, changed = false) => {
    if (panel && (el === panel || panel.contains(el))) return;
    const text = el.innerText || el.textContent || '';
    if (!changed && baseline.get(el) === norm(text)) return;
    const result = uploadNotice(text);
    if (result && (!latest || priority[result.kind] > priority[latest.kind])) latest = { ...result, at: Date.now() };
  };
  let observer = null;
  try {
    observer = new MutationObserver(records => {
      for (const r of records) {
        const el = r.target.nodeType === 1 ? r.target : r.target.parentElement;
        const notice = el?.closest?.(UPLOAD_NOTICE_SELECTOR);
        if (notice && visible(notice)) consider(notice, true);
        for (const node of r.addedNodes || []) {
          if (node.nodeType !== 1) continue;
          if (node.matches?.(UPLOAD_NOTICE_SELECTOR)) consider(node, true);
          for (const child of node.querySelectorAll?.(UPLOAD_NOTICE_SELECTOR) || []) consider(child, true);
        }
      }
    });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['class','style'] });
  } catch (e) { observer = null; }
  return { read() { for (const el of siteUploadNotices()) consider(el); return latest; },
    close() { observer?.disconnect(); } };
};

/* ============================================================
   ЗАДАЧА 2: ЗАЛИВКА ССЫЛОК НА СТРАНИЦУ СОБЫТИЯ
   ============================================================ */
const taskUpload = async (linksRaw, DELAY, categorySettings = { mode: 'auto', custom: '' }, firstSuccessPerNetwork = false) => {
  const limitEnabled = firstSuccessPerNetwork === true;
  const arr = Array.isArray(linksRaw) ? linksRaw : String(linksRaw).split(/[\s,]+/);
  const clean = arr.map(s => String(s).trim()).filter(Boolean);
  const LINKS = [...new Set(clean.filter(s => /^https?:\/\//i.test(s)))];
  if (clean.length !== LINKS.length) console.warn(`Отброшено ${clean.length - LINKS.length} значений без http(s)`);
  if (!LINKS.length) throw new Error('список ссылок пуст — нужны полные https://… (по одной в строке)');

  /* зона события */
  const EVENT_ID = (location.pathname.match(/\/events\/(\d+)/) || [])[1] || null;
  if (!EVENT_ID) throw new Error('Открой страницу события /events/XXXXX и запусти снова');
  const EVENT_PATH = '/events/' + EVENT_ID;
  const EVENT_URL  = location.origin + EVENT_PATH;
  console.log('🎯 рабочая зона:', EVENT_URL);

  const inZone = (href = location.href) => {
    try { const u = new URL(href, location.href);
      return u.origin === location.origin && u.pathname.startsWith(EVENT_PATH); } catch (e) { return false; }
  };

  /* Уже добавленные ссылки: если ссылка видна на странице события (в списке действий) —
     удаляем её из очереди и сохраняем очищенный список, чтобы после F5/резюма они не лились повторно */
  const pageText = () => {
    let hay = document.body.innerText || '';
    // исключаем по одному вхождению значений полей (черновик в textarea — ещё НЕ добавленная ссылка)
    for (const el of document.querySelectorAll('textarea, input')) if (el.value) hay = hay.replace(el.value, ' ');
    return hay;
  };
  // Сравниваем целые URL, а не подстроки: /statuses/2 не равен /statuses/20.
  const hrefSet = new Set((pageText().match(/https?:\/\/[^\s<>"']+/gi) || [])
    .map(u => dbNorm(u.replace(/[),.;!\]}]+$/, ''))));
  for (const a of document.querySelectorAll('a[href]')) {
    if (panel && panel.contains(a)) continue;
    const h = (a.getAttribute('href') || '').trim();
    if (/^https?:\/\//i.test(h)) hrefSet.add(dbNorm(h));
  }
  const isAdded = l => l.length > 12 && hrefSet.has(dbNorm(l));
  const beforeCnt = LINKS.length;
  /* 1) отбрасываем всё, что уже есть в базе залитых (любое событие, любой запуск) */
  await dbLoad();
  let dbSkipped = 0;
  for (let i = LINKS.length - 1; i >= 0; i--) if (dbHas(LINKS[i])) { LINKS.splice(i, 1); dbSkipped++; }
  if (dbSkipped) console.log(`🗃 Пропущено ${dbSkipped} ссылок — уже есть в базе залитых`);
  /* 2) и то, что уже видно в списке действий самого события */
  for (let i = LINKS.length - 1; i >= 0; i--) if (isAdded(LINKS[i])) {
    dbAdd(LINKS[i]); // уже в событии — запоминаем и для следующих запусков
    LINKS.splice(i, 1);
  }
  const removedCnt = beforeCnt - LINKS.length;
  if (removedCnt) {
    console.log(`⏭ Пропущено ${removedCnt} ссылок (база: ${dbSkipped}, видны на странице: ${removedCnt - dbSkipped})`);
    try { chrome.runtime.sendMessage({ type: 'uploadDraftSet', value: LINKS.join('\n'), base: clean.join('\n') }).catch(() => {}); } catch (e) {}
  }
  setStatus({ total: beforeCnt, ok: 0, fail: 0, skipped: removedCnt, limitSkipped: 0, firstSuccessPerNetwork: limitEnabled });
  if (!LINKS.length) {
    return { line: `↪ Все ${beforeCnt} ссылок уже залиты (база: ${dbSkipped}) — заливать нечего` };
  }

  // До установки навигационных обработчиков: ошибка настроек не оставляет их на странице.
  for (const link of LINKS) linkCategory(link, categorySettings);

  /* подтверждение отправки: stealth.js (MAIN мир) перехватывает реальные fetch/XHR
     страницы и шлёт события vkext-net — только успешный POST сайта считается отправкой
     (netOkSince — общий хелпер выше) */

  /* защита навигации в рамках доступного content-скрипту (клика и выгрузки) */
  const guardUnload = e => { e.preventDefault(); e.returnValue = ''; return ''; };
  const guardClick = ev => {
    const a = ev.target.closest && ev.target.closest('a[href]');
    if (!a) return;
    const h = a.getAttribute('href') || '';
    if (!h || h === '#' || h.startsWith('javascript:') || inZone(h)) return;
    console.warn('🚫 клик наружу заблокирован:', h);
    ev.preventDefault(); ev.stopPropagation();
  };
  window.addEventListener('beforeunload', guardUnload);
  document.addEventListener('click', guardClick, true);

  /* прогресс: chrome.storage, ключ = событие, значение = набор ссылок.
     Не зависит от состава списка и не трогает прогресс других событий. */
  const KEY = UPLOAD_PROGRESS_PREFIX + EVENT_ID;
  let done = new Set();
  try {
    const got = await chrome.storage.local.get(KEY);
    done = new Set(Array.isArray(got && got[KEY]) ? got[KEY] : []);
  } catch (e) {}
  // миграция старого формата (localStorage по хешу списка) только для этого события
  try {
    for (const k of Object.keys(localStorage)) {
      if (!k.startsWith('uploader_done_' + EVENT_ID + '_')) continue;
      try { for (const l of JSON.parse(localStorage.getItem(k) || '[]')) done.add(l); } catch (e) {}
      localStorage.removeItem(k);
    }
    localStorage.removeItem('uploader_progress');
  } catch (e) {}
  const doneInList = () => LINKS.reduce((n, l) => n + (done.has(l) ? 1 : 0), 0);
  const initiallySkipped = removedCnt + doneInList();
  setStatus({ skipped: initiallySkipped });
  let doneWrites = Promise.resolve();
  const saveDone = () => {
    const snapshot = [...done];
    doneWrites = doneWrites.then(() => chrome.storage.local.set({ [KEY]: snapshot })).catch(() => {});
    return doneWrites;
  };
  window.uploaderReset = (all = false) => resetUploadProgress(all ? null : EVENT_ID)
    .then(() => console.log('🧹 прогресс сброшен' + (all ? ' (все события)' : ' для события ' + EVENT_ID)));

  /* хелперы UI (findBtn/dead/realClick/sheetOptions/chooseActionType — общие выше) */
  const OPEN_BTN   = 'Создать действие';
  const SUBMIT_BTN = 'Создать действие';
  const BACK_BTN   = 'Вернуться назад';
  const RETRIES    = 3;
  const MAX_FAILS  = 10;

  const field = () => [...document.querySelectorAll('textarea, input[type="text"], input:not([type]), [contenteditable="true"]')].filter(visible)[0];
  const fieldEmpty = f => norm(f.value || f.textContent) === '';

  const setValue = (el, val) => {
    if (el.isContentEditable) { el.focus(); el.textContent = val; el.dispatchEvent(new InputEvent('input', { bubbles: true })); return; }
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement : HTMLInputElement;
    Object.getOwnPropertyDescriptor(proto.prototype, 'value').set.call((el.focus(), el), val);
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
    el.blur(); el.focus();
  };

  /* проверка экрана / возврат */
  const onTaskScreen = () => !!(field() || findBtn(OPEN_BTN));
  const softNav = async url => { history.pushState({}, '', url); window.dispatchEvent(new PopStateEvent('popstate', { state: {} })); await sleep(1500); };
  const ensurePage = async () => {
    if (inZone() && onTaskScreen()) return true;
    console.warn('↩ ушли с экрана события (' + location.href + ') — возвращаюсь');
    for (let k = 0; k < 3 && !STOP; k++) {
      history.back(); await sleep(1500); if (inZone() && onTaskScreen()) return true;
      await softNav(EVENT_URL);             if (inZone() && onTaskScreen()) return true;
      const a = [...document.querySelectorAll('a[href]')].find(x => visible(x) && inZone(x.getAttribute('href')));
      if (a) { a.click(); await sleep(1500); if (inZone() && onTaskScreen()) return true; }
    }
    console.error('⛔ не вернулся. Прогресс сохранён (' + done.size + '). Открой ' + EVENT_URL + ' и запусти заново.');
    STOP = true;
    return false;
  };
  const recover = async () => {
    if (!await ensurePage()) return;
    const b = findBtn(BACK_BTN);
    if (b && !dead(b)) { b.click(); await sleep(900); }
  };

  /* Переиспользуем только форму категории, выбранной этим запуском.
     При смене сети и при неизвестной заранее открытой форме сначала возвращаемся. */
  let formHot = false, selectedCategory = null, selectedField = null, selectedRoute = null;
  const sendOne = async link => {
    const requested = linkCategory(link, categorySettings);
    const categoryKey = requested.key + ':' + categoryText(requested.want);
    let f = field();
    if (f && (!formHot || selectedCategory !== categoryKey || f !== selectedField || location.href !== selectedRoute)) {
      const back = findBtn(BACK_BTN) || findBtn('Закрыть') || findBtn('Отмена');
      if (!back || dead(back)) throw categoryError('Закрой текущую форму для выбора категории: ' + requested.want);
      realClick(back);
      if (!await waitFor(() => !field(), 10000)) throw categoryError('Текущая форма не закрылась');
      f = null; formHot = false; selectedCategory = null;
    }
    if (!f) {
      selectedCategory = null;
      if (!linkSheetOptions(requested).length) {
        const open = findBtn(OPEN_BTN);
        if (!open || dead(open)) throw categoryError(`кнопка "${OPEN_BTN}" не найдена`);
        realClick(open);
      }
      f = await chooseLinkCategory(requested, field);
      selectedCategory = categoryKey;
      selectedField = f; selectedRoute = location.href;
      await sleep(250);
    }
    if (STOP) throw categoryError('Заливка остановлена до заполнения формы');

    if (!await waitFor(() => !siteUploadNotices().some(el => uploadNotice(el.innerText || el.textContent)), 8000))
      throw categoryError('Предыдущее уведомление сайта ещё открыто; новая ссылка не отправлена');
    setValue(f, link);
    await sleep(200);

    const submit = await waitFor(() => { const b = findBtn(SUBMIT_BTN); return b && !dead(b) ? b : null; }, 15000);
    if (!submit) throw new Error('кнопка отправки не стала активной');

    const feedback = watchUploadFeedback();
    try {
      submit.click();
      const res = await waitFor(() => {
        const notice = feedback.read();
        if (!notice) return null;
        // Отказы имеют приоритет даже после закрытия формы и успешного HTTP.
        if (notice.kind !== 'success') return notice;
        return Date.now() - notice.at >= 1000 ? notice : null;
      }, 20000);
      if (!res) throw Object.assign(new Error('Создание действия не подтверждено; повторная отправка остановлена'), { submitted: true });
      if (res.kind === 'rejected') throw Object.assign(new Error(res.message), { submitted: true });
      const cur = field();
      formHot = res.kind === 'success' && !!(cur && fieldEmpty(cur));
      return res;
    } finally { feedback.close(); }

  };

  /* цикл */
  const ok = [], fail = [], skipped = [], limited = [];
  const successfulNetworks = new Set(); let failRow = 0;
  const skippedCount = () => initiallySkipped + skipped.length;
  const times = [];
  const tStart = Date.now();
  console.log(`Всего: ${LINKS.length} | уже отправлено: ${doneInList()} | к отправке: ${LINKS.length - doneInList()}`);

  const eta = () => {
    if (times.length < 3) return '';
    const avg = times.reduce((a, b) => a + b, 0) / times.length;
    const left = LINKS.length - doneInList() - limited.length;
    const m = Math.round(avg * left / 60000);
    return ` | ~${(avg / 1000).toFixed(1)}с/ссылка, осталось ~${m} мин`;
  };

  try {
    for (let i = 0; i < LINKS.length; i++) {
      if (STOP) { console.warn('⏹ остановлено'); break; }
      const link = LINKS[i];
      if (done.has(link)) continue;
      const network = limitEnabled ? uploadNetworkKey(link) : null;
      if (network && successfulNetworks.has(network)) {
        limited.push(link);
        setStatus({ limitSkipped: limited.length, line: `↪ [${i + 1}/${LINKS.length}] ${network}: первая успешная уже залита — не отправляю ${link}` });
        continue; // не сохраняем в done/базу: без галочки ссылка снова доступна
      }
      console.log(`\n[${i + 1}/${LINKS.length}] ${link}${eta()}`);
      setStatus({ total: beforeCnt, ok: ok.length, skipped: skippedCount(), fail: fail.length, line: `[${i + 1}/${LINKS.length}] ${link}${eta()}` });

      const tl = Date.now();
      let sent = null, lastErr = null;
      for (let a = 1; a <= RETRIES && !STOP; a++) {
        if (!await ensurePage()) break;
        try { sent = await sendOne(link); break; }
        catch (e) {
          lastErr = e; formHot = false; selectedCategory = null;
          if (e.categoryError || e.submitted) {
            fail.push(link);
            setStatus({ ok: ok.length, skipped: skippedCount(), fail: fail.length });
            window.uploadOk = ok; window.uploadFail = fail; window.uploadSkipped = skipped; window.uploadLimited = limited;
            throw e; // после клика неизвестный результат не отправляем повторно
          }
          console.warn(`  ⚠ попытка ${a}/${RETRIES}: ${e.message}`);
          await recover();
          await sleep(1200 * a);
        }
      }

      if (sent && sent.kind === 'duplicate') {
        skipped.push(link); done.add(link); saveDone(); dbAdd(link); failRow = 0;
        setStatus({ total: beforeCnt, ok: ok.length, skipped: skippedCount(), fail: fail.length,
          line: `↪ [${i + 1}/${LINKS.length}] уже загружено — ${link}` });
      } else if (sent && sent.kind === 'success') {
        times.push(Date.now() - tl); if (times.length > 20) times.shift();
        console.log('  ✅ отправлено —', sent);
        ok.push(link); done.add(link); saveDone(); dbAdd(link); failRow = 0;
        if (network) successfulNetworks.add(network);
        if (!formHot && field()) { const b = findBtn(BACK_BTN); if (b && !dead(b)) { b.click(); await sleep(400); } }
        setStatus({ total: beforeCnt, ok: ok.length, skipped: skippedCount(), fail: fail.length, line: `✅ [${i + 1}/${LINKS.length}] ${link}` });
      } else if (!STOP) {
        console.error('  ❌', lastErr && lastErr.message);
        fail.push(link); failRow++;
        setStatus({ total: beforeCnt, ok: ok.length, skipped: skippedCount(), fail: fail.length, line: `❌ [${i + 1}/${LINKS.length}] ${link} — ${lastErr && lastErr.message}` });
        if (failRow >= MAX_FAILS) { console.error(`⛔ ${MAX_FAILS} ошибок подряд — стоп`); break; }
        await sleep(3000);
      }

      // адаптивная пауза: минимум DELAY, но если сайт тормозит — чуть больше
      const spent = Date.now() - tl;
      const pause = spent < 4000 ? DELAY : DELAY + Math.min(2000, (spent - 4000) / 2);
      await sleep(pause);
    }
  } finally {
    window.removeEventListener('beforeunload', guardUnload);
    document.removeEventListener('click', guardClick, true);
  }

  const mins = ((Date.now() - tStart) / 60000).toFixed(1);
  const line = `=== Готово за ${mins} мин: успешно ${ok.length}, уже загружено ${skippedCount()}, ошибок ${fail.length}, обработано ${removedCnt + done.size + limited.length}/${beforeCnt}` +
    (limitEnabled ? `, по лимиту ${limited.length}` : '') +
    (removedCnt ? `, пропущено уже добавленных: ${removedCnt}` : '') + ' ===';
  console.log('\n' + line);
  if (fail.length) {
    console.log('Не залились:\n' + fail.join('\n'));
    try { await navigator.clipboard.writeText(fail.join('\n')); } catch (e) {}
  }
  window.uploadOk = ok; window.uploadFail = fail; window.uploadSkipped = skipped; window.uploadLimited = limited;
  return { line, okCount: ok.length, skippedCount: skippedCount(), limitedCount: limited.length, failCount: fail.length };
};

/* ============================================================
   ЗАДАЧА 3: АВТОЛАЙК — виртуальный курсор внутри вкладки, без хоста.
   ============================================================ */
const LIKE_BTN_SEL = 'svg[class*="vkuiIcon"][class*="like"]';
const LIKE_POST_SEL = '[data-post-id], [data-post], [id^="post"], [data-testid="post"], article, .wall_item, .post, [class*="Post__root"]';
const isOutlineLike = el => /like_outline/i.test(el.getAttribute('class') || '');
let likeRunId = null, likeCursor = null, likeDetachError = '';
const cursorSend = (action, point = {}, runId = likeRunId) => new Promise(resolve => {
  try {
    chrome.runtime.sendMessage({ type: 'virtualCursor', action, runId, ...point }, result => {
      const error = chrome.runtime.lastError;
      resolve(error ? { ok: false, error: error.message } : result || { ok: false, error: 'Нет ответа курсора' });
    });
  } catch (e) { resolve({ ok: false, error: e.message }); }
});
const hideLikeCursor = () => { likeCursor?.remove(); likeCursor = null; };
const stopLikeCursor = () => { hideLikeCursor(); if (likeRunId) void cursorSend('stop'); };
const showLikeCursor = ({ x, y }) => {
  if (!likeCursor) {
    likeCursor = document.createElement('div');
    likeCursor.id = 'vk-virtual-cursor';
    likeCursor.setAttribute('aria-hidden', 'true');
    likeCursor.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;width:20px;height:20px;' +
      'border:2px solid #fff;border-radius:50%;background:#7765ee99;box-shadow:0 0 0 2px #7765ee;' +
      'transform:translate(-50%,-50%);transition:left .12s linear,top .12s linear;';
    document.documentElement.appendChild(likeCursor);
  }
  likeCursor.style.left = x + 'px'; likeCursor.style.top = y + 'px';
};
const iconPoint = svg => {
  const r = svg.getBoundingClientRect();
  if (!r.width || !r.height) return null;
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  return x >= 0 && y >= 0 && x < innerWidth && y < innerHeight ? { x, y } : null;
};
const likeExplicitKey = post => {
  if (!post) return null;
  for (const value of [post.getAttribute('data-post-id'), post.getAttribute('data-post'), post.id]) {
    const m = String(value || '').match(/^(?:post|wall)?(-?\d+_\d+)$/);
    if (m) return m[1];
  }
  return null;
};
const likePostKey = post => {
  if (!post) return null;
  const explicit = likeExplicitKey(post);
  if (explicit) return explicit;
  const keys = new Set();
  for (const a of post.querySelectorAll('a[href*="wall"]')) {
    // A quoted post owns its own links; they are not the outer card's identity.
    if (a.closest(LIKE_POST_SEL) !== post) continue;
    const m = a.getAttribute('href').match(/(?:^|\/)wall(-?\d+_\d+)(?:[?#/]|$)/);
    if (m) keys.add(m[1]);
  }
  return keys.size === 1 ? [...keys][0] : null;
};
const likePostFor = svg => {
  const nearest = svg.closest(LIKE_POST_SEL);
  for (let post = nearest; post; post = post.parentElement?.closest(LIKE_POST_SEL)) {
    if (likeExplicitKey(post)) return post;
  }
  return likePostKey(nearest) ? nearest : null;
};
// Resolve from the same current icons as discovery, not a broader ancestor scan.
const likePostByKey = key => [...document.querySelectorAll(LIKE_BTN_SEL)]
  .map(likePostFor).find(post => likePostKey(post) === key);
const likeIcon = post => [...(post?.querySelectorAll(LIKE_BTN_SEL) || [])].find(svg => likePostFor(svg) === post);
const likeFilled = svg => !!svg?.isConnected && !isOutlineLike(svg) &&
  /(?:^|\s)vkuiIcon--like(?:_filled)?(?:_[A-Za-z0-9]+)?(?:\s|$)/i.test(svg.getAttribute('class') || '');
const likeBlocked = () => [...document.querySelectorAll('iframe[src*="captcha"], [class*="Captcha"], [data-testid*="captcha"], [role="alert"]')]
  .some(el => visible(el) && (/captcha/i.test(el.getAttribute('src') || el.className || el.getAttribute('data-testid') || '') ||
    /слишком много|попробуйте позже|лимит|подтвердите.*(?:человек|действие)/i.test(el.textContent || '')));

const taskLike = async (limit, delay) => {
  const route = location.href;
  if (!/^\/([A-Za-z][A-Za-z0-9_.]{1,31}|id\d+|-?\d+)\/?$/.test(location.pathname))
    throw Error('Открой стену группы или страницы — vk.ru/… и запусти снова');
  const runId = crypto.randomUUID();
  likeRunId = runId; likeDetachError = '';
  const wait = async ms => {
    const deadline = Date.now() + ms;
    while (!STOP && Date.now() < deadline) await sleep(Math.min(100, deadline - Date.now()));
  };
  let liked = 0, failed = 0, idle = 0;
  const storageKey = 'vkLikeAttempted:' + location.origin + location.pathname;
  let saved = [];
  try { const value = JSON.parse(sessionStorage.getItem(storageKey) || '[]'); if (Array.isArray(value)) saved = value; } catch (e) {}
  const touched = new Set(saved.filter(x => typeof x === 'string').slice(-5000));
  const remember = key => {
    touched.add(key);
    try { sessionStorage.setItem(storageKey, JSON.stringify([...touched].slice(-5000))); } catch (e) {}
  };
  const check = () => {
    if (likeDetachError) throw Error(likeDetachError);
    if (location.href !== route) throw Error('Страница изменилась — автолайк остановлен');
    if (likeBlocked()) throw Error('ВК запросил проверку или ограничил действия — автолайк остановлен');
    return !STOP;
  };
  const sendInput = async (action, point) => {
    if (!check()) return false;
    showLikeCursor(point);
    const r = await cursorSend(action, point, runId);
    if (!r.ok) { if (STOP && !likeDetachError) return false; throw Error(r.error || 'Курсор отключён'); }
    return true;
  };
  const pageExit = () => { STOP = true; stopLikeCursor(); };
  window.addEventListener('pagehide', pageExit);
  try {
    const ready = await cursorSend('start', {}, runId);
    if (!ready.ok) throw Error(ready.error);
    while (liked < limit && idle < 8 && check()) {
      let attempted = false;
      const candidates = [...document.querySelectorAll(LIKE_BTN_SEL)].filter(svg => visible(svg) && isOutlineLike(svg));
      const keys = [...new Set(candidates
        .map(svg => likePostKey(likePostFor(svg))).filter(key => key && !touched.has(key)))];
      if (!keys.length && candidates.some(svg => !likePostKey(likePostFor(svg))))
        throw Error('Не удалось однозначно определить ID поста по разметке ВК — автолайк остановлен без клика.');
      for (const key of keys) {
        if (!check() || liked >= limit) break;
        let post = likePostByKey(key), svg = likeIcon(post);
        if (!svg || !isOutlineLike(svg)) continue;
        svg.scrollIntoView({ block: 'center', behavior: 'instant' });
        await wait(300);
        if (!check()) break;
        post = likePostByKey(key); svg = likeIcon(post);
        if (!svg || !isOutlineLike(svg)) continue;
        const point = iconPoint(svg);
        const hit = point && document.elementFromPoint(point.x, point.y);
        const button = svg.closest('button,[role="button"],span[tabindex],[class*="ActionButton"]') || svg;
        if (!point || !hit || !button.contains(hit)) continue;
        // Record before sending: an uncertain click must never be retried as an unlike.
        remember(key); attempted = true;
        const t0 = Date.now();
        if (!await sendInput('click', point)) break;
        // VK не отдаёт надёжный DOM-класс «лайк стоит», но страница всегда шлёт
        // успешный POST /method/likes.(add|set) на только что кликнутый пост.
        // За итерацию кликается один пост => likes-POST, пришедший после t0,
        // однозначно наш. DOM-класс оставлен быстрым запасным путём.
        const likeNetConfirmed = () => netEvents.some(e =>
          e.ok && e.method === 'POST' && e.t >= t0 && /\/method\/likes\.(?:add|set)/i.test(e.url));
        let confirmed = false;
        for (let n = 0; n < 12; n++) {
          await wait(250);
          if (!check()) break;
          if (likeNetConfirmed() || likeFilled(likeIcon(likePostByKey(key)))) { confirmed = true; break; }
        }
        if (STOP) break;
        if (!confirmed) {
          failed++;
          setStatus({ total: limit, ok: liked, fail: failed });
          throw Error('Лайк поста ' + key + ' не подтверждён. Очередь остановлена без повторного клика.');
        }
        liked++;
        setStatus({ total: limit, ok: liked, fail: failed, line: `❤ поставлено ${liked} / ${limit} · виртуальный курсор` });
        await wait(Math.max(100, delay));
      }
      if (!check() || liked >= limit) break;
      idle = attempted ? 0 : idle + 1;
      await sendInput('wheel', { x: innerWidth / 2, y: innerHeight / 2, dy: 600 });
      await wait(800);
    }
    check();
    const line = STOP ? `⏹ остановлено — поставлено ${liked} лайков` :
      `✅ Готово: ${liked} лайков` + (idle >= 8 ? ' — новых доступных кнопок не найдено' : '');
    setStatus({ total: limit, ok: liked, fail: failed, line });
    window.likeOk = liked;
    return { line };
  } finally {
    window.removeEventListener('pagehide', pageExit);
    hideLikeCursor();
    await cursorSend('stop', {}, runId);
    if (likeRunId === runId) likeRunId = null;
  }
};

/* ============================================================
   ЗАДАЧА 4: ЗАГРУЗКА СКРИНШОТОВ (из локальной папки, через background)
   Background ведёт цепочку аккаунтов ЕР; вкладка забирает файлы по одному
   ('screensFile' → background → кэш IndexedDB), кладёт их в форму события
   (input[type=file] через DataTransfer) и отправляет. Подтверждение — как
   при заливке ссылок: реальный успешный POST страницы (vkext-net), либо
   очистка поля / закрытие формы / уведомление.
   Прогресс — в localStorage страницы на каждое сочетание
   «событие + аккаунт + очередь»: после перезагрузки/резюма цепочки уже
   залитые файлы не льются повторно.
   Переопределить из консоли: window.vkScreenCfg = { openBtn, typeKey, submitBtn }
   ============================================================ */
const screenBg = msg => new Promise(res => {
  try {
    chrome.runtime.sendMessage(msg, r => {
      if (chrome.runtime.lastError) res({ ok: false, error: chrome.runtime.lastError.message });
      else res(r || { ok: false, error: 'нет ответа от фона' });
    });
  } catch (e) { res({ ok: false, error: String((e && e.message) || e) }); }
});
const screenStopClick = () => { void screenBg({ type: 'eventButtonStop' }); };
const screenEventClick = async (eventId, label) => {
  if (STOP) return false;
  const result = await screenBg({ type: 'eventButtonClick', eventId, label });
  if (STOP) return false;
  if (!result.ok || !result.clicked) throw Object.assign(new Error(result.error || 'Браузер не подтвердил нажатие «' + label + '»'), { noOpenRetry: true });
  return true;
};
const SCREEN_MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', avif: 'image/avif' };

/* Журнал заливки скринов: весь ход работы ТЕКСТОМ. Если что-то пошло не так —
   в консоли (F12) страницы события выполнить:  copy(__vkScreensLog())
   и вставить сюда в чат весь текст (не скриншот — мне виден только текст). */
const SCREEN_LOG = [];
const logLine = (s, fn) => {
  SCREEN_LOG.push(s);
  if (SCREEN_LOG.length > 600) SCREEN_LOG.splice(0, SCREEN_LOG.length - 600);
  fn(s);
};
const slog = (...a) => logLine(a.map(x => typeof x === 'string' ? x : (x && x.message) || String(x)).join(' '), console.log);
const swarn = (...a) => logLine('⚠ ' + a.map(x => typeof x === 'string' ? x : (x && x.message) || String(x)).join(' '), console.warn);
const serr = (...a) => logLine('❌ ' + a.map(x => typeof x === 'string' ? x : (x && x.message) || String(x)).join(' '), console.error);
window.__vkScreensLog = () => SCREEN_LOG.join('\n');

const curFileInput = () => {
  const all = [...document.querySelectorAll('input[type="file"]')];
  if (!all.length) return null;
  return all.find(e => visible(e)) || all[0];
};
const OVERLAY_SEL = '[role="dialog"], .van-popup, .van-action-sheet, [class*="Modal"], [class*="modal"], [class*="Sheet"], [class*="sheet"], [class*="Popover"], [class*="popover"], [class*="BottomSheet"]';
const overlayRoot = () => {
  const ovs = [...document.querySelectorAll(OVERLAY_SEL)].filter(e => visible(e) && e.offsetHeight > 80);
  return ovs.length ? ovs[ovs.length - 1] : null;
};
const hasOverlay = () => !!overlayRoot();
// Upload widgets hide their native file input. Only accept one in a live form/widget,
// never a hidden form left in the DOM by a closed popup.
const screenInputActive = input => {
  if (!input || input.disabled || input.isConnected === false || document.contains?.(input) === false) return false;
  if (visible(input)) return true;
  const root = input.closest?.('form') || input.closest?.('.van-uploader, [data-upload], [class*="upload-container"]');
  const overlay = overlayRoot();
  return !!(root && visible(root) && (!overlay || overlay.contains(root)));
};
const screenLiveInput = usedInputs => {
  const overlay = overlayRoot();
  return [...document.querySelectorAll('input[type="file"]')].find(input =>
    screenInputActive(input) && (!overlay || overlay.contains(input)) && !usedInputs.has(input) && !input.files?.length) || null;
};
const screenBackButton = (allowDisabled = false) => [...document.querySelectorAll(CLICKABLE)].find(el =>
  visible(el) && (allowDisabled || !dead(el)) && norm(el.innerText || el.value) === norm('Вернуться назад')) || null;
const screenLinkField = () => {
  if ([...document.querySelectorAll('input[type="file"]')].some(screenInputActive) || !screenBackButton(true)) return null;
  return [...document.querySelectorAll('textarea, input[type="url"], input[type="text"], input:not([type]), [contenteditable="true"]')]
    .find(el => visible(el) && findScreenSubmit(el)) || null;
};
const screenOpenDiag = () => ({ path: location.pathname,
  overlays: [...document.querySelectorAll(OVERLAY_SEL)].filter(visible).map(el => ({ tag: el.tagName, height: el.offsetHeight })),
  files: [...document.querySelectorAll('input[type="file"]')].map(input => ({ visible: !!visible(input), active: screenInputActive(input),
    disabled: !!input.disabled, selected: input.files?.length || 0, multiple: !!input.multiple })),
  buttons: [...document.querySelectorAll(CLICKABLE)].filter(el => visible(el) && /создать|участвовать|вернуться назад/i.test(el.innerText || el.value || ''))
    .map(el => ({ tag: el.tagName, text: String(el.innerText || el.value || '').trim().slice(0, 60), disabled: !!dead(el) })) });
window.__vkScreensDiag = screenOpenDiag;
const screenPreviewImages = root => [...root.querySelectorAll('img')]
  .filter(i => i.offsetWidth > 60 && i.offsetHeight > 60);
const screenPreviewCount = root => screenPreviewImages(root).length;
const screenFormRoot = input => {
  const overlay = overlayRoot();
  return overlay && overlay.contains(input) ? overlay : input.closest?.('form') || document.body;
};
const screenFilesReady = (input, files, root, previewsBefore) => {
  if (root.getAttribute?.('aria-busy') === 'true' || root.getAttribute?.('data-uploading') === 'true') return false;
  const previews = screenPreviewImages(root).slice(previewsBefore);
  if (previews.length && (previews.length !== files.length ||
      previews.some(img => img.complete === false || img.naturalWidth === 0))) return false;
  const busy = root.querySelectorAll('progress, [role="progressbar"], [aria-busy="true"], [data-uploading="true"], .uploading, [class*="upload-progress"], [class*="uploadProgress"]');
  if ([...busy].some(visible)) return false;
  const selected = [...(input.files || [])];
  const sameFiles = selected.length === files.length && selected.every((file, i) =>
    file.name === files[i].name && (file.size == null || file.size === files[i].size));
  return previews.length === files.length || sameFiles;
};

/* Форма ВВЕРХ бывает не только шторкой: после выбора типа действия сайт
   открывает отдельную страницу с большой кнопкой «Создать действие». */
const findScreenSubmit = (input, preferred = 'Создать действие') => {
  const overlay = overlayRoot();
  const form = input && input.closest ? input.closest('form') : null;
  const scopes = [form, overlay && overlay.contains(input) ? overlay : null, document].filter(Boolean);
  const texts = [preferred, 'Создать действие', 'Добавить действие', 'Отправить', 'Загрузить', 'Сохранить', 'Создать'];
  for (const scope of scopes) {
    const buttons = [...scope.querySelectorAll(CLICKABLE)].filter(e => visible(e) && !dead(e));
    for (const t of texts) {
      const match = buttons.find(e => norm(e.innerText || e.value) === norm(t));
      if (match) return match;
    }
    for (const t of texts) {
      const match = findTextEl(t, scope, true);
      if (match && !dead(match)) return match;
    }
  }
  return null;
};

/* Пустое input.files не подтверждает отправку: React может очистить поле,
   оставив превью и саму страницу формы на месте. */
const screenFormClosed = (input, mode, path) => {
  if (!input) return false;
  if (mode === 'overlay') {
    const overlay = overlayRoot();
    return !overlay || !overlay.contains(input) || !document.contains(input) || !screenInputActive(input);
  }
  // The event's opener has the same label as submit. It is not evidence that
  // a removed form is still open; a replacement live file form is.
  return location.pathname !== path || (!document.contains(input) &&
    ![...document.querySelectorAll('input[type="file"]')].some(screenInputActive));
};

/* все варианты (текст-опции) внутри открытой шторки — без опоры на ключевые слова */
const sheetAllOptions = () => {
  const ov = overlayRoot();
  if (!ov) return [];
  const hits = [];
  for (const el of ov.querySelectorAll('*')) {
    if (el.children.length > 3 || !visible(el)) continue;
    const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (txt.length < 2 || txt.length > 60) continue;
    if (SKIP_OPT.test(norm(txt))) continue;
    hits.push({ el, txt });
  }
  // самые глубокие элементы с текстом варианта
  return hits.filter(h => !hits.some(o => o !== h && h.el.contains(o.el)));
};

const wordRe = k => {
  const s = String(k).toLowerCase();
  // граница слова — по скрипту ключа: «вк» (кириллица) не должно совпадать внутри
  // латиницы и наоборот, чтобы «ок» не попал в «ok», «вк» — в «vkontakte»
  const cls = /^[а-яё]+$/.test(s) ? 'а-яё' : /^[a-z]+$/.test(s) ? 'a-z' : 'a-zа-яё';
  const e = s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp('(^|[^' + cls + '0-9])' + e + '($|[^' + cls + '0-9])', 'i');
};

/* Тип должен соответствовать имени соцсети, а не случайному последнему пункту. */
const chooseScreenType = async (keys, readyFn) => {
  const opts = await waitFor(() => { const o = sheetAllOptions(); return o.length ? o : null; }, 6000);
  if (!opts) return false;
  let pick = null;
  for (const k of keys) {
    const kk = String(k || '').trim();
    if (!kk) continue;
    pick = opts.find(o => norm(o.txt) === norm(kk)) || opts.find(o => wordRe(kk).test(o.txt));
    if (pick) break;
  }
  if (!pick) {
    throw new Error('тип скриншотов не найден для «' + keys.join(', ') + '»; варианты: ' + opts.map(o => o.txt).join(' | '));
  }
  console.log('🖼 варианты типа действия:', opts.map(o => o.txt), '→ выбран:', pick.txt);
  let el = pick.el;
  for (let up = 0; up < 3 && !STOP; up++) {
    realClick(el);
    await sleep(600);
    if ((readyFn && readyFn()) || !sheetAllOptions().length) return true;
    const p = el.parentElement;
    if (!p || /закрыть/i.test((p.innerText || ''))) break;  // не кликаем по всей шторке/фону
    el = p;
    console.warn('↩ пробую родительский элемент варианта');
  }
  return true;
};

/* группа соцсети → ключевик типа действия в шторке (vk → «Отчет по вк» и т.п.) */
const NET_TYPE_KEYS = {
  vk: ['вк', 'vk', 'vkontakte', 'вконтакте'],
  ok: ['ок', 'ok', 'odnoklassniki', 'одноклассник', 'одноклассники'],
  tg: ['тг', 'tg', 'telegram', 'телеграм', 'телеграмм'],
  wa: ['ватсап', 'whatsapp', 'wa'],
  max: ['макс', 'max'],
  fb: ['фейсбук', 'facebook', 'fb'],
  inst: ['инстаграм', 'инста', 'instagram', 'inst'],
  tt: ['тикток', 'tiktok', 'tt'],
};

let screensManualWatch = null;

const taskScreens = async ({ total, queueHash, account, accountId, names, groups }) => {
  const EVENT_ID = (location.pathname.match(/\/events\/(\d+)/) || [])[1] || null;
  if (!EVENT_ID) throw new Error('Открой страницу события /events/XXXXX');
  // Ручная отправка зависшей группы должна попасть в прогресс до чтения done ниже.
  if (screensManualWatch) { await screensManualWatch.settle(); screensManualWatch.stop(); }
  const vcfg = window.vkScreenCfg || {};
  const cfg = {
    openBtn: String(vcfg.openBtn || 'Создать действие'),
    typeKey: vcfg.typeKey ? String(vcfg.typeKey) : null, // только явная настройка пользователя
    typeByKey: (vcfg.typeByKey && typeof vcfg.typeByKey === 'object') ? vcfg.typeByKey : null, // точный тип на соцсеть: { ok: 'Отчет по ок' }
    submitBtn: String(vcfg.submitBtn || 'Создать'),
  };
  // одна группа соцсети = одна форма = одна отправка (6 скринов ВК за раз, 6 ОК за раз и т.д.)
  const nm = (Array.isArray(names) && names.length) ? names.map(String) : null;
  const grp = (Array.isArray(groups) && groups.length)
    ? groups.map(g => ({ net: String((g && g.net) || ''), items: ((g && g.items) || []).map(String) }))
    : (nm ? nm.map(n => ({ net: '', items: [n] })) : null);
  if (!grp) throw new Error('нет очереди — нажми «🖼 Залить скрины» заново');
  const queued = grp.flatMap(g => g.items);
  if (!nm || total !== nm.length || new Set(nm).size !== nm.length ||
      queued.length !== nm.length || new Set(queued).size !== nm.length || queued.some(name => !nm.includes(name)))
    throw new Error('неполная или повторяющаяся очередь скриншотов — выбери папку заново');
  slog('🖼 скрины v6: ' + total + ' файлов, групп: ' + grp.length + ' (' + grp.map(g => (g.net || 'файлы') + '×' + g.items.length).join(' | ') + ') | аккаунт: ' + (account || '?'));
  slog('Если что-то пойдёт не так: в консоли (F12) страницы события выполни  copy(__vkScreensLog())  и вставь сюда весь текст (не скриншот — мне виден только текст). Снимок страницы:  __vkScreensDiag()');

  /* v6: account ID separates identically named accounts; queue includes file metadata. */
  const hash = s => { let h = 5381; for (let i = 0; i < String(s).length; i++) h = ((h * 33) ^ String(s).charCodeAt(i)) >>> 0; return h.toString(36); };
  const KEY = 'screens_done_v6_' + EVENT_ID + '_' + hash(String(accountId || account || '')) + '_' + hash(String(queueHash || ''));
  let done = new Set();
  try { done = new Set(JSON.parse(localStorage.getItem(KEY) || '[]')); } catch (e) {}
  done = new Set([...done].filter(name => nm.includes(name)));
  const saveDone = () => { try { localStorage.setItem(KEY, JSON.stringify([...done])); } catch (e) {} };

  /* защита навигации (как при заливке ссылок) */
  const inZone = href => { try { const u = new URL(href, location.href); return u.origin === location.origin && u.pathname.startsWith('/events/' + EVENT_ID); } catch (e) { return false; } };
  const guardUnload = e => { e.preventDefault(); e.returnValue = ''; };
  const guardClick = ev => {
    const a = ev.target.closest && ev.target.closest('a[href]');
    if (!a) return;
    const h = a.getAttribute('href') || '';
    if (!h || h === '#' || h.startsWith('javascript:') || inZone(h)) return;
    ev.preventDefault(); ev.stopPropagation();
  };
  window.addEventListener('beforeunload', guardUnload);
  document.addEventListener('click', guardClick, true);

  const openBtn = () => {
    const candidates = [findBtn(cfg.openBtn, '/events/' + EVENT_ID), findTextEl(cfg.openBtn, null, true),
      findBtn('Создать действие'), findTextEl('Создать действие', null, true)];
    return candidates.find(el => el && !(panel && panel.contains(el)) && !dead(el) && !dead(el.closest?.('button, [role="button"]') || el)) || null;
  };
  let participationClicked = false;
  const participateBtn = () => {
    // Participation belongs to the event page, never to a draft or another event's link.
    if (location.pathname.replace(/\/+$/, '') !== '/events/' + EVENT_ID || hasOverlay()) return null;
    const candidates = [...document.querySelectorAll('button.progresssliderbtn'),
      ...document.querySelectorAll(CLICKABLE), findTextEl('Участвовать')];
    return candidates.find(el => {
      const title = el?.querySelector?.('.progresssliderbtn__title');
      if (!el || !visible(el) || (panel && panel.contains(el)) ||
          !/^участвовать(?:\s*\d+)?$/.test(norm(title?.textContent || el.innerText || el.textContent || el.value)) ||
          dead(el) || dead(el.closest?.(CLICKABLE) || el)) return false;
      const anchor = el.tagName === 'A' ? el : el.closest?.('a[href]');
      const href = anchor?.tagName === 'A' ? anchor.getAttribute('href') || '' : '';
      if (!href || href === '#') return true;
      try {
        const url = new URL(href, location.href), eventPath = '/events/' + EVENT_ID;
        return url.origin === location.origin && (url.pathname === eventPath || url.pathname.startsWith(eventPath + '/'));
      } catch (e) { return false; }
    }) || null;
  };
  const liveFormInput = () => screenLiveInput(usedInputs);
  const closeOverlay = async () => {
    if (!hasOverlay()) return true;
    try { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, which: 27, bubbles: true })); } catch (e) {}
    const ov0 = overlayRoot();
    if (ov0) {
      const closeB = [...ov0.querySelectorAll(CLICKABLE)].find(e => visible(e) &&
        (/закрыть|отмена/i.test(norm(e.innerText || '')) ||
         /close|закрыть/i.test(e.getAttribute('aria-label') || '') ||
         /^(×|✕|x)$/i.test((e.innerText || '').trim())));
      if (closeB) realClick(closeB);
    }
    await waitFor(() => (!hasOverlay() ? true : null), 2500);
    if (hasOverlay()) {
      // нижняя шторка (bottom sheet): клик по фону над ней закрывает
      const ov1 = overlayRoot();
      if (ov1) {
        const r = ov1.getBoundingClientRect();
        if (r.top > 40) {
          const x = window.innerWidth / 2, y = r.top - 15;
          const el = document.elementFromPoint(x, y) || document.body;
          const o = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1 };
          for (const type of ['mousedown', 'mouseup', 'click']) {
            try { el.dispatchEvent(new MouseEvent(type, o)); } catch (e) {}
          }
        }
      }
      await waitFor(() => (!hasOverlay() ? true : null), 2500);
    }
    return !hasOverlay();
  };
  /* Открыть новую форму: подтвердить меню ИЛИ живое поле на отдельной странице. */
  const openFormOnce = async (net) => {
    const existing = curFileInput();
    if (existing && screenInputActive(existing) && existing.files && existing.files.length)
      throw new Error('в текущей форме уже выбраны ' + existing.files.length + ' файлов — остановлено до подтверждения «Создать действие»');
    const linkField = screenLinkField();
    if (linkField) {
      const draft = String(linkField.value || linkField.textContent || '').trim();
      const accepted = [...(window.uploadOk || []), ...(window.uploadSkipped || [])];
      if (draft && !accepted.includes(draft)) throw new Error('В форме ссылки остался неотправленный черновик — скриншоты остановлены без отправки или удаления ссылки');
      const back = screenBackButton();
      if (!back) throw new Error('Кнопка возврата из формы ссылки неактивна — отправка скриншотов остановлена');
      slog('  ↩ закрываю завершённую форму ссылки перед выбором скриншотов');
      realClick(back);
      if (!await waitFor(() => !document.contains(linkField) || !visible(linkField), 10000))
        throw new Error('Форма ссылки не закрылась — кнопка отправки не используется для открытия скриншотов');
    }
    if (hasOverlay()) {
      const closed = await closeOverlay();
      if (!closed) {
        const dirty = [...document.querySelectorAll('input[type="file"]')].some(e => e.files && e.files.length);
        if (dirty) throw new Error('старая форма с файлами не закрывается (Esc и крестик не помогли) — закрой её вручную и жми «Продолжить»');
      }
    }
    const fi = liveFormInput();
    if (fi) {
      slog('  ↪ чистая форма уже открыта — без «Создать действие»');
      return fi;
    }
    // Account switches may reveal Participate first; only Create action opens the upload flow.
    const entry = await waitFor(() => {
      const open = openBtn();
      if (open) return { open };
      const join = participateBtn();
      return join ? { join } : null;
    }, 15000);
    if (STOP) return null;
    let open = entry?.open;
    if (entry?.join) {
      if (participationClicked) throw Object.assign(new Error('«Участвовать» уже нажата; создание действия не подтвердилось — повторное участие остановлено'), { noOpenRetry: true });
      participationClicked = true;
      slog('  ▶ браузерный клик по кнопке «Участвовать»');
      setStatus({ line: 'Нажимаю «Участвовать» через ввод браузера…' });
      const clickAt = Date.now();
      if (!await screenEventClick(EVENT_ID, 'Участвовать')) return null;
      setStatus({ line: 'Клик выполнен — жду подтверждения участия и «Создать действие»' });
      const ready = await waitFor(() => {
        const request = netEvents.find(e => e.t >= clickAt && e.method === 'POST' &&
          e.url.split('?')[0].endsWith('/api/event/' + EVENT_ID + '/join') && !e.ok);
        if (request) throw Object.assign(new Error('Сайт отклонил участие: ' + (request.status ? 'HTTP ' + request.status : 'ошибка сети') + ' — скриншоты не отправлены'), { noOpenRetry: true });
        return openBtn() || liveFormInput();
      }, 15000);
      if (STOP) return null;
      if (!ready) {
        swarn('  диагностика участия: ' + JSON.stringify(screenOpenDiag()));
        throw Object.assign(new Error('после «Участвовать» не появилась кнопка «Создать действие» или форма файла — скриншоты не загружены, повторный клик остановлен'), { noOpenRetry: true });
      }
      const directInput = liveFormInput();
      if (directInput) return directInput;
      open = openBtn();
    }
    if (!open) {
      const cands = [];
      for (const el of document.querySelectorAll('body *')) {
        if (!visible(el)) continue;
        const t = (el.innerText || '').replace(/\s+/g, ' ').trim();
        if (t && t.length <= 40 && /создать/i.test(t)) cands.push('<' + el.tagName.toLowerCase() + '> «' + t + '»');
      }
      throw new Error('кнопка «' + cfg.openBtn + '» не найдена (видимые «создать»: ' + (cands.join(' | ') || 'НЕТ НИ ОДНОЙ') + "); из консоли: window.vkScreenCfg = { openBtn: 'текст кнопки' }");
    }
    slog('  ▶ жму «' + (open.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40) + '» (<' + open.tagName.toLowerCase() + '>)');
    const nativeButton = open.closest?.('.progresssliderbtn');
    if (nativeButton) { if (!await screenEventClick(EVENT_ID, 'Создать действие')) return null; }
    else realClick(open);
    const opened = await waitFor(() => liveFormInput() || (sheetAllOptions().length ? true : null), 15000);
    if (!opened) {
      swarn('  диагностика открытия: ' + JSON.stringify(screenOpenDiag()));
      throw new Error('клик по «' + cfg.openBtn + '» не открыл меню типов или форму файла; путь: ' + location.pathname);
    }
    if (hasOverlay() && !liveFormInput()) {
      const keys = [];
      if (cfg.typeKey) keys.push(cfg.typeKey); // явная настройка пользователя — в приоритете
      if (cfg.typeByKey && cfg.typeByKey[net]) keys.push(String(cfg.typeByKey[net])); // точный тип на соцсеть
      keys.push(...(NET_TYPE_KEYS[net] || ['скриншот', 'отчет']));
      await chooseScreenType(keys, liveFormInput);
    }
    const in_ = await waitFor(liveFormInput, 15000);
    if (!in_) {
      const ov = overlayRoot();
      throw new Error('поле загрузки файла в форме не открылось' + (ov ? ' — текст формы: ' + (ov.innerText || '').replace(/\s+/g, ' ').slice(0, 200) : ' — формы нет'));
    }
    slog('  ☑ форма открыта, input[type=file] multiple=' + in_.multiple);
    return in_;
  };
  const openScreenForm = async (net) => {
    for (let pass = 0; pass < 2; pass++) {
      const in_ = await openFormOnce(net);
      if (!in_) throw new Error('не найдено новое поле загрузки файла — проверь тип действия; из консоли: window.vkScreenCfg = { openBtn, typeKey, submitBtn, typeByKey }');
      // в чистой форме не должно быть картинок из прошлого черновика (сайтовый React state)
      const ov = overlayRoot();
      const root = screenFormRoot(in_);
      const draftImgs = screenPreviewCount(root);
      if (!draftImgs) return in_;
      if (!ov || pass === 1) throw new Error('в форме уже есть ' + draftImgs + ' изображений — остановлено, чтобы не добавить следующую группу в тот же черновик');
      swarn('  🖼 в форме остался черновик (' + draftImgs + ' картинок) — закрываю и открываю заново');
      await closeOverlay();
    }
    throw new Error('не удалось открыть чистую форму');
  };

  const setFiles = (input, files) => {
    if (!input.multiple && files.length > 1) throw new Error('поле не поддерживает несколько файлов — группа не загружена');
    const dt = new DataTransfer();
    for (const f of files) dt.items.add(f);
    input.files = dt.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  };

  /* Сайт подвис, а файлы группы остались в форме: пользователь может отправить её сам.
     Пока вкладка жива, ждём клик по кнопке отправки (или поздний ответ на наш клик),
     закрытие формы и подтверждение — тогда группа считается залитой и «Продолжить»
     не загрузит те же скрины повторно. Закрытие формы без клика отправки ничего не отмечает. */
  const watchManualSubmit = ({ items, input, formClosed, clickedAt, label }) => {
    if (screensManualWatch) screensManualWatch.stop();
    let firstAt = clickedAt || null, lastAt = firstAt, active = true, confirmed = false;
    const onClick = ev => {
      const sub = findScreenSubmit(input, cfg.submitBtn), hit = ev.target;
      if (!sub || !hit) return;
      const btn = hit.closest?.(CLICKABLE);
      if (sub !== hit && !sub.contains?.(hit) && !(btn && btn.contains?.(sub))) return;
      lastAt = Date.now();
      if (firstAt == null) firstAt = lastAt;
    };
    const stop = () => {
      active = false;
      document.removeEventListener('click', onClick, true);
      if (screensManualWatch === api) screensManualWatch = null;
    };
    const check = () => {
      if (!active || firstAt == null || !formClosed()) return confirmed;
      // Засчитываем только ответ сайта на саму отправку: последний POST после клика должен быть успешным.
      // Счётчик карточек здесь не годится: форму могли закрыть руками после отказа сайта.
      const posts = netEvents.filter(e => e.method === 'POST' && e.t >= firstAt && e.t <= lastAt + 120000 &&
        !isNoiseNet(e.url) && !/\/auth\//i.test(e.url));
      if (!posts.length || !posts[posts.length - 1].ok) return false;
      items.forEach(n => done.add(n)); saveDone();
      confirmed = true;
      stop();
      slog('  ✅ ' + label + ': группа отправлена вручную — «Продолжить» не загрузит её повторно');
      setStatus({ ok: done.size, line: '✅ ' + label + ' отправлена вручную — можно жать «Продолжить»' });
      return true;
    };
    const api = {
      stop,
      // Перед «Продолжить»: форма уже закрыта после клика — даём серверу до 10 с на подтверждение.
      settle: async () => {
        if (check() || !active) return { confirmed };
        if (firstAt != null && formClosed()) for (let i = 0; i < 20 && active && !check(); i++) await sleep(500);
        return { confirmed };
      },
    };
    screensManualWatch = api;
    document.addEventListener('click', onClick, true);
    (async () => { for (let i = 0; i < 3600 && active; i++) { await sleep(500); check(); } stop(); })();
  };

  let failCount = 0;
  const tStart = Date.now();
  /* поля file, которыми уже отправляли группу: повторно их не используем,
     чтобы файлы следующей группы не прилипли к черновику старой формы */
  const usedInputs = new Set();

  // канал может не пропускать ArrayBuffer (JSON-сериализация) — один раз проверяем зондом
  let abOk = null;
  const probeAb = async () => {
    if (abOk === null) {
      const t = await screenBg({ type: 'screensTest', data: new ArrayBuffer(8) });
      abOk = !!t.ok;
    }
    return abOk;
  };
  const b64toBuf = s => {
    const bin = atob(String(s));
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  };

  try {
    const okAb = await probeAb();
    const nameIdx = {};
    (nm || []).forEach((n, i) => { nameIdx[n] = i; });

    for (let gi = 0; gi < grp.length && !STOP; gi++) {
      const g = grp[gi];
      const pending = g.items.filter(nm0 => nameIdx[nm0] != null && !done.has(nm0));
      if (!pending.length) { slog('⏭ группа уже залита: ' + (g.net || g.items[0])); continue; }
      const label = g.net || 'файлы';
      slog('\n[🖼 ' + (gi + 1) + '/' + grp.length + '] ' + label + ': ' + pending.length + ' файл(ов)' + (account ? ' (' + account + ')' : ''));
      setStatus({ total, ok: done.size, fail: failCount, line: '[' + (gi + 1) + '/' + grp.length + '] ' + label + ' (' + pending.length + ' файл.)' + (account ? ' — ' + account : '') });

      let sent = null, lastErr = null, lastInput = null, lastMode = null, lastPath = null, filesAttached = false;
      let submitAt = null;
      const formClosed = () => screenFormClosed(lastInput, lastMode, lastPath);
      for (let a = 1; a <= 2 && !STOP; a++) {
        // сколько карточек «Отчет по …» в списке ДО открытия формы — после отправки должно стать на 1 больше
        const baseCnt = (document.body.innerText.match(/отчет по/gi) || []).length;
        try {
          lastInput = await openScreenForm(g.net);
          const input = lastInput;
          const ov = overlayRoot();
          lastMode = ov && ov.contains(input) ? 'overlay' : 'page';
          lastPath = location.pathname;
          const previewRoot = screenFormRoot(input);
          const previewsBefore = screenPreviewCount(previewRoot);
          const files = [];
          for (const nm0 of pending) {
            const f = await screenBg({ type: 'screensFile', i: nameIdx[nm0], queueHash, b64: !okAb });
            if (!f.ok) throw new Error('фон: ' + (f.error || 'нет данных') + ' (' + nm0 + ')');
            if (f.name && f.name !== nm0) throw new Error('фон вернул другой файл: ' + f.name + ' вместо ' + nm0);
            const data = okAb ? f.data : b64toBuf(f.b64);
            if (!(data instanceof ArrayBuffer) || !data.byteLength) throw new Error('пустые данные файла ' + nm0);
            const base = String(nm0).replace(/[\\/]+/g, '__');
            files.push(new File([data], base, { type: f.mime || SCREEN_MIME[base.split('.').pop().toLowerCase()] || 'application/octet-stream' }));
          }
          filesAttached = true;
          setFiles(input, files); // вся группа сразу — поле multiple
          await sleep(3000); // даём сайту принять файлы (превью/загрузка), прежде чем жать отправку
          let readySince = null;
          const accepted = await waitFor(() => {
            if (!screenFilesReady(input, files, previewRoot, previewsBefore)) { readySince = null; return false; }
            if (readySince == null) readySince = Date.now();
            return Date.now() - readySince >= 1000;
          }, 45000);
          if (!accepted) {
            const inInput = input.files ? input.files.length : 0;
            const inPreviews = screenPreviewCount(previewRoot) - previewsBefore;
            throw new Error('форма не приняла файлы (input: ' + inInput + '/' + files.length + ', превью: ' + inPreviews + '/' + files.length + ')');
          }
          slog('  📎 в форме: ' + files.map(f => f.name).join(', ') + ' (input: ' + (input.files ? input.files.length : 0) + ', превью: ' + (screenPreviewCount(previewRoot) - previewsBefore) + ')');
          // При массовой загрузке сайт подолгу держит кнопку неактивной — 10 с было мало.
          setStatus({ line: '[' + (gi + 1) + '/' + grp.length + '] ' + label + ': жду активную кнопку отправки…' });
          const sub = await waitFor(() => findScreenSubmit(input, cfg.submitBtn), 60000);
          if (!sub) {
            throw new Error('кнопка «Создать действие» не найдена или неактивна — загруженные скрины оставлены в форме, следующая группа не начнётся');
          }
          if (!screenFilesReady(input, files, previewRoot, previewsBefore))
            throw new Error('состав загруженных файлов изменился перед отправкой — следующая группа остановлена');
          slog('  ▶ жму отправку «' + (sub.innerText || sub.value || '').replace(/\s+/g, ' ').trim().slice(0, 40) + '» (<' + sub.tagName.toLowerCase() + '>)');
          const t0 = Date.now();
          submitAt = t0;
          realClick(sub);
          // Переход/закрытие формы обязателен: очистка input и уведомление не означают создание действия.
          sent = await waitFor(() => {
            const txt = document.body.innerText;
            if (!formClosed()) return null;
            const cnt = (txt.match(/отчет по/gi) || []).length;
            if (cnt > baseCnt) return 'действие появилось в списке';
            if (netOkSince(t0)) return 'форма закрылась + сервер подтвердил';
            return null;
          }, 45000);
          if (!sent) {
            const ov = overlayRoot();
            throw new Error('нет подтверждения создания действия: ' + (formClosed() ? 'форма закрылась, но карточка не появилась и POST не подтверждён' : 'форма всё ещё открыта, кнопка не сработала'));
          }
          break;
        } catch (e) {
          lastErr = e;
          swarn('  ⚠ попытка ' + a + '/2: ' + e.message);
          // отправка могла уйти, а подтверждение «не досмотреть» — карточка в списке
          // появился? Только это честный сигнал, иначе ретрай зальёт действие повторно
          const txtNow = document.body.innerText;
          const cntNow = (txtNow.match(/отчет по/gi) || []).length;
          if (formClosed() && cntNow > baseCnt) { sent = 'подтверждение пришло с опозданием'; break; }
          if (filesAttached || e.noOpenRetry) break; // Не повторяем неясное участие или отправку файлов.
          await closeOverlay(); // не даём следующей попытке/группе прилипнуть к этой форме
          await sleep(1000 * a);
        }
      }

      if (sent) {
        pending.forEach(nm0 => done.add(nm0)); saveDone();
        if (lastInput) usedInputs.add(lastInput);
        // форма реально закрылась, прежде чем открываем следующую группу
        if (!formClosed()) throw new Error('форма не закрылась после создания действия — следующая группа остановлена');
        slog('  ✅ ' + label + ': ' + pending.length + ' файл(ов) — ' + sent);
        setStatus({ total, ok: done.size, fail: failCount, line: '✅ [' + (gi + 1) + '/' + grp.length + '] ' + label + ' (' + pending.length + ')' });
        await sleep(3000); // пауза между действиями — сайт должен успеть оформить предыдущее
      } else if (!STOP) {
        failCount += pending.length;
        serr('  ' + label + ' (' + pending.length + ')' + (lastErr ? ' — ' + lastErr.message : ''));
        setStatus({ total, ok: done.size, fail: failCount, line: '❌ [' + (gi + 1) + '/' + grp.length + '] ' + label + ' — ' + (lastErr && lastErr.message) });
        const manual = filesAttached && lastInput;
        if (manual) watchManualSubmit({ items: pending, input: lastInput, formClosed, clickedAt: submitAt, label });
        throw new Error('группа «' + label + '» не отправлена; следующая группа остановлена: ' + (lastErr && lastErr.message) +
          (manual ? '. Можно нажать отправку в форме вручную и потом «Продолжить» — эта группа не зальётся повторно' : ''));
      }
    }
  } finally {
    window.removeEventListener('beforeunload', guardUnload);
    document.removeEventListener('click', guardClick, true);
    screenStopClick();
  }

  const stopped = STOP;
  const mins = ((Date.now() - tStart) / 60000).toFixed(1);
  const line = stopped
    ? `⏹ скрины остановлено — залито ${done.size}/${total}`
    : `✅ скрины: залито ${done.size}/${total} за ${mins} мин, ошибок ${failCount}`;
  console.log('\n=== ' + line + ' ===');
  return { ok: !stopped && done.size === total && !failCount, stopped, okCount: done.size, failCount, line };
};

/* ============================================================
   ЗАПУСК / ОСТАНОВКА ЗАДАЧ
   ============================================================ */
let hideT = null;
const cleanup = () => { stealthOff(); keepAwakeOff(); };
const finish = line => {
  setStatus({ running: false, phase: 'done', line });
  clearTimeout(hideT);
  hideT = setTimeout(() => { if (!STATUS.running) { STATUS.phase = 'idle'; renderPanel(); } }, 15000);
  cleanup();
};

const startTask = (mode, opts) => {
  STOP = false; window.__stop = false;
  clearTimeout(hideT);
  setStatus({ running: true, mode, tabId: opts.tabId, phase: 'work', line: 'старт…', ok: 0, fail: 0, total: 0, skipped: 0, limitSkipped: 0, firstSuccessPerNetwork: false, error: null });
  if (mode !== 'okSearch') stealthOn();
  keepAwakeOn();
  const job = mode === 'parse'
    ? taskParse(Math.max(1, opts.limit | 0 || 1000))
    : mode === 'search'
      ? taskSearch(Math.max(1, opts.limit | 0 || 300), opts)
      : mode === 'okSearch'
        ? taskOkSearch(Math.max(1, Math.min(10000, opts.limit | 0 || 300)))
      : mode === 'like'
        ? taskLike(Math.max(1, opts.limit | 0 || 50), Math.max(100, opts.delay | 0 || 1200))
        : taskUpload(opts.links, Math.max(100, opts.delay | 0 || 800), opts.category, opts.firstSuccessPerNetwork === true);
  job.then(r => finish(r.line)).catch(e => {
    console.error(e);
    setStatus({ error: String((e && e.message) || e) });
    finish('⛔ ' + ((e && e.message) || e));
  });
};

/* Загрузка скринов отличается от других задач: background ЖДЁТ ответа
   (порт сообщения открыт до конца аккаунта — это же держит воркер живым),
   поэтому ответ приходит не сразу, а по завершении всей партии. */
const startScreensTask = msg => {
  STOP = false; window.__stop = false;
  clearTimeout(hideT);
  setStatus({ running: true, mode: 'screens', phase: 'work', line: 'старт…', ok: 0, fail: 0, total: msg.total | 0, error: null });
  stealthOn(); keepAwakeOn();
  return taskScreens(msg)
    .then(r => { finish(r.line); return r; })
    .catch(e => {
      console.error(e);
      setStatus({ error: String((e && e.message) || e) });
      finish('⛔ ' + ((e && e.message) || e));
      return { ok: false, error: String((e && e.message) || e), okCount: STATUS.ok || 0, failCount: STATUS.fail || 0 };
    });
};

/* Переключение аккаунтов ЕР полностью перенесено в background.js и работает
   через chrome.cookies (авторизация ВВЕРХ лежит в httpOnly-куках
   vverh_app_jwt / vverh_app_refresh на домене .er.ru, недоступных из JS).
   На вкладке остаётся только ping/stop/reset и задачи парсинга/заливки. */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'ping') { sendResponse({ ok: true, contentVersion: '1.4.5', screensVersion: '1.4.14', likeVersion: '1', okParserReady: !!globalThis.OkPostParser,
    okParserVersion: globalThis.OkPostParser?.version, status: STATUS }); return; }
  if (msg.type === 'okDiag') {
    if (location.hostname !== 'ok.ru' || !globalThis.OkPostParser?.diagnose) {
      sendResponse({ ok: false, business: true, error: 'Обнови расширение и вкладку ОК для диагностики' }); return;
    }
    try { sendResponse({ ok: true, diagnostics: globalThis.OkPostParser.diagnose(document) }); }
    catch (e) { sendResponse({ ok: false, business: true, error: e.message }); }
    return;
  }
  if (msg.type === 'virtualCursorDetached') {
    if (likeRunId === msg.runId) {
      likeDetachError = 'Управление курсором отключено (' + msg.reason + '). Запусти автолайк заново.';
      STOP = true; hideLikeCursor();
    }
    sendResponse({ ok: true }); return;
  }
  if (msg.type === 'stop') { STOP = true; window.__stop = true; stopLikeCursor(); screenStopClick(); sendResponse({ ok: true }); return; }
  if (msg.type === 'screensSettle') {
    // Фон спрашивает перед перезагрузкой вкладки: ручная отправка должна успеть сохраниться.
    if (!screensManualWatch) { sendResponse({ ok: true, confirmed: false }); return; }
    screensManualWatch.settle().then(r => sendResponse(Object.assign({ ok: true }, r)), () => sendResponse({ ok: false }));
    return true;
  }
  if (msg.type === 'reset') {
    // Кнопка «Сброс» на странице события чистит только это событие; вне события — всё.
    const ev = (location.pathname.match(/\/events\/(\d+)/) || [])[1] || null;
    resetUploadProgress(msg.all ? null : ev).then(() => sendResponse({ ok: true, status: STATUS, eventId: ev }));
    return true;
  }
  if (msg.type === 'parse' || msg.type === 'search' || msg.type === 'okSearch' || msg.type === 'upload' || msg.type === 'like') {
    if (STATUS.running) { sendResponse({ ok: false, business: true, error: 'На этой вкладке уже выполняется задача' }); return; }
    startTask(msg.type, msg);
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'screens') {
    if (STATUS.running) { sendResponse({ ok: false, business: true, error: 'На этой вкладке уже выполняется задача' }); return; }
    startScreensTask(msg).then(sendResponse);
    return true; // асинхронный ответ — по завершении всей партии
  }
});
