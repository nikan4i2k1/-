@echo off
:: Установка VK Liker Native Host для Chrome / Edge (Windows)
:: Регистрирует нативный хост кликов в реестре. Манифест и обёртка уже готовы.

setlocal EnableDelayedExpansion

set MANIFEST=%~dp0vk_liker_native.json
if not exist "%MANIFEST%" (
  echo [ОШИБКА] Не найден %MANIFEST%
  pause & exit /b 1
)

reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\vk_liker_native"   /ve /t REG_SZ /d "%MANIFEST%" /f >nul 2>&1 && echo [OK] Chrome: хост зарегистрирован || echo [WARN] Chrome: reg add не сработал
reg add "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\vk_liker_native" /ve /t REG_SZ /d "%MANIFEST%" /f >nul 2>&1 && echo [OK] Edge:  хост зарегистрирован || echo [WARN] Edge:  reg add не сработал

echo.
echo ============================================================
echo  Нативный хост кликов установлен.
echo  Перезапусти браузер полностью (все окна), затем открой
echo  стену ВК и нажми "Лайкать стену".
echo ============================================================
echo.
pause