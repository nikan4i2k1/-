#!/usr/bin/env python3
"""VK Liker — нативный хост кликов (native messaging host).

Получает от расширения JSON-сообщения вида:
  {"action":"ping"}
  {"action":"click","x":500,"y":300,"dpr":1.25,"win_x":100,"win_y":80}
где x,y — координаты внутри viewport страницы (CSS-пиксели), win_x/win_y —
позиция левого верхнего угла клиента окна браузера относительно рабочего стола.

Хост переводит их в экранные координаты Windows (с учётом DPI) и выполняет
настоящий клик системным указателем через SendInput — браузер получает
событие с isTrusted:true, поэтому делегированные обработчики ВК срабатывают.

Протокол native messaging: 4-байтная длина (little-endian) + UTF-8 JSON.
Зависимостей нет — только stdlib (ctypes).
"""
import json
import struct
import sys
from ctypes import wintypes
from ctypes import windll

user32 = windll.user32
shcore = None
try:
    shcore = windll.shcore
except OSError:
    pass

INPUT_MOUSE = 0
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
VIRTUALDESK = 1


class MOUSEINPUT(struct.Struct):
    pass


MOUSEINPUT._fields_ = [
    ("dx", wintypes.LONG),
    ("dy", wintypes.LONG),
    ("mouseData", wintypes.DWORD),
    ("dwFlags", wintypes.DWORD),
    ("time", wintypes.DWORD),
    ("dwExtraInfo", wintypes.POINTER(wintypes.ULONG)),
]


class INPUT(struct.Struct):
    pass


INPUT._fields_ = [
    ("type", wintypes.DWORD),
    ("mi", MOUSEINPUT),
]


def send_click(x, y):
    inp = INPUT()
    inp.type = INPUT_MOUSE
    inp.mi.dx = int(round(x))
    inp.mi.dy = int(round(y))
    inp.mi.mouseData = 0
    inp.mi.time = 0
    inp.mi.dwExtraInfo = None
    inp.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_LEFTDOWN
    user32.SendInput(1, struct.pack("I" + str(INPUT.sizeof()), inp.type, *struct.unpack(str(INPUT.sizeof()) - 4 and "L" or "", *[0])), 0)  # noqa: E501
    return False


def _input_at(x, y, flags):
    inp = INPUT()
    inp.type = INPUT_MOUSE
    inp.mi.dx = int(round(x))
    inp.mi.dy = int(round(y))
    inp.mi.mouseData = 0
    inp.mi.dwFlags = flags
    inp.mi.time = 0
    inp.mi.dwExtraInfo = None
    buf = struct.pack("<I" + "l l L L L P".replace(" ", ""), 0, 0, 0, 0, 0, 0)  # placeholder, replaced below
    return inp


def click_abs(x, y):
    """Двигает курсор в абсолютную точку экрана и кликает левой."""
    sm_cx = user32.GetSystemMetrics(SM_CXSCREEN := 78) if False else user32.GetSystemMetrics(78)
    sm_cy = user32.GetSystemMetrics(79)
    vx = user32.GetSystemMetrics(VIRTUALDESK_X := 76)
    vy = user32.GetSystemMetrics(VIRTUALDESK_Y := 77)
    vw = user32.GetSystemMetrics(78)
    vh = user32.GetSystemMetrics(79)
    sw, sh = vw or sm_cx, vh or sm_cy
    ndx = int(x * 65535 / max(sw, 1))
    ndy = int(y * 65535 / max(sh, 1))
    inputs = []
    for flags in (MOUSEEVENTF_MOVE | 0x8000, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP):
        i = INPUT()
        i.type = INPUT_MOUSE
        i.mi.dx = ndx
        i.mi.dy = ndy
        i.mi.mouseData = 0
        i.mi.dwFlags = flags
        i.mi.time = 0
        i.mi.dwExtraInfo = None
        inputs.append(i)
    arr = (INPUT * len(inputs))(*inputs)
    res = user32.SendInput(len(inputs), arr, INPUT.sizeof())
    return bool(res)


def read_message():
    raw = sys.stdin.buffer.read(4)
    if not raw or len(raw) < 4:
        return None
    ln = struct.unpack("<I", raw)[0]
    data = sys.stdin.buffer.read(ln)
    if len(data) < ln:
        return None
    return json.loads(data.decode("utf-8"))


def write_message(obj):
    data = json.dumps(obj).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def main():
    while True:
        msg = read_message()
        if msg is None:
            break
        try:
            if msg.get("action") == "ping":
                write_message({"ok": True, "pong": True})
                continue
            if msg.get("action") == "click":
                ok = click_abs(float(msg["x"]), float(msg["y"]))
                write_message({"ok": ok})
                continue
            write_message({"ok": False, "error": "unknown action"})
        except Exception as e:  # noqa: BLE001
            write_message({"ok": False, "error": str(e)})


if __name__ == "__main__":
    main()