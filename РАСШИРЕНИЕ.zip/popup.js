/* Панель управления. Задачи выполняются на вкладках и в service worker. */

const $ = id => document.getElementById(id);
let tabId = null;
let tabUrl = '';

/* Persistent panel follows its own browser window, not another focused window. */
let panelWindowId = null;
let tabQuerySequence = 0;
function refreshActiveTab() {
  const sequence = ++tabQuerySequence;
  const query = panelWindowId == null ? { active: true, currentWindow: true } :
    { active: true, windowId: panelWindowId };
  return new Promise(resolve => chrome.tabs.query(query, tabs => {
    if (sequence !== tabQuerySequence) return resolve();
    const t = tabs && tabs[0];
    if (t?.windowId != null) panelWindowId = t.windowId;
    tabId = t ? t.id : null;
    tabUrl = (t && t.url) || '';
    const target = $('targetTab');
    if (target) {
      target.textContent = t ? (t.title || tabUrl || 'Текущая вкладка') : 'Нет активной вкладки';
      target.title = tabUrl;
    }
    hint();
    resolve();
  }));
}
refreshActiveTab();
chrome.tabs.onActivated?.addListener(info => {
  if (panelWindowId == null || info.windowId === panelWindowId) refreshActiveTab();
});
chrome.tabs.onUpdated?.addListener((id, change) => {
  if (id === tabId && (change.url || change.title || change.status === 'complete')) refreshActiveTab();
});
chrome.tabs.onRemoved?.addListener(id => { if (id === tabId) refreshActiveTab(); });

const isOkTab = () => /^https:\/\/ok\.ru\//.test(tabUrl);
const isSupported = () => isOkTab() || /^https:\/\/(vk\.ru|vk\.com|m\.vk\.ru|m\.vk\.com|vverh-app\.er\.ru|[^/]+\.er\.ru)\//.test(tabUrl);

function hint() {
  const h = $('hint');
  if (!isSupported()) {
    h.textContent = '⚠ Открой ok.ru, поиск vk.ru/search/statuses, vk.ru/friends или событие vverh-app.er.ru/events/…';
    h.className = 'warn';
  } else if (isOkTab()) {
    h.textContent = '✓ ОК — «Парсить ОК» собирает посты людей прокруткой, без API.';
    h.className = '';
  } else if (/\/events\/\d+/.test(tabUrl)) {
    h.textContent = '✓ Страница события — можно заливать ссылки.';
    h.className = '';
  } else if (/\/search\//.test(tabUrl)) {
    h.textContent = '✓ Поиск ВК — можно парсить посты (вкладка «Посты»).';
    h.className = '';
  } else if (/\/friends/.test(tabUrl)) {
    h.textContent = '✓ Страница друзей — можно парсить.';
    h.className = '';
  } else if (/^https:\/\/(vk\.ru|vk\.com)\/([A-Za-z][A-Za-z0-9_.]{1,31}|id\d+|-?\d+)\/?$/.test(tabUrl)) {
    h.textContent = '✓ Стена группы / страницы — можно лайкать.';
    h.className = '';
  } else {
    h.textContent = 'Парсер постов — вкладка «Посты» в поиске ВК, парсер друзей — vk.ru/friends, автолайк — стена группы (vk.ru/…), заливка — страница события.';
    h.className = '';
  }
}

/* ---------- отправка команд на вкладку ---------- */
const rawSend = (msg, targetId = tabId) => new Promise(resolve => {
  chrome.tabs.sendMessage(targetId, msg, r => {
    if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
    else resolve(r || { ok: false, error: 'нет ответа от вкладки' });
  });
});

/* Скрипт может отсутствовать на вкладке, если она была открыта ДО установки
   или перезагрузки расширения. Тогда подключаем его на лету. */
const ensureInjected = async (targetId = tabId, targetUrl = tabUrl) => {
  const okTab = /^https:\/\/ok\.ru\//.test(targetUrl);
  const ping = await rawSend({ type: 'ping' }, targetId);
  if (ping.ok && ping.contentVersion === '1.4.5' && (!okTab || (ping.okParserReady && ping.okParserVersion === '1.4.2'))) return true;
  // Existing lexical content-script state is not safely replaceable in-place.
  if (ping.ok && (ping.contentVersion !== '1.4.5' || (okTab && ping.okParserVersion !== '1.4.2'))) return false;
  try {
    if (okTab) await chrome.scripting.executeScript({ target: { tabId: targetId }, files: ['ok_parser.js'] });
    if (!ping.ok) await chrome.scripting.executeScript({ target: { tabId: targetId }, files: ['content.js'] });
    if (!okTab) await chrome.scripting.executeScript({ target: { tabId: targetId }, files: ['stealth.js'], world: 'MAIN' }).catch(() => {});
    await new Promise(r => setTimeout(r, 200));
    const after = await rawSend({ type: 'ping' }, targetId);
    return after.ok && after.contentVersion === '1.4.5' && (!okTab || after.okParserVersion === '1.4.2');
  } catch (e) {
    return false;
  }
};

const send = async msg => {
  await refreshActiveTab();
  const targetId = tabId, targetUrl = tabUrl;
  if (targetId == null) return { ok: false, error: 'нет активной вкладки' };
  if ((msg.type === 'okSearch' || msg.type === 'okDiag') && !/^https:\/\/ok\.ru\//.test(targetUrl))
    return { ok: false, error: 'Открой нужную ленту или профиль на ok.ru' };
  if (msg.type === 'like' && !/^https:\/\/(vk\.ru|vk\.com)\//.test(targetUrl))
    return { ok: false, error: 'Открой стену группы или страницы на vk.ru' };
  // Freeze the target throughout asynchronous ping/injection/retry steps.
  if ('tabId' in msg) msg = { ...msg, tabId: targetId };
  if ((msg.type === 'upload' || (msg.type === 'search' && msg.thenUpload)) && !await ensureInjected(targetId, targetUrl)) {
    return { ok: false, business: true, error: 'Обнови вкладку после перезагрузки расширения для выбора категорий' };
  }
  if (msg.type === 'like') {
    if (!await ensureInjected(targetId, targetUrl)) return { ok: false, business: true, error: 'Обнови вкладку ВК (F5)' };
    const ping = await rawSend({ type: 'ping' }, targetId);
    if (ping.likeVersion !== '1') return { ok: false, business: true, error: 'Обнови вкладку ВК (F5) для виртуального курсора' };
  }
  let r = await rawSend(msg, targetId);
  if (r.ok || r.business) return r; // вкладка ответила содержательно — не трогаем транспорт
  if (!/^https:\/\/(ok\.ru|vk\.ru|vk\.com|m\.vk\.ru|m\.vk\.com|vverh-app\.er\.ru|[^/]+\.er\.ru)\//.test(targetUrl)) return { ok: false, error: 'Открой вкладку ВК, ok.ru или страницу события vverh-app.er.ru' };
  if (!await ensureInjected(targetId, targetUrl)) {
    return { ok: false, error: 'Скрипт не подключился к вкладке — обнови страницу (F5) и попробуй снова' };
  }
  r = await rawSend(msg, targetId);
  return r.ok || r.business ? r : { ok: false, error: 'Вкладка не ответила — обнови страницу (F5)' };
};

/* ---------- настройки (сохраняются) ---------- */
const DEFAULTS = { vkLimit: 1000, vkLimitSearch: 300, vkEventUrl: 'https://vverh-app.er.ru/events/74108', vkDelay: 800, vkLinks: '', vkLikeLimit: 50, vkLikeDelay: 1200, vkUploadCategory: 'auto', vkUploadCategoryCustom: '', vkFirstSuccessPerNetwork: false };
let draftBase = '';
let draftDirty = false;
let draftRevision = 0;
let draftSaveQueue = Promise.resolve();
let draftSavesPending = 0;
let draftStorageRevision = 0;
const draftSend = msg => new Promise(resolve => chrome.runtime.sendMessage(msg, response => {
  if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
  else resolve(response || { ok: false, error: 'нет ответа от фонового процесса' });
}));

const draftReady = chrome.storage.local.get(DEFAULTS).then(s => {
  $('limit').value = s.vkLimit;
  $('limitSearch').value = s.vkLimitSearch;
  $('eventUrl').value = s.vkEventUrl;
  $('delay').value = s.vkDelay;
  if (draftStorageRevision === 0) draftBase = String(s.vkLinks || '');
  if (!draftDirty && draftStorageRevision === 0) {
    draftBase = String(s.vkLinks || '');
    $('links').value = draftBase;
  }
  $('likeLimit').value = s.vkLikeLimit;
  $('likeDelay').value = s.vkLikeDelay;
  $('uploadCategory').value = s.vkUploadCategory;
  $('uploadCategoryCustom').value = s.vkUploadCategoryCustom;
  $('firstSuccessPerNetwork').checked = s.vkFirstSuccessPerNetwork === true;
  categoryUI();
});
const saveSettings = () => chrome.storage.local.set({
  vkLimit: parseInt($('limit').value) || 1000,
  vkLimitSearch: parseInt($('limitSearch').value) || 300,
  vkEventUrl: $('eventUrl').value.trim(),
  vkDelay: parseInt($('delay').value) || 800,
  vkLikeLimit: parseInt($('likeLimit').value) || 50,
  vkLikeDelay: parseInt($('likeDelay').value) || 1200,
  vkUploadCategory: $('uploadCategory').value,
  vkUploadCategoryCustom: $('uploadCategoryCustom').value.trim(),
  vkFirstSuccessPerNetwork: $('firstSuccessPerNetwork').checked === true
});
const saveDraft = () => {
  const input = $('links');
  const revision = draftRevision;
  const value = input.value;
  const selection = [input.selectionStart, input.selectionEnd];
  const dirty = draftDirty || value !== draftBase;
  draftSavesPending++;
  const work = async () => {
    await draftReady;
    // A settings change is not a textarea edit. Never replay a stale clean value.
    if (!dirty) {
      const current = String((await chrome.storage.local.get('vkLinks')).vkLinks || '');
      if (revision === draftRevision && !draftDirty) {
        draftBase = current;
        input.value = current;
      }
      return { ok: true, value: current };
    }
    const result = await draftSend({ type: 'uploadDraftSet', value, base: draftBase });
    if (!result.ok) return result;
    if (revision !== draftRevision) {
      // The acknowledgement belongs to text which the user has already changed.
      // Advance the merge base only to text actually submitted, never replace newer input.
      draftBase = value;
      return result;
    }
    draftBase = String(result.value || '');
    draftDirty = false;
    if (input.value !== draftBase) {
      input.value = draftBase;
      if (document.activeElement === input && selection[0] != null) {
        const end = input.value.length;
        input.setSelectionRange(Math.min(selection[0], end), Math.min(selection[1], end));
      }
    }
    return result;
  };
  const pending = draftSaveQueue.then(work, work).finally(() => { draftSavesPending--; });
  draftSaveQueue = pending.catch(() => {});
  return pending;
};
const mergeDraftLinks = async links => {
  const saved = await saveDraft();
  if (!saved?.ok) return saved || { ok: false, error: 'не удалось сохранить текущий черновик' };
  const revision = draftRevision;
  const result = await draftSend({ type: 'uploadDraftMerge', links });
  if (result.ok && revision === draftRevision && !draftDirty) {
    draftBase = String(result.value || '');
    $('links').value = draftBase;
  }
  return result;
};
const save = () => Promise.all([saveSettings(), saveDraft()]);
['limit', 'limitSearch', 'eventUrl', 'delay', 'likeLimit', 'likeDelay'].forEach(id => $(id).addEventListener('change', save));
function categoryUI() { $('uploadCategoryCustomWrap').hidden = $('uploadCategory').value !== 'custom'; }
function uploadCategorySettings() {
  const category = { mode: $('uploadCategory').value || 'auto', custom: $('uploadCategoryCustom').value.trim() };
  if (category.mode === 'custom' && !category.custom) throw new Error('Введи точное название категории');
  return category;
}
$('firstSuccessPerNetwork').addEventListener('change', save);
$('uploadCategory').addEventListener('change', () => { categoryUI(); save(); });
$('uploadCategoryCustom').addEventListener('input', save);
let saveT = null;
$('links').addEventListener('input', () => {
  draftDirty = true;
  draftRevision++;
  clearTimeout(saveT);
  saveT = setTimeout(saveDraft, 400);
});

/* ---------- кнопки ---------- */
chrome.storage.local.get({ okLimit: 300 }).then(s => { $('okLimit').value = s.okLimit; });
$('okLimit').addEventListener('change', () => chrome.storage.local.set({ okLimit: Math.max(1, Math.min(10000, Number($('okLimit').value) || 300)) }));
$('okStartBtn').onclick = async () => {
  await refreshActiveTab();
  if (!isOkTab()) return setStatusText('Открой нужную ленту или профиль на ok.ru', true);
  // Reloaded extensions can attach to a tab which was already open.
  if (!await ensureInjected()) return setStatusText('Обнови вкладку ОК после перезагрузки расширения', true);
  const limit = Math.max(1, Math.min(10000, Number($('okLimit').value) || 300));
  await chrome.storage.local.set({ okLimit: limit });
  const r = await send({ type: 'okSearch', limit, tabId });
  setStatusText(r.ok ? 'ОК: парсер запущен — попап можно закрыть' : (r.error || 'Ошибка запуска ОК'), !r.ok);
};
$('okStopBtn').onclick = async () => {
  const s = await chrome.storage.local.get('okParseStatus');
  if (s.okParseStatus?.tabId != null) await chrome.tabs.sendMessage(s.okParseStatus.tabId, { type: 'stop' }).catch(() => {});
  else {
    await refreshActiveTab();
    if (isOkTab()) await rawSend({ type: 'stop' });
  }
};
const okResultLinks = async () => ((await chrome.storage.local.get('okParseResult')).okParseResult?.links || []);
$('okDiagBtn').onclick = async () => {
  await refreshActiveTab();
  if (!isOkTab()) return setStatusText('Открой проблемную ленту на ok.ru', true);
  if (!await ensureInjected()) return setStatusText('Обнови расширение и вкладку ОК для новой диагностики', true);
  const r = await send({ type: 'okDiag' });
  if (!r.ok) return setStatusText(r.error || 'Ошибка диагностики ОК', true);
  await chrome.storage.local.set({ okParseDiagnostics: r.diagnostics });
  const url = URL.createObjectURL(new Blob([JSON.stringify(r.diagnostics, null, 2)], { type: 'application/json;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = 'ok_parser_diagnostics.json'; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setStatusText(`Диагностика сохранена: карточек ${r.diagnostics.cards}, распознано ${r.diagnostics.recognized}, не распознано ${r.diagnostics.unresolved}`);
};
$('okCopyBtn').onclick = async () => {
  const links = await okResultLinks();
  if (!links.length) return setStatusText('ОК: пока нет собранных ссылок');
  try { await navigator.clipboard.writeText(links.join('\n')); setStatusText(`ОК: скопировано ${links.length} ссылок`); }
  catch (e) { setStatusText('Ошибка копирования: ' + e.message, true); }
};
$('okDownloadBtn').onclick = async () => {
  const links = await okResultLinks();
  if (!links.length) return setStatusText('ОК: пока нет собранных ссылок');
  const url = URL.createObjectURL(new Blob([links.join('\n')], { type: 'text/plain;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = `ok_people_posts_${links.length}.txt`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
$('okToLinksBtn').onclick = async () => {
  const links = await okResultLinks();
  if (!links.length) return setStatusText('⛔ Пока нет результатов ОК', true);
  const result = await mergeDraftLinks(links);
  if (!result.ok) return setStatusText('⛔ ' + (result.error || 'не удалось добавить ссылки'), true);
  window.PanelUI?.selectView('upload');
  $('links').focus();
};

const storedLinks = async key => ((await chrome.storage.local.get(key))[key]?.links || []);
const downloadStoredLinks = async (key, prefix, label) => {
  const links = await storedLinks(key);
  if (!links.length) return setStatusText(`${label}: пока нет результатов`, true);
  const url = URL.createObjectURL(new Blob([links.join('\n') + '\n'], { type: 'text/plain;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = `${prefix}_${links.length}.txt`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  setStatusText(`⬇ Скачано ${links.length} ссылок (${label})`);
};
if ($('searchDownloadBtn')) $('searchDownloadBtn').onclick = () => downloadStoredLinks('vkSearchResult', 'vk_posts', 'ВК');
if ($('friendsDownloadBtn')) $('friendsDownloadBtn').onclick = () => downloadStoredLinks('vkFriendsResult', 'vk_friends', 'друзья ВК');

$('parseBtn').onclick = async () => {
  save();
  const r = await send({ type: 'parse', limit: parseInt($('limit').value) || 1000 });
  if (!r.ok) setStatusText('⛔ ' + (r.error || 'не удалось запустить'), true);
};

$('searchBtn').onclick = async () => {
  save();
  const r = await send({ type: 'search', limit: parseInt($('limitSearch').value) || 300 });
  if (!r.ok) setStatusText('⛔ ' + (r.error || 'не удалось запустить'), true);
};

$('searchUpBtn').onclick = async () => {
  save();
  let category;
  try { category = uploadCategorySettings(); } catch (e) { return setStatusText(e.message, true); }
  const eventUrl = $('eventUrl').value.trim();
  if (!/^https:\/\/[^/]+\/events\/\d+/.test(eventUrl)) return setStatusText('⛔ Проверь URL события (…/events/число)', true);
  const r = await send({
    type: 'search',
    limit: parseInt($('limitSearch').value) || 300,
    thenUpload: true, eventUrl, category, firstSuccessPerNetwork: $('firstSuccessPerNetwork').checked === true,
    delay: parseInt($('delay').value) || 800
  });
  if (!r.ok) setStatusText('⛔ ' + (r.error || 'не удалось запустить'), true);
};

$('likeBtn').onclick = async () => {
  save();
  await refreshActiveTab();
  if (!/^https:\/\/(vk\.ru|vk\.com)\//.test(tabUrl)) return setStatusText('⛔ Открой стену группы или страницы на vk.ru (например vk.ru/er_bgo)', true);
  const r = await send({
    type: 'like',
    limit: parseInt($('likeLimit').value) || 50,
    delay: parseInt($('likeDelay').value) || 1200
  });
  if (!r.ok) setStatusText('⛔ ' + (r.error || 'не удалось запустить'), true);
};

$('uploadBtn').onclick = async () => {
  // Сохранение черновика идёт отдельно; запуск заливки использует текущее поле.
  save().catch(() => {});
  let category;
  try { category = uploadCategorySettings(); } catch (e) { return setStatusText(e.message, true); }
  const links = $('links').value.split(/[\s,]+/).map(s => s.trim()).filter(s => /^https?:\/\//i.test(s));
  if (!links.length) return setStatusText('⛔ Вставь ссылки в поле (полные https://…)', true);
  const r = await send({ type: 'upload', links: $('links').value, category, firstSuccessPerNetwork: $('firstSuccessPerNetwork').checked === true, delay: parseInt($('delay').value) || 800 });
  if (!r.ok) setStatusText('⛔ ' + (r.error || 'не удалось запустить'), true);
};

/* «Стоп» шлём во все вкладки: при цепочке парсер и заливка живут на разных вкладках;
   плюс — в background, чтобы остановить цепочку скринов (он сам оповестит вкладки) */
$('stopBtn').onclick = async () => {
  bgSend({ type: 'screensStop' }).catch(() => {});
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    try { chrome.tabs.sendMessage(t.id, { type: 'stop' }, () => void chrome.runtime.lastError); } catch (e) {}
  }
};
$('resetBtn').onclick = async () => { const r = await send({ type: 'reset' }); if (r.ok) setStatusText('🧹 Прогресс заливки сброшен'); };

$('fileBtn').onclick = () => $('file').click();
$('file').onchange = () => {
  const f = $('file').files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    $('links').value = String(reader.result || '');
    draftDirty = true;
    draftRevision++;
    save();
  };
  reader.readAsText(f);
  $('file').value = '';
};

/* ---------- база залитых ссылок (общая для всех событий) ---------- */
const DB_KEY = 'vkUploadedDb';
const dbNorm = u => String(u || '').trim().toLowerCase()
  .replace(/^http:/, 'https:').replace(/[?#].*$/, '').replace(/\/+$/, '');
const dbGet = async () => (await chrome.storage.local.get({ [DB_KEY]: [] }))[DB_KEY] || [];
const dbSet = async arr => chrome.storage.local.set({ [DB_KEY]: arr });
const dbRender = async () => { $('dbCount').textContent = `В базе: ${(await dbGet()).length} ссылок`; };
dbRender();
setInterval(dbRender, 2000);

$('dbSaveBtn').onclick = async () => {
  const a = await dbGet();
  if (!a.length) return setStatusText('База пуста — скачивать нечего');
  const url = URL.createObjectURL(new Blob([a.join('\n')], { type: 'text/plain;charset=utf-8' }));
  const el = document.createElement('a');
  el.href = url; el.download = `uploaded_links_${a.length}.txt`;
  document.body.appendChild(el); el.click(); el.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  setStatusText(`⬇ Скачано ${a.length} ссылок из базы`);
};

$('dbClearBtn').onclick = async () => {
  const n = (await dbGet()).length;
  if (n && !confirm(`Очистить базу (${n} ссылок)? После этого она будет заполняться заново.`)) return;
  await dbSet([]);
  await dbRender();
  setStatusText('🧹 База залитых ссылок очищена');
};

$('dbImportBtn').onclick = () => $('dbFile').click();
$('dbFile').onchange = () => {
  const f = $('dbFile').files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = async () => {
    const add = String(reader.result).split(/[\s,]+/).map(dbNorm).filter(s => /^https?:\/\//i.test(s));
    const set = new Set(await dbGet());
    const before = set.size;
    add.forEach(u => set.add(u));
    await dbSet([...set]);
    await dbRender();
    setStatusText(`🗃 Добавлено в базу: ${set.size - before} (всего ${set.size})`);
  };
  reader.readAsText(f);
  $('dbFile').value = '';
};

/* ============================================================
   ПЕРЕКЛЮЧАТЕЛЬ АККАУНТОВ ЕР (vverh-app.er.ru / *.er.ru)
   Авторизация сайта — в httpOnly-куках vverh_app_jwt / vverh_app_refresh
   на домене .er.ru, поэтому переключение идёт через background.js
   (chrome.cookies), а не через хранилище вкладки.
   Аккаунты хранятся в chrome.storage.local['erAccounts'] как массив:
     [{ id, name, token, refresh?, jwtExp?, refreshExp?, active? }]
   ============================================================ */
const ER_KEY = 'erAccounts';
const isErTab = () => /^https:\/\/[^/]*\.?er\.ru\//i.test(tabUrl);

const erGetList = async () => (await chrome.storage.local.get({ [ER_KEY]: [] }))[ER_KEY] || [];
const erSetList = async arr => chrome.storage.local.set({ [ER_KEY]: arr });
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

const erAgo = t => {
  const m = Math.max(0, Math.round((Date.now() - t) / 60000));
  return m < 60 ? m + 'м' : m < 1440 ? Math.round(m / 60) + 'ч' : Math.round(m / 1440) + 'д';
};

/* автопродление сессий: настройки + последний прогон */
async function erBgRefreshInfo() {
  if (!$('erBgInfo')) return;
  const r = await bgSend({ type: 'erBgGet' });
  if (!r || !r.ok) { $('erBgInfo').textContent = 'автопродление: нет связи с фоном'; return; }
  $('erBgOn').checked = !!r.settings.enabled;
  $('erBgPeriod').value = String(r.settings.periodMin);
  $('erBgPeriod').disabled = !r.settings.enabled;
  const L = r.last, parts = [];
  if (r.running) parts.push('▶ продлеваю…');
  if (L) parts.push(`последний раз ${erAgo(L.finishedAt || L.at)} назад: продлено ${L.refreshed}, действуют без продления ${L.verified || 0}, ошибок ${L.failed}` +
    (L.needLogin ? `, нужен вход: ${L.needLogin}` : '') + (L.note ? ` (${L.note})` : ''));
  if (r.settings.enabled && r.next) parts.push('следующий ~' + new Date(r.next).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }));
  if (!r.settings.enabled) parts.push('выключено: неактивные аккаунты продлеваются только при переключении');
  $('erBgInfo').textContent = parts.join(' · ') || '—';
}
if ($('erBgOn') && $('erBgPeriod') && $('erBgNowBtn')) {
$('erBgOn').onchange = async () => { await bgSend({ type: 'erBgSet', enabled: $('erBgOn').checked }); erBgRefreshInfo(); };
$('erBgPeriod').onchange = async () => { await bgSend({ type: 'erBgSet', periodMin: Number($('erBgPeriod').value) }); erBgRefreshInfo(); };
$('erBgNowBtn').onclick = async () => {
  $('erBgNowBtn').disabled = true; $('erBgInfo').textContent = '▶ продлеваю все аккаунты…';
  try {
    const r = await bgSend({ type: 'erBgNow' });
    if (!r || !r.ok) setStatusText('⛔ Продление: ' + ((r && r.error) || 'нет ответа'), true);
    else if (r.report && r.report.ok === false) setStatusText('⛔ Продление: ' + r.report.error, true);
    else setStatusText(`🔄 Продлено: ${r.report.refreshed}, действуют без продления: ${r.report.verified || 0}, ошибок: ${r.report.failed}` + (r.report.needLogin ? `, нужен вход: ${r.report.needLogin}` : ''));
  } finally { $('erBgNowBtn').disabled = false; erBgRefreshInfo(); erRender(); }
};
}

async function erRender() {
  const list = await erGetList();
  const box = $('erList');
  if (!list.length) { box.innerHTML = '<span style="color:#8a8f99">пока пусто</span>'; return; }
  box.innerHTML = '';
  for (const a of list) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:6px;margin-top:4px;padding:5px 7px;' +
      'background:' + (a.active ? '#2a3a52' : '#1b1d22') + ';border:1px solid ' + (a.active ? '#2d81e0' : '#34383f') +
      ';border-radius:6px;cursor:pointer';
    const dot = document.createElement('span');
    dot.style.cssText = 'width:8px;height:8px;border-radius:50%;flex:0 0 auto;background:' + (a.active ? '#4caf50' : '#555');
    const nm = document.createElement('span');
    nm.style.cssText = 'flex:1;color:#e8e8ea;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    nm.textContent = a.name || '(без имени)';
    nm.title = 'Двойной клик — переименовать';
    nm.ondblclick = e => { e.stopPropagation(); erRename(a.id, nm); };
    const ren = document.createElement('button');
    ren.className = 'ghost'; ren.textContent = '✎';
    ren.style.cssText = 'font-size:11px;padding:2px 6px;flex:0 0 auto';
    ren.title = 'Переименовать аккаунт';
    ren.onclick = e => { e.stopPropagation(); erRename(a.id, nm); };
    const del = document.createElement('button');
    del.className = 'danger'; del.textContent = '✕';
    del.style.cssText = 'font-size:10px;padding:2px 6px;flex:0 0 auto';
    del.title = 'Удалить аккаунт';
    del.onclick = e => { e.stopPropagation(); erDelete(a.id); };
    const bg = document.createElement('span');
    bg.style.cssText = 'font-size:10px;flex:0 0 auto;color:' + (a.needsLogin ? '#f1707a' : (a.bgRefreshError || a.authWarning) ? '#e8b74a' : '#6c7280');
    if (a.needsLogin) { bg.textContent = 'Вход'; bg.title = a.bgRefreshError || a.authError || 'Сайт не подтвердил доступ и продление; нужен новый вход'; }
    else if (a.bgRefreshError) { bg.textContent = '⚠'; bg.title = 'Автопродление: ' + a.bgRefreshError; }
    else if (a.authWarning) { bg.textContent = '✓ ⚠'; bg.title = a.authWarning; }
    else if (a.lastAuthVerifiedAt > (a.lastAuthRefreshAt || 0)) { bg.textContent = '✓ ' + erAgo(a.lastAuthVerifiedAt); bg.title = 'Доступ проверен сайтом ' + new Date(a.lastAuthVerifiedAt).toLocaleString('ru-RU'); }
    else if (a.lastAuthRefreshAt) { bg.textContent = '⟳ ' + erAgo(a.lastAuthRefreshAt); bg.title = 'Сессия продлена ' + new Date(a.lastAuthRefreshAt).toLocaleString('ru-RU'); }
    row.append(dot, nm, bg, ren, del);
    row.onclick = () => erSwitchTo(a.id);
    box.appendChild(row);
  }
}

async function erAdd() {
  const name = $('erName').value.trim();
  const token = $('erToken').value.trim();
  const refresh = $('erRefresh').value.trim();
  if (!token) return setStatusText('⛔ Вставь access-токен (значение куки vverh_app_jwt)', true);
  if (!/^eyJ[A-Za-z0-9_-]+\./.test(token))
    setStatusText('⚠ Похоже, это не JWT. Убедись, что скопировал значение куки vverh_app_jwt целиком.', false);
  const acc = { id: uid(), name: name || 'Аккаунт ' + ((await erGetList()).length + 1), token, refresh };
  const list = await erGetList();
  list.push(acc);
  await erSetList(list);
  $('erName').value = ''; $('erToken').value = ''; $('erRefresh').value = '';
  await erRender();
  setStatusText(`✅ Аккаунт «${acc.name}» добавлен`);
}

/* переименование: превращаем span в input прямо в строке списка */
function erRename(id, nmEl) {
  if (nmEl.tagName === 'INPUT') return;
  const list0 = nmEl.textContent;
  const inp = document.createElement('input');
  inp.type = 'text';
  inp.value = list0 === '(без имени)' ? '' : list0;
  inp.style.cssText = 'flex:1;background:#17181c;color:#e8e8ea;border:1px solid #71aaeb;border-radius:4px;padding:2px 5px;font:inherit;min-width:0';
  nmEl.replaceWith(inp);
  inp.focus(); inp.select();
  let done = false;
  const commit = async save => {
    if (done) return; done = true;
    const val = save ? inp.value.trim() : '';
    const span = document.createElement('span');
    span.style.cssText = 'flex:1;color:#e8e8ea;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    span.textContent = val || '(без имени)';
    span.title = 'Двойной клик — переименовать';
    span.ondblclick = e => { e.stopPropagation(); erRename(id, span); };
    inp.replaceWith(span);
    if (!save || !val || val === list0) return;
    const list = await erGetList();
    const acc = list.find(a => a.id === id);
    if (acc) { acc.name = val; await erSetList(list); setStatusText(`✎ Аккаунт переименован в «${val}»`); }
  };
  inp.onkeydown = e => {
    if (e.key === 'Enter') commit(true);
    else if (e.key === 'Escape') commit(false);
  };
  inp.onblur = () => commit(true);
}

async function erDelete(id) {
  let list = await erGetList();
  const acc = list.find(a => a.id === id);
  if (acc && !confirm(`Удалить аккаунт «${acc.name}»? Токен будет потерян из расширения.`)) return;
  list = list.filter(a => a.id !== id);
  await erSetList(list);
  await erRender();
  setStatusText('🗑 Аккаунт удалён');
}

/* ============================================================
   ПЕРЕКЛЮЧАТЕЛЬ АККАУНТОВ ЕР — через chrome.cookies (background)
   Авторизация ВВЕРХ лежит в httpOnly-куках vverh_app_jwt /
   vverh_app_refresh на домене .er.ru. Доступ к ним есть только у
   background-скрипта, поэтому попап шлёт команды туда через
   chrome.runtime.sendMessage, а не на вкладку.
   ============================================================ */
const bgSend = msg => new Promise(resolve => {
  try { chrome.runtime.sendMessage(msg, r => resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : (r || { ok: false, error: 'нет ответа от фона' }))); }
  catch (e) { resolve({ ok: false, error: String(e && e.message || e) }); }
});

/* ---------- парсер постов через VK API ---------- */
const localDate = () => {
  const d = new Date();
  return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0')].join('-');
};
const apiFields = ['apiQuery', 'apiFrom', 'apiTo', 'apiLimit', 'apiOnlyPeople'];
chrome.storage.local.get({ vkApiOptions: { query: '', from: localDate(), to: localDate(), limit: 300, onlyPeople: true } }).then(s => {
  const o = s.vkApiOptions;
  $('apiQuery').value = o.query || '';
  $('apiFrom').value = o.from || localDate();
  $('apiTo').value = o.to || localDate();
  $('apiLimit').value = o.limit || 300;
  $('apiOnlyPeople').checked = o.onlyPeople !== false;
});
const apiOptions = () => ({ query: $('apiQuery').value.trim(), from: $('apiFrom').value,
  to: $('apiTo').value, limit: Number($('apiLimit').value), onlyPeople: $('apiOnlyPeople').checked });
const saveApiOptions = () => chrome.storage.local.set({ vkApiOptions: apiOptions() });
apiFields.forEach(id => $(id).addEventListener('change', saveApiOptions));

$('apiStartBtn').onclick = async () => {
  const token = $('apiToken').value.trim();
  const options = apiOptions();
  if (!token) return setStatusText('⛔ Введи access-токен VK API', true);
  if (!options.query || !options.from || !options.to || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 10000)
    return setStatusText('⛔ Укажи запрос, даты и количество от 1 до 10000', true);
  await saveApiOptions();
  const r = await bgSend({ type: 'vkApiStart', token, ...options });
  $('apiToken').value = '';
  setStatusText(r.ok ? '▶ API-парсер запущен; результат появится ниже' : '⛔ ' + (r.error || 'не удалось запустить'), !r.ok);
};
$('apiStopBtn').onclick = async () => {
  const r = await bgSend({ type: 'vkApiStop' });
  if (r.ok) setStatusText('⏹ Останавливаю API-парсер…');
};
const apiLinks = async () => {
  const s = await chrome.storage.local.get('vkApiParseResult');
  return (s.vkApiParseResult && s.vkApiParseResult.links) || [];
};
$('apiCopyBtn').onclick = async () => {
  const links = await apiLinks();
  if (!links.length) return setStatusText('⛔ Пока нет результатов API-парсера', true);
  try { await navigator.clipboard.writeText(links.join('\n')); setStatusText(`Скопировано ${links.length} ссылок`); }
  catch (e) { setStatusText('⛔ Не удалось скопировать: ' + e.message, true); }
};
$('apiDownloadBtn').onclick = async () => {
  const links = await apiLinks();
  if (!links.length) return setStatusText('⛔ Пока нет результатов API-парсера', true);
  const url = URL.createObjectURL(new Blob([links.join('\n') + '\n'], { type: 'text/plain;charset=utf-8' }));
  const el = document.createElement('a');
  el.href = url; el.download = `vk_api_posts_${links.length}.txt`;
  document.body.appendChild(el); el.click(); el.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  setStatusText(`⬇ Скачано ${links.length} ссылок`);
};
$('apiToUploadBtn').onclick = async () => {
  const links = await apiLinks();
  if (!links.length) return setStatusText('⛔ Пока нет результатов API-парсера', true);
  const result = await mergeDraftLinks(links);
  if (!result.ok) return setStatusText('⛔ ' + (result.error || 'не удалось добавить ссылки'), true);
  window.PanelUI?.selectView('upload');
  $('links').focus();
  setStatusText(`В поле заливки добавлено ${result.added} из ${links.length} ссылок`);
};

let erSwitchBusy = false;
async function erSwitchTo(id) {
  if (erSwitchBusy) return;
  erSwitchBusy = true;
  setStatusText('🔄 Переключаю аккаунт и проверяю сессию…');
  try {
    const r = await bgSend({ type: 'erSwitchBg', id });
    await erRender();
    if (!r.ok) return setStatusText('⛔ ' + (r.error || 'переключение не подтверждено'), true);
    setStatusText(r.applied?.warning ? `⚠ Аккаунт «${r.name}» применён · ${r.applied.warning}`
      : r.refreshed ? `✅ Аккаунт «${r.name}»: куки обновлены${r.reload ? ', вкладка перезагружена' : ''}`
      : r.applied?.refresh ? `✅ Аккаунт «${r.name}» применён · сессия действующая, лишнее продление не требуется${r.reload ? ', вкладка перезагружена' : ''}`
      : `✅ Аккаунт «${r.name}» применён · refresh отсутствует, автоматическое продление требует входа на сайт`);
  } finally { erSwitchBusy = false; }
}

async function erDetect() {
  const r = await bgSend({ type: 'erDetectBg' });
  if (!r.ok) return setStatusText('⛔ ' + (r.error || 'не удалось определить'), true);
  await renderScheme();
  if (!r.hasJwt) return setStatusText('⛔ Кука vverh_app_jwt не найдена — ты не залогинен ни в одном аккаунте er.ru', true);
  let msg = '🎯 Куки авторизации найдены: ' + (r.found || []).map(f => f.kind + '(' + f.name + ')').join(', ');
  const j = (r.found || []).find(f => f.kind === 'access');
  if (j && j.jwtExp) msg += `, доступ до ${new Date(j.jwtExp * 1000).toLocaleString('ru-RU')}`;
  setStatusText(msg);
}

async function renderScheme() {
  const el = $('erScheme');
  if (!el) return;
  const r = await bgSend({ type: 'erDetectBg' });
  if (!r.ok || !r.hasJwt) {
    el.textContent = 'куки авторизации не найдены — войди в любой аккаунт er.ru и нажми «🎯 Проверить куки»';
    el.style.color = '#e8b74a';
    return;
  }
  const kinds = (r.found || []).map(f => f.kind);
  el.textContent = '✓ схема: httpOnly-куки на .er.ru (' + kinds.join(' + ') + ')' + (kinds.includes('refresh') ? '' : ' · ⚠ refresh отсутствует');
  el.style.color = '#4caf50';
}

async function erHarvest() {
  const r = await bgSend({ type: 'erHarvestBg', save: true, name: ($('erHarvestName').value || '').trim() });
  if (!r.ok) return setStatusText('⛔ ' + (r.error || 'чтение куки не подтверждено'), true);
  await erRender();
  $('erHarvestName').value = '';
  let msg = r.updated ? `✓ Аккаунт «${r.name}»: свежие куки сохранены` : `📤 Забран «${r.name}»`;
  if (r.exp) msg += ` (доступ до ${new Date(r.exp * 1000).toLocaleDateString('ru-RU')})`;
  if (!r.refresh) msg += ' · refresh отсутствует';
  setStatusText(msg);
}

chrome.storage?.onChanged?.addListener((changes, area) => {
  if (area === 'local' && changes.vkLinks) {
    draftStorageRevision++;
    if (!draftDirty && !draftSavesPending) {
      draftBase = String(changes.vkLinks.newValue || '');
      if ($('links').value !== draftBase) $('links').value = draftBase;
    }
  }
  if (area === 'local' && changes[ER_KEY]) erRender().catch(() => {});
  if (area === 'local' && (changes.erBgRefreshState || changes.erBgRefreshSettings)) erBgRefreshInfo().catch(() => {});
});

/* ---------- экспорт / импорт списка аккаунтов (.json) ---------- */
async function erExport() {
  const snapshot = await bgSend({ type: 'erExportAccountsBg' });
  if (!snapshot.ok) return setStatusText('⛔ Экспорт: ' + (snapshot.error || 'чтение сессий не подтверждено'), true);
  const list = snapshot.accounts;
  if (!list.length) return setStatusText('⛔ Список аккаунтов пуст — сначала «Забрать с этой вкладки»', true);
  const data = JSON.stringify({ version: snapshot.version, exportedAt: snapshot.exportedAt, accounts: list }, null, 2);
  const url = URL.createObjectURL(new Blob([data], { type: 'application/json;charset=utf-8' }));
  const el = document.createElement('a');
  el.href = url; el.download = `er_accounts_${list.length}_${Date.now()}.json`;
  document.body.appendChild(el); el.click(); el.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  setStatusText(`⬇ Экспортировано ${list.length} аккаунтов. Файл содержит живые токены — храни его в безопасности и удали после переноса.`);
}

function erImport() { $('erImportFile').click(); }

$('erImportFile').onchange = () => {
  const f = $('erImportFile').files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const parsed = JSON.parse(String(reader.result));
      const incoming = Array.isArray(parsed) ? parsed : (parsed && parsed.accounts);
      if (!Array.isArray(incoming)) throw new Error('в файле нет массива accounts');
      const result = await bgSend({ type: 'erImportAccountsBg', accounts: incoming });
      if (!result.ok) throw new Error(result.error || 'сохранение аккаунтов не подтверждено');
      await erRender();
      setStatusText(`📎 Импорт: добавлено ${result.added}, обновлено ${result.updated}${result.skippedOlder ? `, старых версий пропущено ${result.skippedOlder}` : ''}. Всего в списке: ${result.total}`);
    } catch (e) {
      setStatusText('⛔ Импорт не удался: ' + (e && e.message || e), true);
    }
  };
  reader.readAsText(f);
  $('erImportFile').value = '';
};

$('erHarvestBtn').onclick = erHarvest;
$('erExportBtn').onclick = erExport;
$('erImportBtn').onclick = erImport;
$('erAddBtn').onclick = erAdd;
$('erDetectBtn').onclick = erDetect;
erRender();
renderScheme();
setInterval(erRender, 3000);

/* ============================================================
   СКРИНШОТЫ ДЛЯ СОБЫТИЯ
   Попап: выбор локальной папки (File System Access API), кэш
   картинок в IndexedDB background, запуск цепочки «скрины
   события на все аккаунты». Сама цепочка живёт в background /
   на вкладке — попап можно закрыть в любой момент.
   Имя файла = имя соцсети + порядковый номер: vk1.png…vk6.png,
   ok1.png…ok3.png — сколько найдено, столько и заливается.
   ============================================================ */
const SC_IMG_EXT = new Set(['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'avif']);
const scDefaults = { vkScreensOrder: '', vkScreensSingle: false, vkScreensFromCurrent: true, vkScreensRestore: false, vkScreensRecurse: false };
chrome.storage.local.get(scDefaults).then(s => {
  $('scOrder').value = s.vkScreensOrder;
  $('scSingle').checked = !!s.vkScreensSingle;
  $('scFromCurrent').checked = !!s.vkScreensFromCurrent;
  $('scRestore').checked = !!s.vkScreensRestore;
  $('scRecurse').checked = !!s.vkScreensRecurse;
  renderScMeta();
});
const scSave = () => chrome.storage.local.set({
  vkScreensOrder: $('scOrder').value.trim(),
  vkScreensSingle: !!$('scSingle').checked,
  vkScreensFromCurrent: !!$('scFromCurrent').checked,
  vkScreensRestore: !!$('scRestore').checked,
  vkScreensRecurse: !!$('scRecurse').checked
});
['scOrder', 'scSingle', 'scFromCurrent', 'scRestore', 'scRecurse'].forEach(id => $(id).addEventListener('change', scSave));

const bufToB64 = buf => {
  const u = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
};

let scAbMode = true;   // проходим ли ArrayBuffer прямо в runtime-сообщениях (проверяем зондом)
let scProbed = false;
let scBusy = false;

const scExtOf = name => (name.split('.').pop() || '').toLowerCase();
async function scWalk(handle, out, depth, maxDepth, prefix = '') {
  for await (const [name, h] of handle.entries()) {
    if (h.kind === 'directory') {
      if (depth < maxDepth) await scWalk(h, out, depth + 1, maxDepth, prefix + name + '/');
      continue;
    }
    if (SC_IMG_EXT.has(scExtOf(name))) {
      const f = await h.getFile();
      out.push({ name: prefix + name, size: f.size, mtime: f.lastModified, handle: h });
    }
  }
}

$('scPickBtn').onclick = async () => {
  if (scBusy) return;
  if (typeof window.showDirectoryPicker !== 'function')
    return setStatusText('⛔ Этот Chrome не умеет выбирать папки (showDirectoryPicker) — обнови браузер', true);
  scBusy = true;
  let handle;
  try {
    handle = await window.showDirectoryPicker({ mode: 'read' });
  } catch (e) {
    scBusy = false;
    if (String((e && e.name) || e) === 'AbortError') setStatusText('Выбор папки отменён');
    else setStatusText('⛔ ' + ((e && e.message) || e), true);
    return;
  }
  try {
    let perm = await handle.queryPermission({ mode: 'read' });
    if (perm !== 'granted') perm = await handle.requestPermission({ mode: 'read' });
    if (perm !== 'granted') throw new Error('нет доступа на чтение папки');

    const out = [];
    await scWalk(handle, out, 0, $('scRecurse').checked ? Infinity : 0);
    if (!out.length) throw new Error('в папке нет картинок (png/jpg/webp/gif/bmp/avif)');

    if (!scProbed) {
      const t = await bgSend({ type: 'screensTest', data: new ArrayBuffer(8) });
      scAbMode = !!t.ok;
      scProbed = true;
    }

    // перекашиваем только новое/изменённое — по имени + размеру + mtime
    const meta = await bgSend({ type: 'screensMeta' });
    const cached = new Map(((meta.files) || []).map(f => [f.name, f]));
    const toCache = out.filter(f => { const c = cached.get(f.name); return !c || c.size !== f.size || c.mtime !== f.mtime; });

    if (toCache.length) setStatusText(`📂 «${handle.name}» — ${out.length} картинок, кэширую ${toCache.length}…`);
    for (let i = 0; i < toCache.length; i++) {
      const f = toCache[i];
      const g = await f.handle.getFile();
      const buf = await g.arrayBuffer();
      const r = await bgSend({
        type: 'screensCache', name: f.name,
        ...(scAbMode ? { data: buf } : { b64: bufToB64(buf) }),
        mtime: f.mtime, idx: i + 1, total: toCache.length
      });
      if (!r.ok) throw new Error('ошибка кэша: ' + (r.error || '?') + ' (' + f.name + ')');
      if (i % 5 === 0 || i === toCache.length - 1)
        setStatusText(`📂 Кэширую «${handle.name}»… ${i + 1}/${toCache.length}`);
    }

    const files = out.map(({ name, size, mtime }) => ({ name, size, mtime }));
    const end = await bgSend({ type: 'screensCacheEnd', dirName: handle.name, files });
    if (!end.ok) throw new Error('ошибка кэша: ' + (end.error || '?'));
    setStatusText(`📂 «${handle.name}»: ${files.length} картинок закэшировано (изменено: ${toCache.length})`);
    renderScMeta();
  } catch (e) {
    setStatusText('⛔ ' + ((e && e.message) || e), true);
  }
  scBusy = false;
};

async function renderScMeta() {
  const el = $('scMeta');
  if (!el) return;
  const [meta, plan] = await Promise.all([
    bgSend({ type: 'screensMeta' }),
    bgSend({ type: 'screensPlan', orderTokens: $('scOrder').value.trim() })
  ]);
  if (!meta.ok || !meta.files || !meta.files.length) { el.textContent = 'папка не выбрана'; return; }
  const when = meta.pickedAt ? new Date(meta.pickedAt).toLocaleString('ru-RU') : '?';
  el.textContent =
    `папка: ${meta.dirName || '?'} — ${meta.files.length} картинок\n` +
    `очередь: ${(plan && plan.summary) || '…'} (всего ${plan ? plan.total : '?'})\n` +
    `действий: ${plan.groups ? plan.groups.length : '?'} (до 6 скринов в каждом)\n` +
    (plan.unrecognized?.length ? `⚠ Не распознаны: ${plan.unrecognized.join(', ')}\n` : '') +
    `кэш: ${when}`;
}
let scPlanT = null;
$('scOrder').addEventListener('input', () => { clearTimeout(scPlanT); scPlanT = setTimeout(renderScMeta, 400); });

$('scStartBtn').onclick = async () => {
  scSave();
  const meta = await bgSend({ type: 'screensMeta' });
  if (!meta.ok || !meta.files || !meta.files.length)
    return setStatusText('⛔ Сначала выбери папку со скриншотами («📂 Выбрать папку»)', true);
  const list = await erGetList();
  if (!list.length)
    return setStatusText('⛔ Нет аккаунтов ЕР — добавь хотя бы один в карточке «Аккаунты ЕР»', true);
  await refreshActiveTab();
  const url = /^https:\/\/[^/]+\/events\/\d+/.test(tabUrl) ? tabUrl : $('eventUrl').value.trim();
  if (!/^https:\/\/[^/]+\/events\/\d+/.test(url))
    return setStatusText('⛔ Открой страницу события (…/events/число) или укажи URL в карточке «Заливка ссылок»', true);
  const r = await bgSend({
    type: 'screensStart', eventUrl: url,
    orderTokens: $('scOrder').value.trim(),
    single: !!$('scSingle').checked,
    fromCurrent: !!$('scFromCurrent').checked,
    restoreFirst: !!$('scRestore').checked
  });
  if (!r.ok) return setStatusText('⛔ ' + (r.error || 'не удалось запустить цепочку'), true);
  setStatusText(`▶ Цепочка запущена: ${r.accounts} аккаунт(ов) × ${r.files} скриншотов${r.single ? ' (только текущий)' : ''} — попап можно закрыть`);
};

$('scStopBtn').onclick = async () => {
  const r = await bgSend({ type: 'screensStop' });
  if (r.ok) setStatusText('⏹ Останавливаю цепочку скринов (до конца текущего файла)…');
};

$('scResumeBtn').onclick = async () => {
  const r = await bgSend({ type: 'screensResume' });
  if (!r.ok) return setStatusText('⛔ ' + (r.error || 'не удалось продолжить'), true);
  setStatusText(`↻ Продолжаю цепочку с «${r.account}» (${r.from + 1}/${r.total})`);
};

function renderScChain(st) {
  const el = $('scChain');
  if (!el) return '';
  const n = (st && st.accounts) ? st.accounts.length : 0;
  if (!st || !n) { el.textContent = ''; $('scStartBtn').disabled = false; $('scResumeBtn').style.display = 'none'; return ''; }
  const total = (st.fileOrder || []).length;
  const name = i => (st.accounts[i] || {}).name || '?';
  let head;
  if (st.running) head = `▶ работаю: аккаунт ${Math.min(st.accountIdx + 1, n)}/${n} — ${name(st.accountIdx)} (${total} скрин.)`;
  else if (st.finished) head = `✅ цепочка завершена — все ${n} аккаунта(ов)`;
  else if (st.error) head = `⛔ ${st.error}`;
  else if (st.stopped) head = '⏹ цепочка остановлена';
  else if (st.accountIdx > 0) head = `⏸ на паузе: следующий — ${name(st.accountIdx)}`;
  else head = '';
  const lines = head ? [head] : [];
  for (let i = 0; i < n; i++) {
    const p = (st.progress || [])[i] || {};
    const mark = p.done ? (p.stopped ? '⏹' : (p.ok ? '✓' : '✗')) : (p.inFlight ? '▶' : '·');
    const cnt = (p.okCount != null) ? `: ${p.okCount}/${total}${p.failCount ? ` (${p.failCount} ошибок)` : ''}` : '';
    lines.push(`${mark} ${name(i)}${cnt}`);
  }
  const text = lines.join('\n');
  el.textContent = text;
  el.style.color = (st.error || (st.progress || []).some(p => p && p.done && p.ok === false)) ? '#e88' : '#8a8f99';
  $('scStartBtn').disabled = !!st.running;
  $('scResumeBtn').style.display = (!st.running && !st.finished && st.accountIdx < n) ? '' : 'none';
  return text;
}

function setStatusText(text, isErr) {
  const s = $('status');
  s.textContent = text;
  s.className = isErr ? 'err' : '';
}

/* ---------- опрос статусов из storage (парсер и заливка — отдельные ключи) ---------- */
let lastRender = '';
let statusPollInFlight = false;
const runningFresh = (st, now, maxAge) => !!(st && st.running && st.ts && now - st.ts < maxAge);
setInterval(async () => {
  if (statusPollInFlight) return;
  statusPollInFlight = true;
  try {
  const [s, cs] = await Promise.all([
    chrome.storage.local.get(['vkExtStatus', 'vkExtStatusUpload', 'vkExtStatusScreens', 'vkApiParseStatus', 'vkApiParseResult', 'okParseStatus', 'okParseResult']),
    (chrome.storage.session || chrome.storage.local).get(['screensChain'])
  ]);
  const now = Date.now();
  const P = s.vkExtStatus || {}, U = s.vkExtStatusUpload || {}, S = s.vkExtStatusScreens || {};
  const A = s.vkApiParseStatus || {}, R = s.vkApiParseResult || {};
  const O = s.okParseStatus || {}, OR = s.okParseResult || {};
  const oRun = runningFresh(O, now, 15000);
  $('okProgress').textContent = (O.line || '—') + ` · сохранено: ${(OR.links || []).length}`;
  $('okStartBtn').disabled = oRun;
  $('okStopBtn').disabled = !oRun;
  const pRun = runningFresh(P, now, 15000), uRun = runningFresh(U, now, 180000);
  const scRun = runningFresh(S, now, 180000);
  const lRun = P.running && P.mode === 'like' ? pRun : false;
  const pShow = P.mode !== 'like' ? P : {};

  const row = (label, st, run) => (!st.line && !run) ? null :
    `${label} ${run ? '▶' : (st.phase === 'done' ? '■' : '')} ${st.line || ''}` +
    (st.total ? ` (успешно: ${st.ok || 0}${label === 'Заливка:' ? `, уже загружено: ${st.skipped || 0}${st.firstSuccessPerNetwork ? `, по лимиту: ${st.limitSkipped || 0}` : ''}` : ''}, ошибок: ${st.fail || 0}, всего: ${st.total})` : '');
  const rows = [
    row('Парсер:', { ...pShow, running: pShow.running }, pRun && P.mode !== 'like'),
    row('Лайкер:', { ...P, running: lRun }, lRun),
    row('VK API:', A, !!A.running),
    row('ОК:', O, oRun),
    row('Заливка:', { ...U, running: uRun }, uRun),
    row('Скриншоты:', { ...S, running: scRun }, scRun)
  ].filter(Boolean);
  const chainText = renderScChain(cs.screensChain);
  const apiText = A.error ? '⛔ ' + A.error : (A.line || '—');
  $('apiProgress').textContent = apiText + ((R.links || []).length ? ` · результат: ${R.links.length} ссылок` : '');
  $('apiStartBtn').disabled = !!A.running;
  $('apiStopBtn').disabled = !A.running;
  const key = rows.join('\n') + '||sc||' + chainText;
  if (key === lastRender) return;
  lastRender = key;

  const el = $('status');
  el.className = (P.error || U.error || S.error || A.error || O.error) ? 'err' : '';
  el.textContent = rows.length ? rows.join('\n') : '—';

  $('parseBtn').disabled = pRun;
  $('searchBtn').disabled = pRun;
  $('searchUpBtn').disabled = pRun || uRun;
  $('uploadBtn').disabled = uRun;
  $('likeBtn').disabled = pRun;
  } finally {
    statusPollInFlight = false;
  }
}, 500);

// автопродление: показать состояние (после объявления bgSend)
if ($('erBgInfo')) {
  erBgRefreshInfo().catch(() => {});
}


/* ---------- общий счётчик отчётов ---------- */
const renderReportCounter = state => {
  const total = $('reportCounterTotal'), info = $('reportCounterInfo');
  if (!total || !info) return;
  if (state != null && (!Number.isSafeInteger(state.total) || state.total < 0)) {
    total.textContent = '—'; info.textContent = 'Ошибка данных счётчика; итог не сброшен'; return;
  }
  total.textContent = String(state?.total || 0);
  info.textContent = state?.since
    ? 'Все аккаунты · с ' + new Date(state.since).toLocaleString('ru-RU')
    : 'Все аккаунты · новые отчёты с момента включения счётчика';
  info.title = 'Ручная отправка и расширение. Один созданный отчёт = +1, независимо от числа файлов. Дубли и ошибки не считаются. Старые отчёты не пересчитываются.';
};
let reportCounterRevision = 0;
chrome.storage.local.get(['vkReportCounter']).then(s => {
  if (!reportCounterRevision) renderReportCounter(s.vkReportCounter);
}).catch(() => {
  const info = $('reportCounterInfo'); if (info) info.textContent = 'Не прочитан сохранённый счётчик';
});
chrome.storage.onChanged?.addListener((changes, area) => {
  if (area === 'local' && changes.vkReportCounter) {
    reportCounterRevision++; renderReportCounter(changes.vkReportCounter.newValue);
  }
});

const reportCounterResetButton = $('reportCounterReset');
if (reportCounterResetButton) reportCounterResetButton.onclick = async () => {
  if (reportCounterResetButton.disabled) return;
  if (!confirm('Сбросить статистику успешных отчётов до нуля? Сами отчёты, аккаунты и база ссылок останутся без изменений.')) return;
  reportCounterResetButton.disabled = true;
  const revision = reportCounterRevision;
  try {
    const result = await bgSend({ type: 'reportCounterReset' });
    if (!result?.ok) throw new Error(result?.error || 'нет ответа от расширения');
    // Storage changes may already include a newer report while this reply is in transit.
    if (reportCounterRevision === revision) renderReportCounter({ total: result.total, since: result.since });
  } catch (e) {
    const info = $('reportCounterInfo');
    if (info) info.textContent = 'Сброс не выполнен: ' + String(e.message || e);
  } finally {
    reportCounterResetButton.disabled = false;
  }
};
