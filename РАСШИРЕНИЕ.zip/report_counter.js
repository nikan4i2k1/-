/* One observer for manual and automated submissions; attachment upload is not report creation. */
(() => {
  if (globalThis.__vkReportCounterV1 || typeof document === 'undefined' ||
      typeof chrome === 'undefined' || location.hostname !== 'vverh-app.er.ru') return;
  globalThis.__vkReportCounterV1 = true;
  const PENDING_KEY = 'vkReportCounterPendingV1';
  const OUTBOX_KEY = 'vkReportCounterOutboxV1';
  const PENDING_TTL = 5 * 60 * 1000, RETRY_TTL = 10 * 60 * 1000, SETTLE_MS = 1000;
  const SELECTOR = '.van-notify, .van-toast, [role="alert"], [role="status"], .alert, .notification';
  let pending = null, baseline = new Map(), settleTimer = null, retryTimer = null, sending = false;
  let outbox = [];
  const textOf = el => String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  const visible = el => el.offsetParent !== null || el.getClientRects().length > 0;
  const notices = () => [...document.querySelectorAll(SELECTOR)].filter(visible);
  const eventId = () => location.origin === 'https://vverh-app.er.ru' &&
    (location.pathname.match(/^\/events\/(\d+)(?:\/|$)/) || [])[1];
  const save = () => { try {
    if (pending) sessionStorage.setItem(PENDING_KEY, JSON.stringify(pending));
    else sessionStorage.removeItem(PENDING_KEY);
  } catch (e) { /* Tab storage may be disabled; memory-only tracking still works. */ } };
  const clear = () => {
    pending = null; baseline.clear(); clearTimeout(settleTimer); settleTimer = null;
    save();
  };
  const isFresh = () => pending && location.origin === 'https://vverh-app.er.ru' &&
    Date.now() - (pending.confirmedAt || pending.startedAt) <= (pending.confirmedAt ? RETRY_TTL : PENDING_TTL);
  const saveOutbox = () => { try { sessionStorage.setItem(OUTBOX_KEY, JSON.stringify(outbox)); } catch (e) {} };
  const flush = () => {
    if (sending) return;
    outbox = outbox.filter(item => Date.now() - item.confirmedAt <= RETRY_TTL);
    saveOutbox();
    if (!outbox.length) return;
    const item = outbox[0];
    sending = true;
    const retry = () => {
      sending = false;
      clearTimeout(retryTimer); retryTimer = setTimeout(flush, 2000);
    };
    try {
      chrome.runtime.sendMessage({ type: 'reportCounterRecord', id: item.id,
        startedAt: item.startedAt, confirmedAt: item.confirmedAt, eventId: item.eventId }, response => {
        if (chrome.runtime.lastError || !response?.ok) { retry(); return; }
        sending = false;
        outbox = outbox.filter(receipt => receipt.id !== item.id); saveOutbox(); flush();
      });
    } catch (e) { retry(); }
  };
  const scope = target => {
    if (!eventId() || !target?.closest || target.closest('[data-vk-report-counter]')) return false;
    if (/\/report\/edit(?:\/|$)/.test(location.pathname)) return false;
    return !!target.closest('.report-create, .report-add, [data-report-create]') ||
      /\/(?:report\/add|new-action)(?:\/|$)/.test(location.pathname);
  };
  const begin = target => {
    if (!scope(target)) return;
    if (isFresh() && pending.eventId === eventId()) return;
    clear();
    baseline = new Map(notices().map(el => [el, textOf(el)]));
    pending = { id: 'report-' + crypto.randomUUID(), eventId: eventId(), startedAt: Date.now(), confirmedAt: 0 };
    save();
  };
  const classify = text => {
    if (!text || text.length > 700) return null;
    if (/уже.{0,35}(?:загруж|добавл|создан|существ)|дубликат|ошибк|не удалось|не (?:создан|отправлен|принят)|отклон[её]н/i.test(text)) return 'rejected';
    if (/(?:ваше\s+)?(?:действие|отч[её]т)\s+(?:успешно\s+)?(?:создан[оа]?|отправлен[оа]?|добавлен[оа]?)(?:[.!\s]|$)/i.test(text)) return 'created';
    return null;
  };
  const scheduleConfirmation = () => {
    if (!pending?.candidateAt || settleTimer !== null) return;
    const item = pending;
    settleTimer = setTimeout(() => {
      settleTimer = null;
      if (pending !== item || !isFresh()) return;
      pending.confirmedAt = Date.now();
      // Keep confirmed receipts separate so a slow storage acknowledgement cannot block the next report.
      outbox = [...outbox, { ...pending }].slice(-4096); saveOutbox(); clear(); flush();
    }, Math.max(0, SETTLE_MS - (Date.now() - item.candidateAt)));
  };
  const consider = el => {
    if (!isFresh()) { if (pending) clear(); return; }
    if (pending.confirmedAt || !visible(el)) return;
    const text = textOf(el);
    if (baseline.get(el) === text) return;
    const result = classify(text);
    if (result === 'rejected') { clear(); return; }
    if (result !== 'created') return;
    if (!pending.candidateAt) { pending.candidateAt = Date.now(); save(); }
    scheduleConfirmation();
  };
  const start = () => {
    try {
      const saved = JSON.parse(sessionStorage.getItem(OUTBOX_KEY) || '[]');
      if (Array.isArray(saved)) outbox = saved.filter(item => item && typeof item.id === 'string' &&
        Number.isFinite(item.confirmedAt) && Number.isFinite(item.startedAt)).slice(-4096);
    } catch (e) {}
    try {
      const item = JSON.parse(sessionStorage.getItem(PENDING_KEY) || 'null');
      if (item && typeof item.id === 'string' && Number.isFinite(item.startedAt)) pending = item;
    } catch (e) { /* A malformed draft is not a confirmed report. */ }
    if (pending && !isFresh()) clear();
    if (!pending) baseline = new Map(notices().map(el => [el, textOf(el)]));
    document.addEventListener('click', event => {
      const button = event.target?.closest?.('button, [role="button"], input[type="submit"]');
      if (!button || button.disabled || button.getAttribute('aria-disabled') === 'true') return;
      const caption = String(button.innerText || button.value || button.textContent || '').replace(/\s+/g, ' ').trim();
      if (/^(?:создать(?: действие| отч[её]т)?|отправить(?: отч[её]т)?|сохранить)$/i.test(caption)) begin(button);
    }, true);
    document.addEventListener('submit', event => begin(event.target), true);
    const observer = new MutationObserver(records => {
      if (!pending) return;
      for (const record of records) {
        const parent = record.target.nodeType === 1 ? record.target : record.target.parentElement;
        const notice = parent?.closest?.(SELECTOR);
        if (notice) consider(notice);
        for (const node of record.addedNodes || []) {
          if (node.nodeType !== 1) continue;
          if (node.matches?.(SELECTOR)) consider(node);
          for (const el of node.querySelectorAll?.(SELECTOR) || []) consider(el);
        }
      }
      for (const el of notices()) consider(el);
    });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true,
      attributes: true, attributeFilter: ['class', 'style'] });
    flush();
    if (pending) for (const el of notices()) consider(el);
    scheduleConfirmation();
  };
  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start, { once: true });
})();
