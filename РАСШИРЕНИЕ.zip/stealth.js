/* stealth.js — работает в MAIN-мире страницы, загружается в document_start.
   1) Сетевой наблюдатель (всегда включён): оборачивает fetch/XHR страницы и
      шлёт content.js событие vkext-net {t, method, url, ok} — это честное
      подтверждение POST-запросов сайта (нужно для заливки без ложных «успехов»).
   2) Stealth по команде: подменяет document.hidden/visibilityState и глушит
      события видимости, пока content.js продлевает «on» heartbeat'ами.
   3) Watchdog: если content.js умер и 10 минут не продлевал «on» — stealth
      выключается сам, страница возвращается к нормальной жизни. */
(() => {
  /* ---------- 1) сетевой наблюдатель ---------- */
  const emit = d => { try { window.dispatchEvent(new CustomEvent('vkext-net', { detail: d })); } catch (e) {} };

  try {
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
      window.fetch = function (...a) {
        const url = (typeof a[0] === 'string' ? a[0] : (a[0] && a[0].url)) || '';
        const method = ((a[1] && a[1].method) || (a[0] && a[0].method) || 'GET').toUpperCase();
        const t = Date.now();
        const p = origFetch.apply(this, a);
        return p.then(
          r => { emit({ t, method, url, ok: !!(r && r.ok), status: Number(r?.status) || 0 }); return r; },
          e => { emit({ t, method, url, ok: false, status: 0 }); throw e; });
      };
    }
  } catch (e) {}

  try {
    const XO = window.XMLHttpRequest;
    const oOpen = XO.prototype.open, oSend = XO.prototype.send;
    XO.prototype.open = function (m, u, ...r) { this.__vkextM = (m || 'GET').toUpperCase(); this.__vkextU = u; return oOpen.call(this, m, u, ...r); };
    XO.prototype.send = function (...a) {
      const t = Date.now(), m = this.__vkextM || 'GET', u = this.__vkextU || '';
      try {
        this.addEventListener('load', () => { emit({ t, method: m, url: u, ok: this.status >= 200 && this.status < 400, status: Number(this.status) || 0 }); });
        this.addEventListener('error', () => { emit({ t, method: m, url: u, ok: false, status: 0 }); });
      } catch (e) {}
      return oSend.apply(this, a);
    };
  } catch (e) {}

  /* ---------- 2) stealth on/off + 3) watchdog ---------- */
  const listeners = [];
  let watchdog = null;

  const off = () => {
    clearTimeout(watchdog); watchdog = null;
    listeners.forEach(([tgt, t, f]) => { try { tgt.removeEventListener(t, f, true); } catch (e) {} });
    listeners.length = 0;
    try { delete document.hidden; delete document.visibilityState; } catch (e) {}
  };

  window.addEventListener('vkext-stealth-on', () => {
    off(); // идемпотентно: heartbeat просто пересобирает состояние и сбрасывает watchdog
    try {
      Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
      Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    } catch (e) {}
    const swallow = ev => ev.stopImmediatePropagation();
    // blur НЕ глушим — он ломает валидацию форм на сторонних сайтах
    [['visibilitychange', document], ['pagehide', window],
     ['freeze', document], ['resume', document]].forEach(([t, tgt]) => {
      try { tgt.addEventListener(t, swallow, true); listeners.push([tgt, t, swallow]); } catch (e) {}
    });
    watchdog = setTimeout(off, 10 * 60 * 1000);
  });

  window.addEventListener('vkext-stealth-off', off);
})();
