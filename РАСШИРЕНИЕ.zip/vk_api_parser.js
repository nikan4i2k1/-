/* VK newsfeed.search pagination and link conversion; no credentials are stored here. */
(() => {
  'use strict';

  const day = value => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Укажи дату в формате ГГГГ-ММ-ДД');
    const ms = Date.parse(value + 'T00:00:00+03:00');
    if (!Number.isFinite(ms) || new Date(ms + 3 * 3600000).toISOString().slice(0, 10) !== value)
      throw new Error('Некорректная дата');
    return Math.floor(ms / 1000);
  };

  const dateBounds = (from, to) => {
    const start_time = day(from), end_time = day(to) + 86400 - 1;
    if (end_time < start_time) throw new Error('Дата окончания раньше даты начала');
    return { start_time, end_time };
  };

  /* 6 — слишком часто, 9 — флуд-контроль, 10 — внутренняя ошибка, 29 — rate limit метода */
  const RETRYABLE = new Set([6, 9, 10, 29]);
  const MAX_ATTEMPTS = 6;
  const backoff = (code, attempt) => (code === 9 || code === 29)
    ? Math.min(60000, 5000 * 2 ** (attempt - 1))   // 5, 10, 20, 40, 60 с
    : 1500 * 2 ** (attempt - 1);                   // 1.5, 3, 6, 12, 24 с
  const SPLIT_MIN_SPAN = 120, API_CAP = 1000;

  const searchPosts = async (options, request, hooks = {}) => {
    const q = String(options.query || '').trim();
    if (!q) throw new Error('Введи хештег или слово для запроса');
    const limit = Number(options.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > 10000) throw new Error('Количество постов: от 1 до 10000');
    const bounds = dateBounds(options.from, options.to);
    const links = new Set();
    const windows = [bounds];
    let requests = 0, scanned = 0, splitWindows = 0, unresolvedWindows = 0, retries = 0, apiError = null;
    const lostRanges = [];
    const split = w => {
      const mid = Math.floor((w.start_time + w.end_time) / 2);
      windows.push({ start_time: w.start_time, end_time: mid });
      windows.push({ start_time: mid + 1, end_time: w.end_time });
      splitWindows++;
    };
    const stopped = () => hooks.shouldStop && hooks.shouldStop();
    outer: while (windows.length && links.size < limit && !stopped() && requests < 2000) {
      const window = windows.pop();
      const cursors = new Set();
      let cursor = '', returned = 0, reported = 0, lastFull = false, exhausted = false, splitEarly = false, firstPage = true;
      while (links.size < limit && !stopped() && requests < 2000 && returned < 1000) {
        const params = { q, ...window, count: 200, v: '5.199' };
        if (cursor) params.start_from = cursor;
        let data;
        for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
          const prevCode = data && data.error ? Number(data.error.error_code) : 0;
          const pause = attempt ? backoff(prevCode, attempt) : 400;
          if (attempt && hooks.onRetry) hooks.onRetry({ code: prevCode, attempt, wait: pause });
          if (hooks.wait && (requests || attempt)) await hooks.wait(pause);
          if (stopped()) break;
          data = await request(params);
          requests++;
          if (attempt) retries++;
          if (!data || !data.error || !RETRYABLE.has(Number(data.error.error_code)) || attempt === MAX_ATTEMPTS - 1) break;
        }
        if (!data && stopped()) break;
        if (data && data.error) {
          const code = Number(data.error.error_code);
          const msg = `VK API (${data.error.error_code || '?'}): ${data.error.error_msg || 'ошибка запроса'}`;
          // Лимит не отпустил даже после бэкоффа: отдаём то, что уже собрано, а не роняем весь прогон.
          if (!RETRYABLE.has(code) || !links.size) throw new Error(msg);
          apiError = msg;
          break outer;
        }
        const result = data && data.response;
        if (!result || !Array.isArray(result.items)) throw new Error('VK API вернул неожиданный ответ');
        returned += result.items.length;
        scanned += result.items.length;
        reported = Math.max(reported, Number(result.total_count) || 0, Number(result.count) || 0);
        lastFull = result.items.length === 200;
        for (const post of result.items) {
          if (links.size >= limit) break;
          if (!Number.isSafeInteger(post.owner_id) || !post.owner_id ||
              (options.onlyPeople && post.owner_id < 0) ||
              !Number.isSafeInteger(post.id) || post.id <= 0 ||
              !Number.isSafeInteger(post.date) || post.date < window.start_time || post.date > window.end_time) continue;
          links.add(`https://vk.ru/wall${post.owner_id}_${post.id}`);
        }
        if (hooks.onProgress) hooks.onProgress(links.size, requests,
          { scanned, splitWindows, pendingWindows: windows.length, unresolvedWindows, retries });
        // total_count известен с первой страницы: если окно заведомо больше потолка API,
        // делим сразу, а не листаем 1000 постов, чтобы потом выкачать обе половины заново.
        if (firstPage) {
          firstPage = false;
          if (reported > API_CAP && window.end_time - window.start_time >= SPLIT_MIN_SPAN && links.size < limit) {
            split(window); splitEarly = true; break;
          }
        }
        const next = result.next_from;
        if (!next || !result.items.length || cursors.has(next)) { exhausted = true; break; }
        cursors.add(next);
        cursor = next;
      }
      const saturated = !splitEarly && (returned >= API_CAP || reported >= API_CAP || (exhausted && lastFull));
      if (links.size < limit && !stopped() && saturated) {
        if (window.end_time - window.start_time >= SPLIT_MIN_SPAN) split(window);
        else {
          // Окно < 2 мин, а постов всё равно больше 1000: часть VK не отдаст никак.
          unresolvedWindows++;
          if (lostRanges.length < 20) lostRanges.push({ ...window, reported });
        }
      }
    }
    if (hooks.onComplete) hooks.onComplete({ requests, scanned, splitWindows, unresolvedWindows,
      pendingWindows: windows.length, stopped: !!stopped(), limitReached: links.size >= limit,
      retries, apiError, lostRanges, requestCapHit: requests >= 2000 });
    return [...links];
  };

  globalThis.VKApiParser = { dateBounds, searchPosts };
})();
