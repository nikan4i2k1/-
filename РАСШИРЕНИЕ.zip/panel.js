/* Only presentation state lives here; existing task controls keep their IDs. */
(() => {
  const views = [...document.querySelectorAll('[data-view]')];
  const modes = [...document.querySelectorAll('[data-vk-mode]')];
  let interacted = false;
  const select = (buttons, name) => {
    if (!buttons.some(button => button.dataset.view === name || button.dataset.vkMode === name)) return false;
    for (const button of buttons) {
      const active = (button.dataset.view || button.dataset.vkMode) === name;
      button.setAttribute('aria-selected', String(active));
      button.tabIndex = active ? 0 : -1;
      document.getElementById(button.getAttribute('aria-controls')).hidden = !active;
    }
    return true;
  };
  const persist = values => chrome.storage.local.set(values).catch(console.error);
  function selectView(name, save = true) {
    if (!select(views, name)) return;
    document.querySelector('.panel-main').scrollTop = 0;
    if (save) { interacted = true; persist({ panelView: name }); }
  }
  function selectMode(name, save = true) {
    if (!select(modes, name)) return;
    if (save) { interacted = true; persist({ panelVkMode: name }); }
  }
  function wire(buttons, activate) {
    buttons.forEach((button, index) => {
      button.addEventListener('click', () => activate(button.dataset.view || button.dataset.vkMode));
      button.addEventListener('keydown', event => {
        let next;
        if (event.key === 'ArrowRight') next = (index + 1) % buttons.length;
        else if (event.key === 'ArrowLeft') next = (index + buttons.length - 1) % buttons.length;
        else if (event.key === 'Home') next = 0;
        else if (event.key === 'End') next = buttons.length - 1;
        else return;
        event.preventDefault();
        buttons[next].click();
        buttons[next].focus();
      });
    });
  }
  wire(views, selectView);
  wire(modes, selectMode);
  chrome.storage.local.get({ panelView: 'vk', panelVkMode: 'search' }).then(saved => {
    if (interacted) return;
    selectView(saved.panelView, false);
    selectMode(saved.panelVkMode, false);
  }).catch(console.error);
  window.PanelUI = { selectView };
})();
