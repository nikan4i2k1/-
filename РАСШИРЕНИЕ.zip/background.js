/* ============================================================
   VK Parser & Uploader — background service worker (MV3)
   Оркестратор цепочки «парсинг постов -> заливка в событие»:
   вкладка ВК присылает {type:'uploadToEvent', links, eventUrl, delay},
   мы находим/открываем вкладку события и запускаем там задачу upload.
   + виртуальный курсор вкладки для автолайка (без нативного хоста).
   ============================================================ */
importScripts('vk_api_parser.js');

/* ---------- Общий черновик ссылок для заливки ---------- */
const UPLOAD_DRAFT_KEY = 'vkLinks';
const UPLOAD_RESULT_KEYS = new Set(['vkSearchResult', 'vkFriendsResult', 'vkApiParseResult', 'okParseResult']);
let uploadDraftWrites = Promise.resolve();

const uploadDraftLines = value => {
  const source = Array.isArray(value) ? value : String(value || '').split(/[\s,]+/);
  return source.map(link => String(link || '').trim()).filter(link => /^https?:\/\//i.test(link));
};

const uploadDraftIdentity = value => {
  try {
    const url = new URL(String(value || '').trim());
    const host = url.hostname.toLowerCase().replace(/^(?:www\.|m\.)/, '');
    const path = url.pathname.replace(/\/+$/, '') || '/';
    const wall = /^(?:\/)?wall(-?\d+)_(\d+)(?:\/|$)/i.exec(path);
    if ((host === 'vk.ru' || host === 'vk.com') && wall) return `vk:wall${wall[1]}_${wall[2]}`;
    if (host === 'ok.ru') return `ok:${path}`;
    // Query/hash and path case can identify different manually entered URLs.
    return url.href;
  } catch (e) {
    return String(value || '').trim().toLowerCase().replace(/[?#].*$/, '').replace(/\/+$/, '');
  }
};

const uploadDraftUnique = lines => {
  const out = [], seen = new Set();
  for (const link of uploadDraftLines(lines)) {
    const key = uploadDraftIdentity(link);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(link);
  }
  return out;
};

const queueUploadDraft = work => {
  const next = uploadDraftWrites.then(work, work);
  uploadDraftWrites = next.catch(() => {});
  return next;
};

const mergeUploadDraft = links => queueUploadDraft(async () => {
  const incoming = uploadDraftUnique(links);
  const currentValue = String((await chrome.storage.local.get({ [UPLOAD_DRAFT_KEY]: '' }))[UPLOAD_DRAFT_KEY] || '');
  const current = uploadDraftUnique(currentValue);
  if (!incoming.length) return { value: currentValue, added: 0, total: current.length };
  const seen = new Set(current.map(uploadDraftIdentity));
  const addedLinks = [];
  let added = 0;
  for (const link of incoming) {
    const key = uploadDraftIdentity(link);
    if (seen.has(key)) continue;
    seen.add(key);
    addedLinks.push(link);
    added++;
  }
  const separator = currentValue && !currentValue.endsWith('\n') ? '\n' : '';
  const value = currentValue + (addedLinks.length ? separator + addedLinks.join('\n') : '');
  if (added) await chrome.storage.local.set({ [UPLOAD_DRAFT_KEY]: value });
  return { value, added, total: seen.size };
});

const updateUploadDraft = (value, base) => queueUploadDraft(async () => {
  const desiredValue = String(value || '');
  const desired = uploadDraftUnique(desiredValue);
  const previous = uploadDraftUnique(base);
  const currentValue = String((await chrome.storage.local.get({ [UPLOAD_DRAFT_KEY]: '' }))[UPLOAD_DRAFT_KEY] || '');
  const current = uploadDraftUnique(currentValue);
  const desiredKeys = new Set(desired.map(uploadDraftIdentity));
  const previousKeys = new Set(previous.map(uploadDraftIdentity));
  const additions = [];
  for (const link of current) {
    const key = uploadDraftIdentity(link);
    if (!previousKeys.has(key) && !desiredKeys.has(key)) {
      desiredKeys.add(key);
      additions.push(link);
    }
  }
  const separator = desiredValue && !desiredValue.endsWith('\n') ? '\n' : '';
  const nextValue = desiredValue + (additions.length ? separator + additions.join('\n') : '');
  await chrome.storage.local.set({ [UPLOAD_DRAFT_KEY]: nextValue });
  return { value: nextValue, total: desiredKeys.size };
});

chrome.storage?.onChanged?.addListener((changes, area) => {
  if (area !== 'local') return;
  for (const key of UPLOAD_RESULT_KEYS) {
    const result = changes[key]?.newValue;
    if (Array.isArray(result?.links) && result.links.length) mergeUploadDraft(result.links).catch(() => {});
  }
});

// Global browser panel: clicking the toolbar icon opens it without a popup.
if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .catch(error => console.error('Side panel:', error));
}

/* ---------- API-парсер постов (не зависит от открытой вкладки VK) ---------- */
const VK_API_STATUS_KEY = 'vkApiParseStatus';
const VK_API_RESULT_KEY = 'vkApiParseResult';
let vkApiRunning = false;
let vkApiStop = false;

const vkApiRequest = async (token, params) => {
  const body = new URLSearchParams({ ...params, access_token: token });
  const response = await fetch('https://api.vk.com/method/newsfeed.search', { method: 'POST', body });
  if (!response.ok) throw new Error('VK API: HTTP ' + response.status);
  return response.json();
};

const runVkApiParse = async (msg) => {
  const token = String(msg.token || '').trim();
  const options = { query: msg.query, from: msg.from, to: msg.to,
    limit: Number(msg.limit), onlyPeople: !!msg.onlyPeople };
  if (!token) throw new Error('Введи access-токен VK API');
  VKApiParser.dateBounds(options.from, options.to);
  if (!String(options.query || '').trim()) throw new Error('Введи запрос');
  if (!Number.isInteger(options.limit) || options.limit < 1 || options.limit > 10000)
    throw new Error('Количество постов: от 1 до 10000');
  if (vkApiRunning) throw new Error('API-парсер уже работает');
  vkApiRunning = true;
  vkApiStop = false;
  const status = { running: true, phase: 'work', line: 'Запрос к VK API…',
    ok: 0, total: options.limit, requests: 0, ts: Date.now(), error: null };
  await chrome.storage.local.set({ [VK_API_STATUS_KEY]: status, [VK_API_RESULT_KEY]: { links: [] } });
  let writes = Promise.resolve();
  const saveProgress = (count, requests, detail) => {
    Object.assign(status, { ok: count, requests, scanned: detail.scanned, ts: Date.now(),
      line: `Найдено ${count}/${options.limit}; запросов ${requests}` });
    const snapshot = { ...status };
    writes = writes.then(() => chrome.storage.local.set({ [VK_API_STATUS_KEY]: snapshot }));
  };
  const onRetry = ({ code, attempt, wait }) => {
    Object.assign(status, { ts: Date.now(),
      line: `VK притормозил (код ${code}), жду ${Math.round(wait / 1000)} с, попытка ${attempt}…` });
    const snapshot = { ...status };
    writes = writes.then(() => chrome.storage.local.set({ [VK_API_STATUS_KEY]: snapshot }));
  };
  let summary = {};
  const fmt = t => new Date(t * 1000).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' });
  (async () => {
    try {
      const links = await VKApiParser.searchPosts(options, params => vkApiRequest(token, params), {
        shouldStop: () => vkApiStop,
        wait: ms => new Promise(resolve => setTimeout(resolve, ms)),
        onProgress: saveProgress,
        onRetry,
        onComplete: s => { summary = s; }
      });
      await writes;
      const stopped = vkApiStop;
      const warnings = [];
      if (summary.unresolvedWindows) warnings.push(`⚠ потеряна часть постов: ${summary.unresolvedWindows} окон короче 2 мин, где больше 1000 постов` +
        (summary.lostRanges?.[0] ? ` (напр. ${fmt(summary.lostRanges[0].start_time)})` : ''));
      if (summary.apiError) warnings.push(`⚠ VK так и не снял лимит, результат частичный: ${summary.apiError}`);
      if (summary.requestCapHit) warnings.push('⚠ упёрлись в потолок 2000 запросов, результат частичный');
      const head = stopped ? 'Остановлено' : (warnings.length ? 'Готово с потерями' : 'Готово');
      await chrome.storage.local.set({
        [VK_API_RESULT_KEY]: { links, query: String(options.query).trim(), ts: Date.now(),
          unresolvedWindows: summary.unresolvedWindows || 0, lostRanges: summary.lostRanges || [], apiError: summary.apiError || null },
        [VK_API_STATUS_KEY]: { ...status, running: false, phase: stopped ? 'stopped' : 'done',
          ok: links.length, warnings, unresolvedWindows: summary.unresolvedWindows || 0,
          line: `${head}: ${links.length} ссылок; запросов ${summary.requests || status.requests}` +
            (warnings.length ? ' · ' + warnings.join(' · ') : ''), ts: Date.now() }
      });
    } catch (e) {
      await writes;
      await chrome.storage.local.set({ [VK_API_STATUS_KEY]: { ...status, running: false,
        phase: 'error', line: 'Ошибка VK API', error: String((e && e.message) || e), ts: Date.now() } });
    } finally {
      vkApiRunning = false;
      vkApiStop = false;
    }
  })();
  return { ok: true };
};

const sleep = ms => new Promise(r => setTimeout(r, ms));

/* sendMessage с ответом; null — если на вкладке нашего скрипта нет */
const tabSend = (tabId, msg) => new Promise(res => {
  try {
    chrome.tabs.sendMessage(tabId, msg, r =>
      res(chrome.runtime.lastError ? null : (r || { ok: false })));
  } catch (e) { res(null); }
});

const inject = async tabId => {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
  await chrome.scripting.executeScript({ target: { tabId }, files: ['stealth.js'], world: 'MAIN' }).catch(() => {});
};

async function uploadToEvent({ links, eventUrl, delay, category, firstSuccessPerNetwork = false }) {
  if (!Array.isArray(links) || !links.length) throw new Error('пустой список ссылок');
  const u = new URL(eventUrl);
  if (!/(^|\.)er\.ru$/.test(u.hostname)) throw new Error('URL события должен быть на er.ru');
  if (!/^\/events\/\d+/.test(u.pathname)) throw new Error('URL события должен быть вида /events/XXXXX');

  let [tab] = await chrome.tabs.query({ url: eventUrl + '*' });
  if (!tab) {
    tab = await chrome.tabs.create({ url: eventUrl, active: true });
  } else {
    await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
  }

  // ждём, пока на вкладке появится content.js (она могла быть открыта до перезагрузки расширения)
  let alive = null;
  for (let i = 0; i < 15 && !alive; i++) {
    await sleep(1000);
    alive = await tabSend(tab.id, { type: 'ping' });
    if (!alive && (i === 2 || i === 7)) await inject(tab.id);
  }
  if (!alive) await inject(tab.id);

  if (alive && alive.contentVersion !== '1.4.5') return { ok: false, error: 'Обнови вкладку события после перезагрузки расширения для выбора категорий' };
  let r = await tabSend(tab.id, { type: 'upload', links, delay, category, firstSuccessPerNetwork: firstSuccessPerNetwork === true });
  if (!r) { // скрипт на вкладке так и не ожил — последняя попытка: инжект + повтор
    await inject(tab.id);
    await sleep(500);
    r = await tabSend(tab.id, { type: 'upload', links, delay, category, firstSuccessPerNetwork: firstSuccessPerNetwork === true });
  }
  if (!r) return { ok: false, error: 'вкладка события не ответила — обнови её (F5)' };
  if (r.ok === false && /уже выполняется/.test(r.error || '')) return { ok: true, note: 'заливка уже работала' };
  return r;
}

/* Виртуальный курсор: только Input, только вкладка отправителя, только текущий запуск. */
const cursorSessions = new Map();
const cursorVkUrl = url => /^https:\/\/(?:m\.)?vk\.(?:ru|com)\//.test(url || '');
const cursorRoute = url => { const u = new URL(url); return u.origin + u.pathname + u.search; };

async function cursorClose(tabId, session) {
  if (!session) return;
  session.cancelled = true;
  await session.pending.catch(() => {});
  if (cursorSessions.get(tabId) !== session) return;
  cursorSessions.delete(tabId);
  if (session.attached) await chrome.debugger.detach({ tabId }).catch(() => {});
}

async function virtualCursor(msg, sender) {
  const tabId = sender.tab?.id;
  if (!Number.isInteger(tabId) || sender.frameId !== 0 || !cursorVkUrl(sender.url))
    throw Error('Виртуальный курсор работает только на основной странице ВК');
  if (typeof msg.runId !== 'string' || !msg.runId || msg.runId.length > 80)
    throw Error('Нет идентификатора запуска курсора');
  let session = cursorSessions.get(tabId);
  const owns = session && session.runId === msg.runId && session.documentId === sender.documentId;
  // Stop must cancel immediately, including during attach or an in-flight movement.
  if (msg.action === 'stop') {
    if (owns) await cursorClose(tabId, session);
    return { ok: true };
  }
  const tab = await chrome.tabs.get(tabId);
  if (!cursorVkUrl(tab.url) || cursorRoute(tab.url) !== cursorRoute(sender.url))
    throw Error('Страница изменилась — запусти автолайк заново');
  if (msg.action === 'start') {
    // Re-read after tabs.get: two concurrent starts must not both attach.
    if (cursorSessions.has(tabId)) throw Error('Курсор уже работает на этой вкладке');
    if (!chrome.debugger) throw Error('Перезагрузи расширение с разрешением debugger');
    session = { runId: msg.runId, documentId: sender.documentId, cancelled: false, attached: false };
    cursorSessions.set(tabId, session);
    session.pending = (async () => {
      await chrome.debugger.attach({ tabId }, '1.3');
      session.attached = true;
    })();
    try {
      await session.pending;
      if (session.cancelled) throw Error('Курсор остановлен');
    } catch (e) {
      await cursorClose(tabId, session);
      throw Error('Курсор не подключён: ' + e.message + '. Закрой DevTools этой вкладки и повтори запуск.');
    }
    return { ok: true };
  }
  if (!owns || session.cancelled) throw Error('Курсор отключён — запусти автолайк заново');
  if (!['click', 'wheel'].includes(msg.action)) throw Error('Неизвестное действие курсора');
  if (![msg.x, msg.y].every(n => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 100000))
    throw Error('Некорректная точка курсора');
  if (msg.action === 'wheel' && (!Number.isFinite(msg.dy) || Math.abs(msg.dy) > 2000))
    throw Error('Некорректная прокрутка');
  const run = async () => {
    const check = () => {
      if (session.cancelled || cursorSessions.get(tabId) !== session) throw Error('Курсор остановлен');
    };
    check();
    const input = params => chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
      x: msg.x, y: msg.y, ...params
    });
    if (msg.action === 'wheel') {
      await input({ type: 'mouseWheel', deltaX: 0, deltaY: msg.dy });
    } else {
      await input({ type: 'mouseMoved', button: 'none', buttons: 0 });
      check();
      try {
        await input({ type: 'mousePressed', button: 'left', buttons: 1, clickCount: 1 });
      } finally {
        // Always release, even if Stop arrived after the press.
        await input({ type: 'mouseReleased', button: 'left', buttons: 0, clickCount: 1 });
      }
    }
  };
  const result = session.pending.then(run);
  session.pending = result.catch(() => {});
  try { await result; } catch (e) { await cursorClose(tabId, session); throw e; }
  return { ok: true };
}

chrome.debugger?.onDetach.addListener((source, reason) => {
  const eventRun = eventButtonRuns.get(source.tabId);
  if (eventRun) eventRun.cancelled = true;
  const session = cursorSessions.get(source.tabId);
  if (!session) return;
  session.cancelled = true;
  cursorSessions.delete(source.tabId);
  chrome.tabs.sendMessage(source.tabId, { type: 'virtualCursorDetached', runId: session.runId, reason }).catch(() => {});
});
chrome.tabs?.onRemoved?.addListener(tabId => {
  const eventRun = eventButtonRuns.get(tabId);
  if (eventRun) eventRun.cancelled = true;
  const session = cursorSessions.get(tabId);
  if (session) { session.cancelled = true; cursorSessions.delete(tabId); }
});
chrome.tabs?.onUpdated?.addListener((tabId, change) => {
  if (change.status === 'loading' || change.url) {
    const eventRun = eventButtonRuns.get(tabId);
    if (eventRun) eventRun.cancelled = true;
    const session = cursorSessions.get(tabId);
    if (session) {
      chrome.tabs.sendMessage(tabId, { type: 'virtualCursorDetached', runId: session.runId, reason: 'navigation' }).catch(() => {});
      void cursorClose(tabId, session);
    }
  }
});

/* One browser-input click on an event's real control; never a form submit or arbitrary coordinate. */
const eventButtonRuns = new Map();
const eventButtonRoute = (url, id) => {
  try { const u = new URL(url); return u.origin === 'https://vverh-app.er.ru' && u.pathname.replace(/\/+$/, '') === '/events/' + id; }
  catch (e) { return false; }
};
function eventButtonPoint(label, eventId) {
  if (location.origin !== 'https://vverh-app.er.ru' || location.pathname.replace(/\/+$/, '') !== '/events/' + eventId)
    throw Error('Страница события изменилась до клика');
  const norm = value => String(value || '').replace(/\s+/g, ' ').trim();
  const buttons = [...document.querySelectorAll('button.progresssliderbtn, a.progresssliderbtn, button, [role="button"]')];
  const matches = buttons.filter(el => {
    const title = el.querySelector('.progresssliderbtn__title');
    const text = norm(title?.textContent || el.innerText || el.textContent);
    return (text === label || (!title && new RegExp('^' + label + '\\s*\\d*$').test(text))) &&
      !el.closest('form, [inert]') && !el.disabled && el.getAttribute('aria-disabled') !== 'true' &&
      !/disabled|inactive/i.test(el.className || '') && el.getClientRects().length &&
      getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).pointerEvents !== 'none';
  });
  if (matches.length !== 1) throw Error('Кнопка «' + label + '» не определена однозначно: ' + matches.length);
  const el = matches[0];
  if (el.tagName === 'A') {
    const url = new URL(el.getAttribute('href') || '#', location.href);
    if (url.origin !== location.origin || url.pathname.replace(/\/+$/, '') !== '/events/' + eventId)
      throw Error('Кнопка ведёт на другую страницу');
  }
  el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
  const r = el.getBoundingClientRect(), left = Math.max(0, r.left), right = Math.min(innerWidth, r.right),
    top = Math.max(0, r.top), bottom = Math.min(innerHeight, r.bottom);
  if (right <= left || bottom <= top) throw Error('Кнопка вне видимой области');
  for (const ratio of [0.5, 0.25, 0.75]) {
    const x = left + (right - left) * ratio, y = (top + bottom) / 2;
    const hit = document.elementFromPoint(x, y);
    if (hit && (hit === el || el.contains(hit))) return { x, y, label, tag: el.tagName };
  }
  throw Error('Кнопка «' + label + '» перекрыта другим элементом');
}
function eventButtonStop(sender) {
  const run = eventButtonRuns.get(sender.tab?.id);
  if (run && sender.frameId === 0 && run.documentId === sender.documentId) run.cancelled = true;
  return { ok: true };
}
async function eventButtonClick(msg, sender) {
  const tabId = sender.tab?.id, eventId = String(msg.eventId || ''), label = msg.label;
  if (!Number.isInteger(tabId) || sender.frameId !== 0 || !/^\d{1,20}$/.test(eventId) ||
      !['Участвовать', 'Создать действие'].includes(label) || !eventButtonRoute(sender.url, eventId))
    throw Error('Клик разрешён только по кнопке текущего события');
  if (eventButtonRuns.has(tabId) || cursorSessions.has(tabId)) throw Error('На вкладке уже выполняется нажатие');
  const run = { cancelled: false, documentId: sender.documentId, attached: false };
  eventButtonRuns.set(tabId, run);
  const check = async () => {
    if (run.cancelled) throw Error('Нажатие остановлено');
    if (!eventButtonRoute((await chrome.tabs.get(tabId)).url, eventId)) throw Error('Вкладка сменила событие до клика');
    if (run.cancelled) throw Error('Нажатие остановлено');
  };
  try {
    await check();
    try { await chrome.debugger.attach({ tabId }, '1.3'); run.attached = true; }
    catch (e) { throw Error('Нажатие не выполнено: браузер не подключил ввод. Закрой DevTools этой вкладки. ' + e.message); }
    await check();
    const target = sender.documentId ? { tabId, documentIds: [sender.documentId] } : { tabId, frameIds: [0] };
    const results = await chrome.scripting.executeScript({ target, func: eventButtonPoint, args: [label, eventId] });
    const point = results?.[0]?.result;
    if (!point || ![point.x, point.y].every(n => Number.isFinite(n) && n >= 0 && n <= 100000))
      throw Error('Браузер не подтвердил координаты кнопки');
    await check();
    const input = params => chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { x: point.x, y: point.y, ...params });
    await input({ type: 'mouseMoved', button: 'none', buttons: 0 });
    await check();
    try { await input({ type: 'mousePressed', button: 'left', buttons: 1, clickCount: 1 }); }
    finally { await input({ type: 'mouseReleased', button: 'left', buttons: 0, clickCount: 1 }); }
    return { ok: true, clicked: true, input: 'browser', label };
  } finally {
    if (run.attached) await chrome.debugger.detach({ tabId }).catch(() => {});
    if (eventButtonRuns.get(tabId) === run) eventButtonRuns.delete(tabId);
  }
}

/* ============================================================
   ПЕРЕКЛЮЧАТЕЛЬ АККАУНТОВ ЕР — через chrome.cookies
   Авторизация ВВЕРХ (vverh-app.er.ru) живёт в httpOnly-куках:
     vverh_app_jwt    — access (JWT)
     vverh_app_refresh— refresh (opaque)
   обе на домене .er.ru. Из JS страницы они нечитаемы, поэтому
   читаем/пишем их здесь, в привилегированном контексте расширения.
   ============================================================ */
const ER_COOKIE_DOMAIN = '.er.ru';
const ER_JWT_NAME    = 'vverh_app_jwt';
const ER_REFRESH_NAME = 'vverh_app_refresh';
const ER_ACCOUNTS_KEY = 'erAccounts';

/* разбор payload JWT без внешних зависимостей */
const b64url = s => { try { return decodeURIComponent(escape(atob(String(s).replace(/-/g, '+').replace(/_/g, '/')))); } catch (e) { return null; } };
const decodeJwt = tok => {
  const parts = String(tok || '').split('.');
  if (parts.length < 2) return null;
  let payload = {};
  try { payload = JSON.parse(b64url(parts[1]) || '{}'); } catch (e) {}
  return { payload, exp: Number(payload.exp) || null,
    uid: payload.uid || payload.userId || payload.id || payload.user_id || payload.sub || null };
};

/* найти куку по имени на домене .er.ru */
const getErCookie = name => new Promise(res => {
  try { chrome.cookies.get({ url: 'https://vverh-app.er.ru', name }, c => res(c || null)); }
  catch (e) { res(null); }
});

/* поставить/обновить куку. Домен .er.ru, path /, те же Secure/SameSite,
   что у оригинала, expirationDate сохраняем если не задан явно. */
const setErCookie = ({ name, value, expirationDate, secure = true, sameSite = 'lax' }) => new Promise(res => {
  const details = { url: 'https://vverh-app.er.ru/', domain: ER_COOKIE_DOMAIN, path: '/', name, value, secure, httpOnly: true, sameSite };
  if (expirationDate) details.expirationDate = expirationDate;
  try { chrome.cookies.set(details, c => res(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : { ok: true, cookie: c })); }
  catch (e) { res({ ok: false, error: String(e && e.message || e) }); }
});

const removeErCookie = name => new Promise(res => {
  try { chrome.cookies.remove({ url: 'https://vverh-app.er.ru/', name }, c => res(!!c)); }
  catch (e) { res(false); }
});

/* ЗАБРАТЬ: прочитать текущие куки -> объект аккаунта для экспорта/хранения */
async function erHarvest() {
  const jwtC = await getErCookie(ER_JWT_NAME);
  if (!jwtC || !jwtC.value) throw new Error('Кука vverh_app_jwt не найдена — убедись, что ты залогинен на вкладке er.ru');
  const refC = await getErCookie(ER_REFRESH_NAME);
  const dec = decodeJwt(jwtC.value) || {};
  const p = dec.payload || {};
  const name = p.fio || p.fullName || p.name || p.username || ('uid ' + (dec.uid || '?'));
  return {
    token: jwtC.value,
    refresh: (refC && refC.value) || '',
    name,
    uid: String(dec.uid || ''),
    exp: dec.exp || null,
    jwtExp: jwtC.expirationDate || null,
    refreshExp: (refC && refC.expirationDate) || null,
  };
}

// Auth operations share one cookie jar: do not interleave two account switches.
let erAuthQueue = Promise.resolve(), erAuthBusy = false, erCookieSyncTimer = null;
const erAuthRun = job => {
  const run = erAuthQueue.then(async () => {
    erAuthBusy = true;
    try { return await job(); } finally { erAuthBusy = false; }
  });
  erAuthQueue = run.catch(() => {});
  return run;
};
const erAccountUid = acc => String(decodeJwt(acc?.token)?.uid || acc?.uid || '');
const erPairDiffers = (a, b) => a.token !== b.token || (a.refresh || '') !== (b.refresh || '');
const erCookiePair = async () => {
  const [jwt, refresh] = await Promise.all([getErCookie(ER_JWT_NAME), getErCookie(ER_REFRESH_NAME)]);
  return { jwt, refresh };
};
const erAccountFromPair = pair => ({ token: pair.jwt?.value || '', refresh: pair.refresh?.value || '',
  uid: String(decodeJwt(pair.jwt?.value)?.uid || ''), tokenExp: decodeJwt(pair.jwt?.value)?.exp || null,
  jwtExp: pair.jwt?.expirationDate || null, refreshExp: pair.refresh?.expirationDate || null,
  cookiesUpdatedAt: Date.now() });

// Never trust the active marker alone: a different user may have logged in on the site.
async function erSyncCurrentCookies() {
  const pair = await erCookiePair();
  if (!pair.jwt?.value) return pair;
  const snapshot = erAccountFromPair(pair);
  const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
  const owners = list.filter(a => snapshot.uid ? erAccountUid(a) === snapshot.uid : a.token === snapshot.token);
  if (owners.length) {
    for (const a of list) {
      if (owners.includes(a) && !(a.sessionPending && erPairDiffers(a, snapshot))) {
        if (erPairDiffers(a, snapshot)) Object.assign(a, { needsLogin: false, authError: null, bgRefreshError: null });
        Object.assign(a, snapshot);
      }
      a.active = a.id === owners[0].id;
    }
    await chrome.storage.local.set({ [ER_ACCOUNTS_KEY]: list });
  }
  return pair;
}

async function erSaveHarvest(name = '') {
  return erAuthRun(async () => {
    const snapshot = await erHarvest();
    const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
    let acc = list.find(a => snapshot.uid ? erAccountUid(a) === snapshot.uid : a.token === snapshot.token);
    if (acc?.sessionPending && erPairDiffers(acc, snapshot))
      throw new Error('Свежая сессия сохранена, но её установка ещё не подтверждена — повтори переключение этого аккаунта');
    const updated = !!acc;
    if (!acc) { acc = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), name: name || snapshot.name }; list.push(acc); }
    const label = name || acc.name || snapshot.name;
    Object.assign(acc, snapshot, { name: label, tokenExp: snapshot.exp, cookiesUpdatedAt: Date.now(),
      sessionPending: false, authError: null, needsLogin: false });
    for (const a of list) a.active = a.id === acc.id;
    await chrome.storage.local.set({ [ER_ACCOUNTS_KEY]: list });
    return { ...snapshot, name: label, id: acc.id, updated };
  });
}

async function erExportAccounts() {
  return erAuthRun(async () => {
    await erSyncCurrentCookies();
    const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
    return { version: 2, exportedAt: new Date().toISOString(), accounts: list };
  });
}

async function erImportAccounts(incoming) {
  return erAuthRun(async () => {
    if (chainRunning || (await getChain())?.running) throw new Error('Останови цепочку скриншотов перед импортом аккаунтов');
    if (!Array.isArray(incoming)) throw new Error('В файле нет массива accounts');
    const clean = incoming.filter(a => a && typeof a.token === 'string' && a.token.trim());
    if (!clean.length) throw new Error('Валидных аккаунтов с токеном не найдено');
    const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
    let added = 0, updated = 0, skippedOlder = 0;
    const positive = n => typeof n === 'number' && Number.isFinite(n) && n > 0 ? n : null;
    for (const item of clean) {
      const token = item.token.trim(), uid = String(decodeJwt(token)?.uid || '');
      let acc = list.find(a => uid ? erAccountUid(a) === uid : a.token === token);
      if (acc && Number(decodeJwt(acc.token)?.payload?.iat || 0) > Number(decodeJwt(token)?.payload?.iat || 0) &&
          Number(decodeJwt(token)?.payload?.iat || 0) > 0) { skippedOlder++; continue; }
      if (acc) updated++;
      else {
        acc = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 9), active: false };
        list.push(acc); added++;
      }
      const refresh = typeof item.refresh === 'string' ? item.refresh.trim() : '';
      const samePair = acc.token === token && (acc.refresh || '') === refresh;
      Object.assign(acc, { name: String(item.name || acc.name || 'без имени'), token, refresh, uid,
        tokenExp: decodeJwt(token)?.exp || null, jwtExp: positive(item.jwtExp), refreshExp: positive(item.refreshExp),
        lastAuthRefreshAt: positive(item.lastAuthRefreshAt), cookiesUpdatedAt: positive(item.cookiesUpdatedAt),
        // Destination cookies can belong to an older session of this same uid.
        sessionPending: true,
        // Reimporting identical credentials is not a new sign-in and cannot erase a known denial.
        ...(samePair ? {} : { authError: null, bgRefreshError: null, authWarning: null, needsLogin: false }) });
    }
    await chrome.storage.local.set({ [ER_ACCOUNTS_KEY]: list });
    return { added, updated, skippedOlder, total: list.length };
  });
}

// Server rotation changes JWT and refresh cookies in separate events; read the settled pair.
chrome.cookies?.onChanged?.addListener(change => {
  const c = change.cookie;
  if (erAuthBusy || change.removed || !c || ![ER_JWT_NAME, ER_REFRESH_NAME].includes(c.name) ||
      !/(^|\.)er\.ru$/.test(c.domain.replace(/^\./, ''))) return;
  clearTimeout(erCookieSyncTimer);
  erCookieSyncTimer = setTimeout(() => {
    erAuthRun(erSyncCurrentCookies).catch(() => console.warn('[erAuth] сохранение куки отложено'));
  }, 150);
});

/* Запись пары: refresh другого аккаунта всегда удаляется/заменяется первым. */
async function erWriteAccountCookies(acc) {
  if (!acc || !acc.token) throw new Error('у аккаунта нет токена');
  if (acc.refresh) {
    const r2 = await setErCookie({ name: ER_REFRESH_NAME, value: acc.refresh.trim(), expirationDate: acc.refreshExp || undefined });
    if (!r2.ok) throw new Error('Запись refresh-куки не подтверждена');
  } else {
    await removeErCookie(ER_REFRESH_NAME);
    if (await getErCookie(ER_REFRESH_NAME)) throw new Error('Удаление refresh-куки не подтверждено');
  }
  // Expired access may be needed only to identify the user while refreshing. Its JWT exp stays unchanged.
  const jwtExp = acc.jwtExp > Date.now() / 1000 ? acc.jwtExp : undefined;
  const r1 = await setErCookie({ name: ER_JWT_NAME, value: acc.token.trim(), expirationDate: jwtExp });
  if (!r1.ok) throw new Error('Запись куки доступа не подтверждена');
}

async function erRestorePair(pair) {
  for (const [name, c] of [[ER_REFRESH_NAME, pair.refresh], [ER_JWT_NAME, pair.jwt]]) {
    if (c) {
      const result = await setErCookie({ name, value: c.value, expirationDate: c.expirationDate,
        secure: c.secure, sameSite: c.sameSite });
      if (!result.ok) throw new Error('Восстановление исходной сессии не подтверждено');
    } else {
      await removeErCookie(name);
    }
  }
}

// Same-origin Nuxt $fetch protocol, verified in the site's public frontend bundles.
const ER_AUTH_ORIGIN = 'https://vverh-app.er.ru';
const ER_AUTH_RATE_KEY = 'erAuthRateState', ER_AUTH_VERIFIED_KEY = 'erAuthVerifiedAccess';
const ER_REFRESH_WINDOW = 120, ER_VERIFY_TTL = 60000;
const erRetryAfterMs = (value, now = Date.now()) => {
  const text = String(value || '').trim();
  if (/^-?\d+$/.test(text)) {
    const ms = Number(text) * 1000;
    return Number.isSafeInteger(ms) && ms >= 0 ? Math.max(1000, ms) : 60000;
  }
  const date = text ? Date.parse(text) : NaN;
  return Number.isFinite(date) ? Math.max(1000, date - now) : 60000;
};
const erRateState = async () => (await chrome.storage.local.get([ER_AUTH_RATE_KEY]))[ER_AUTH_RATE_KEY] || {};
const erRateError = (stage, until) => Object.assign(new Error('Сайт ограничил запросы (HTTP 429). Пауза ещё ' +
  Math.max(1, Math.ceil((until - Date.now()) / 1000)) + ' с; сессия не объявлена истёкшей'),
  { stage, status: 429, retryAt: until, loginNeeded: false });
async function erVerifiedAccess(acc) {
  const cache = (await chrome.storage.local.get([ER_AUTH_VERIFIED_KEY]))[ER_AUTH_VERIFIED_KEY] || {};
  const record = cache[acc.id], age = Date.now() - (record?.at || 0);
  return !!(record && record.token === acc.token && record.uid === erAccountUid(acc) && age >= 0 && age < ER_VERIFY_TTL);
}
async function erRememberAccess(acc, token, uid) {
  const cache = (await chrome.storage.local.get([ER_AUTH_VERIFIED_KEY]))[ER_AUTH_VERIFIED_KEY] || {};
  cache[acc.id] = { token, uid, at: Date.now() };
  // Keep only current accounts; verification metadata is never part of account exports.
  const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
  for (const id of Object.keys(cache)) if (!list.some(a => a.id === id)) delete cache[id];
  await chrome.storage.local.set({ [ER_AUTH_VERIFIED_KEY]: cache });
}
async function erAuthFailureReason(response) {
  try {
    const size = Number(response.headers?.get?.('Content-Length')) || 0;
    if (size > 16384) return 'unclassified';
    const data = await (response.clone ? response.clone() : response).json();
    const text = [data?.code, data?.error, data?.error_description, data?.message,
      data?.errors?.[0]?.code, data?.errors?.[0]?.message].filter(value => typeof value === 'string').join(' ').slice(0, 2000);
    if (/reuse|replay|already used|повторн/i.test(text)) return 'reused';
    if (/expir|ист[её]к|просроч/i.test(text)) return 'expired';
    if (/revok|отозван|invalidated/i.test(text)) return 'revoked';
    if (/not found|not exist|не найден/i.test(text)) return 'not_found';
    if (/invalid|неверн|некоррект/i.test(text)) return 'invalid';
  } catch (e) {}
  return 'unclassified';
}
const erAuthDiagnostic = e => ({ at: Date.now(), stage: String(e.stage || 'unknown'),
  status: Number(e.status) || 0, reason: String(e.serverReason || 'unclassified'), replayStopped: !!e.refreshBlocked });

async function erAuthFetch(path, init = {}) {
  const stage = path === '/api/auth/token/refresh' ? 'refresh' : path === '/api/v2/profile' ? 'profile' : 'session';
  const rate = await erRateState();
  if (rate.until > Date.now()) throw erRateError(stage, rate.until);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(ER_AUTH_ORIGIN + path, { credentials: 'include', ...init,
      headers: { 'Content-Type': 'application/json', ...init.headers }, signal: controller.signal });
    if (!response.ok) {
      if (response.status === 429) {
        const until = Date.now() + erRetryAfterMs(response.headers?.get?.('Retry-After'));
        await chrome.storage.local.set({ [ER_AUTH_RATE_KEY]: { until } });
        throw erRateError(stage, until);
      }
      const loginNeeded = stage === 'profile' && response.status === 401;
      const serverReason = await erAuthFailureReason(response);
      throw Object.assign(new Error((loginNeeded ? 'Нужен вход: сайт отклонил сессию' : 'Сайт не подтвердил сессию') +
        ' (' + stage + ', HTTP ' + response.status + ')'), { loginNeeded, stage, status: response.status, serverReason });
    }
    return path === '/inapi/update_session' ? null : await response.json();
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('Сайт не ответил за 12 секунд (' + stage + ')');
    throw e;
  } finally { clearTimeout(timeout); }
}
async function erPersistAccount(id, patch, activate = false) {
  const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
  const acc = list.find(a => a.id === id);
  if (!acc) throw new Error('Аккаунт удалён из списка во время переключения');
  Object.assign(acc, patch);
  if (activate) for (const a of list) a.active = a.id === id;
  await chrome.storage.local.set({ [ER_ACCOUNTS_KEY]: list });
  return acc;
}
const ER_REFRESH_JOURNAL_KEY = 'erRefreshJournal';
const ER_REFRESH_HISTORY_LIMIT = 32;
// Cookie persistence matches the live update_session contract; JWT exp is never modified.
const ER_SESSION_COOKIE_SECONDS = 60 * 24 * 3600;
const erRefreshFingerprint = async value => {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(value || '')));
  return Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
};
async function erRefreshJournalUpdate(id, key, patch) {
  const journal = (await chrome.storage.local.get([ER_REFRESH_JOURNAL_KEY]))[ER_REFRESH_JOURNAL_KEY] || {};
  const items = Array.isArray(journal[id]) ? journal[id] : [];
  const previous = items.find(item => item.key === key) || {};
  journal[id] = [...items.filter(item => item.key !== key), { ...previous, key, ...patch }].slice(-ER_REFRESH_HISTORY_LIMIT);
  await chrome.storage.local.set({ [ER_REFRESH_JOURNAL_KEY]: journal });
}
async function erRequestRefresh(acc, credentials) {
  const key = await erRefreshFingerprint(acc.refresh);
  const journal = (await chrome.storage.local.get([ER_REFRESH_JOURNAL_KEY]))[ER_REFRESH_JOURNAL_KEY] || {};
  const previous = (journal[acc.id] || []).find(item => item.key === key && item.phase !== 'reusable' && item.phase !== 'throttled');
  if (previous) throw Object.assign(new Error('Повтор refresh остановлен: предыдущая попытка уже выполнена или её результат неизвестен; нужна свежая сохранённая сессия'),
    { stage: 'refresh', status: previous.status || 0, refreshBlocked: true, noRefreshRetry: true });
  // Older releases have already confirmed denial for these exact saved credentials.
  if (acc.needsLogin && /refresh[^)]{0,40}HTTP (?:400|401|403)/i.test(String(acc.bgRefreshError || acc.authError || '')))
    throw Object.assign(new Error('Сайт уже отклонил этот сохранённый refresh; повторная отправка остановлена'),
      { stage: 'refresh', status: 401, refreshBlocked: true, noRefreshRetry: true });
  // Persist BEFORE transmission: a worker restart must not silently replay a potentially consumed token.
  await erRefreshJournalUpdate(acc.id, key, { phase: 'pending', at: Date.now(), status: 0 });
  try {
    return await erAuthFetch('/api/auth/token/refresh', { method: 'POST', credentials,
      body: JSON.stringify({ refresh_token: acc.refresh }) });
  } catch (e) {
    const phase = e.status === 429 ? 'throttled' : [400, 401, 403].includes(e.status) ? 'rejected' : 'uncertain';
    await erRefreshJournalUpdate(acc.id, key, { phase, status: Number(e.status) || 0, reason: String(e.serverReason || 'unclassified') });
    throw Object.assign(e, { noRefreshRetry: true });
  }
}
async function erCommitRefresh(acc, refresh) {
  const key = await erRefreshFingerprint(acc.refresh);
  await erRefreshJournalUpdate(acc.id, key, { phase: refresh === acc.refresh ? 'reusable' : 'committed', status: 200 });
}
async function erConfirmSessionCookies(acc, token, refresh) {
  let pair = await erCookiePair();
  if (pair.jwt?.value === token && pair.refresh?.value === refresh) return pair;
  const currentUid = String(decodeJwt(pair.jwt?.value)?.uid || ''), expectedUid = erAccountUid(acc);
  if (currentUid && expectedUid && currentUid !== expectedUid)
    throw new Error('Во время установки сессии cookies перешли к другому пользователю; свежая пара сохранена');
  const expiration = Date.now() / 1000 + ER_SESSION_COOKIE_SECONDS;
  // A successful cross-origin fetch can expose HTTP200 without applying Set-Cookie to the extension's jar.
  await erWriteAccountCookies({ ...acc, token, refresh, jwtExp: expiration, refreshExp: expiration });
  pair = await erCookiePair();
  if (pair.jwt?.value !== token || pair.refresh?.value !== refresh)
    throw new Error('Запись свежей пары cookies не подтвердилась; свежие токены сохранены, повтор refresh не выполняется');
  return pair;
}

async function erRefreshAccount(acc) {
  const data = await erRequestRefresh(acc, 'include');
  const token = data?.jwt?.token, refresh = data?.jwt?.refreshToken;
  const decoded = decodeJwt(token), expectedUid = erAccountUid(acc);
  if (typeof token !== 'string' || !token || typeof refresh !== 'string' || !refresh ||
      !decoded?.exp || decoded.exp <= Date.now() / 1000)
    throw new Error('Сайт вернул некорректную пару токенов');
  if (expectedUid && decoded.uid && String(decoded.uid) !== expectedUid)
    throw new Error('Обновлённая сессия принадлежит другому аккаунту');
  // Persist rotated credentials before the next request: a temporary error must not lose them.
  if (expectedUid && String(decoded.uid || '') === expectedUid) {
    await erPersistAccount(acc.id, { token, refresh, uid: expectedUid, tokenExp: decoded.exp,
      jwtExp: null, refreshExp: null, lastAuthRefreshAt: Date.now(), sessionPending: true });
    await erCommitRefresh(acc, refresh);
  }
  const profile = await erAuthFetch('/api/v2/profile', { headers: { Authorization: 'Bearer ' + token } });
  const uid = String(profile?.me?.id || '');
  if (!uid || (expectedUid && uid !== expectedUid) || (decoded.uid && String(decoded.uid) !== uid))
    throw new Error('Проверка пользователя обновлённой сессии не пройдена');
  await erPersistAccount(acc.id, { token, refresh, uid, tokenExp: decoded.exp,
    jwtExp: null, refreshExp: null, lastAuthRefreshAt: Date.now(), sessionPending: true });
  await erCommitRefresh(acc, refresh);
  await erAuthFetch('/inapi/update_session', { method: 'POST', body: JSON.stringify({ token, refreshToken: refresh }) });
  const pair = await erConfirmSessionCookies(acc, token, refresh);
  await erRememberAccess(acc, token, uid);
  return erAccountFromPair(pair);
}

async function erVerifyCurrentAccess(acc) {
  const decoded = decodeJwt(acc.token);
  if (!decoded?.exp || decoded.exp <= Date.now() / 1000) throw new Error('Нужен вход: срок токена доступа истёк');
  let uid = erAccountUid(acc);
  if (!await erVerifiedAccess(acc)) {
    const profile = await erAuthFetch('/api/v2/profile', { headers: { Authorization: 'Bearer ' + acc.token } });
    uid = String(profile?.me?.id || '');
    if (!uid || (erAccountUid(acc) && erAccountUid(acc) !== uid)) throw new Error('Проверка пользователя сессии не пройдена');
    await erRememberAccess(acc, acc.token, uid);
  }
  if (decoded.exp <= Date.now() / 1000) throw new Error('Нужен вход: срок токена доступа истёк во время проверки');
  const pair = await erCookiePair();
  if (pair.jwt?.value !== acc.token) throw new Error('Куки доступа изменились во время проверки');
  return { ...erAccountFromPair(pair), uid };
}

/* Save cookies on each switch; renew only near expiry or after a server access rejection. */
async function erApplyCookies(input) {
  return erAuthRun(async () => {
    const before = await erSyncCurrentCookies();
    const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
    const stored = list.find(a => a.id === input?.id);
    const acc = stored && { ...stored };
    if (!acc?.token) throw new Error('Аккаунт не найден или его токен пуст');
    const exp = decodeJwt(acc.token)?.exp;
    if (acc.refreshExp && acc.refreshExp <= Date.now() / 1000) acc.refresh = '';
    if (!acc.refresh && exp && exp <= Date.now() / 1000)
      throw new Error('Нужен вход в аккаунт «' + acc.name + '»: сессия истекла');
    const pause = await erRateState();
    if (pause.until > Date.now() && (before.jwt?.value !== acc.token || (before.refresh?.value || '') !== (acc.refresh || '')))
      throw erRateError('session', pause.until); // Do not leave old page UI under another account's cookies.
    try {
      await erWriteAccountCookies(acc);
      let snapshot, refreshed = false, warning = null;
      let renew = !!acc.refresh && (!exp || exp - Date.now() / 1000 <= ER_REFRESH_WINDOW);
      if (!renew) {
        try { snapshot = await erVerifyCurrentAccess(acc); }
        catch (e) {
          if (e.stage !== 'profile' || e.status !== 401 || !acc.refresh) throw e;
          renew = true;
        }
      }
      if (renew) {
        try { snapshot = await erRefreshAccount(acc); refreshed = true; }
        catch (e) {
          // A refresh rejection is not evidence that a still-live access JWT is invalid.
          // Never accept local exp alone: the server must confirm this user's profile.
          if (e.stage !== 'refresh' || (![400, 401, 403, 429].includes(e.status) && !e.refreshBlocked) || !exp || exp <= Date.now() / 1000) throw e;
          snapshot = await erVerifyCurrentAccess(acc);
          warning = 'Сессия проверена сайтом; обновление refresh отклонено (HTTP ' + e.status + '). Продление не подтверждено';
        }
      }
      const rate = await erRateState(), deferred = rate.until > Date.now();
      if (deferred) warning = 'Куки применены для недавно проверенной сессии; серверная пауза HTTP 429 — ещё ' +
        Math.ceil((rate.until - Date.now()) / 1000) + ' с. Продление отложено';
      await erPersistAccount(acc.id, { ...snapshot, needsLogin: false, authError: null, bgRefreshError: null, authWarning: warning, lastAuthVerifiedAt: Date.now(), sessionPending: false }, true);
      return { jwt: ER_JWT_NAME, refresh: snapshot.refresh ? ER_REFRESH_NAME : null,
        refreshed, warning, deferred, verified: true, uid: snapshot.uid, name: acc.name };
    } catch (e) {
      await erPersistAccount(acc.id, { authError: e.message, needsLogin: !!e.loginNeeded, authDiagnostic: erAuthDiagnostic(e) }).catch(() => {});
      await erRestorePair(before);
      throw e;
    }
  });
}

/* ОПРЕДЕЛИТЬ схему: показать какие куки авторизации сейчас есть */
async function erDetectCookies() {
  const jwtC = await getErCookie(ER_JWT_NAME);
  const refC = await getErCookie(ER_REFRESH_NAME);
  const found = [];
  if (jwtC && jwtC.value) found.push({ name: ER_JWT_NAME, kind: 'access', exp: jwtC.expirationDate || null, jwtExp: (decodeJwt(jwtC.value) || {}).exp });
  if (refC && refC.value) found.push({ name: ER_REFRESH_NAME, kind: 'refresh', exp: refC.expirationDate || null });
  return { found, hasJwt: !!(jwtC && jwtC.value), hasRefresh: !!(refC && refC.value) };
}

/* ============================================================
   СКРИНЫ ДЛЯ СОБЫТИЯ — автозагрузка из локальной папки с перебором
   аккаунтов ЕР. Попап выбирает папку (File System Access API) и
   кэширует файлы в IndexedDB этого воркера; background ведёт цепочку:
   на каждый аккаунт — применить куки (chrome.cookies), перезагрузить
   вкладку события, контентный скрипт грузит файлы по одному (данные
   отдаёт background по 'screensFile').
   Воркер может быть убит между аккаунтами: состояние цепочки живёт в
   chrome.storage.session, и после перезапуска воркера цепочка
   продолжается с того же места (уже залитые файлы пропускает
   прогресс контентного скрипта в localStorage страницы).
   ============================================================ */
const SCREENS_CHAIN_KEY = 'screensChain';
const CHAIN_TTL = 6 * 3600 * 1000; // если storage.session заменён на local — защита от «застывшей» цепочки
const sessionStore = chrome.storage.session || chrome.storage.local;
const hash36 = s => { let h = 5381; for (let i = 0; i < String(s).length; i++) h = ((h * 33) ^ String(s).charCodeAt(i)) >>> 0; return h.toString(36); };
const MIME_OF = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', avif: 'image/avif' };
const mimeOf = name => MIME_OF[String(name).split('.').pop().toLowerCase()] || 'application/octet-stream';
const b64toBuf = s => {
  const bin = atob(String(s));
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u.buffer;
};
const bufToB64 = buf => {
  const u = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
};

/* ---------- IndexedDB кэш скриншотов (живёт после перезапуска воркера) ---------- */
let idb = null;
const idbOpen = () => new Promise((res, rej) => {
  if (idb) return res(idb);
  const r = indexedDB.open('vkext_screens', 1);
  r.onupgradeneeded = () => {
    const d = r.result;
    if (!d.objectStoreNames.contains('files')) d.createObjectStore('files', { keyPath: 'name' });
    if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'key' });
  };
  r.onsuccess = () => { idb = r.result; res(idb); };
  r.onerror = () => rej(r.error || new Error('ошибка IndexedDB'));
});
const idbReq = (store, mode, reqFn) => idbOpen().then(db => new Promise((res, rej) => {
  const t = db.transaction(store, mode);
  t.oncomplete = () => res(t.__req ? t.__req.result : undefined);
  t.onerror = () => rej(t.error || new Error('ошибка IDB'));
  t.onabort = () => rej(t.error || new Error('IDB прервана'));
  try { t.__req = reqFn(t.objectStore(store)); } catch (e) { rej(e); }
}));
const idbPut = (store, v) => idbReq(store, 'readwrite', os => os.put(v));
const idbGet = (store, k) => idbReq(store, 'readonly', os => os.get(k));
const idbDel = (store, k) => idbReq(store, 'readwrite', os => os.delete(k));
const idbAll = store => idbReq(store, 'readonly', os => os.getAll());
const idbMeta = () => idbGet('meta', 'meta');
const idbSetMeta = meta => idbPut('meta', { key: 'meta', ...meta });

/* ---------- очередь скриншотов: группы по соцсети, по возрастанию номера ----------
   "vk1.png" → vk/1; "ВК_скрин_3.jpg" → vk/3; "0924_ok2.png" → ok/2.
   Соцсеть узнаётся по списку ходовых сокращений (с проверкой границ,
   чтобы "book" не стал "ok"); если сокращение не похоже на известное —
   первое буквенное слово в имени; без букв — группа «без префикса».
   Количество файлов в группе не фиксированное: сколько найдено — столько и грузится. */
const SCREEN_NETS = [
  'odnoklassniki', 'одноклассники', 'одноклассник',
  'vkontakte', 'вконтакте', 'whatsapp', 'ватсап', 'instagram', 'инстаграм',
  'tiktok', 'тикток', 'youtube', 'ютуб', 'rutube',
  'yandex', 'яндекс', 'telegram', 'телеграм', 'телеграмм', 'messenger', 'facebook', 'pinterest',
  'vk', 'вк', 'ok', 'ок', 'tg', 'тг', 'wa', 'fb', 'tt', 'inst', 'max', 'макс', 'dzen', 'дзен', 'zen',
];
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const screenNetOf = base => {
  const s = String(base || '').toLowerCase();
  for (const k of SCREEN_NETS) {
    if (new RegExp('(^|[^a-zа-яё])' + escRe(k) + '([^a-zа-яё]|$)').test(s)) return k;
  }
  const m = s.match(/[a-zа-яё]{2,}/);
  return m ? m[0] : null;
};
const NET_ALIAS = {
  vk: ['vk', 'вк', 'vkontakte', 'вконтакте'],
  ok: ['ok', 'ок', 'odnoklassniki', 'одноклассники', 'одноклассник'],
  tg: ['tg', 'тг', 'telegram', 'телеграм', 'телеграмм'],
  wa: ['wa', 'whatsapp', 'ватсап'],
  max: ['max', 'макс'],
  fb: ['fb', 'facebook'],
  inst: ['inst', 'instagram', 'инстаграм'],
  tt: ['tt', 'tiktok', 'тикток'],
};
const netGroup = k => {
  if (!k) return null;
  const s = String(k).toLowerCase();
  for (const [g, list] of Object.entries(NET_ALIAS)) if (list.includes(s)) return g;
  return s;
};
const orderScreens = (files, orderTokens) => {
  const items = files.map(f => {
    const name = String((f && f.name) || f);
    const base = name.split(/[\\/]/).pop();
    const noExt = base.replace(/\.[A-Za-z0-9]+$/, '');
    const nums = (noExt.match(/\d+/g) || ['0']).map(Number);
    return { name, base, noExt, net: screenNetOf(noExt), num: nums[nums.length - 1] };
  });
  const groups = new Map(); // groupId -> items[]
  for (const it of items) {
    const k = netGroup(it.net) || '___other___';
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(it);
  }
  const tok = String(orderTokens || '').split(/[,;]/).map(t => t.trim().toLowerCase()).filter(Boolean);
  const orderedKeys = [];
  if (tok.length) {
    for (const t of tok) {
      const g = netGroup(t) || t;
      const k = [...groups.keys()].find(k => k === g || k === t);
      if (k && !orderedKeys.includes(k)) orderedKeys.push(k);
    }
    for (const k of [...groups.keys()].sort((a, b) => a.localeCompare(b, 'ru'))) if (!orderedKeys.includes(k)) orderedKeys.push(k);
  } else {
    // без указания — порядок, в котором пользователь подписал файлы (по имени)
    const firstName = key => groups.get(key).map(i => i.base)
      .sort((a, b) => a.localeCompare(b, 'ru', { numeric: true }))[0];
    for (const k of [...groups.keys()].sort((a, b) => firstName(a).localeCompare(firstName(b), 'ru', { numeric: true })))
      orderedKeys.push(k);
  }
  const out = [];
  for (const k of orderedKeys) {
    groups.get(k).sort((a, b) => (a.num - b.num) || a.name.localeCompare(b.name, 'ru', { numeric: true }));
    out.push(...groups.get(k));
  }
  return out.map(i => i.name);
};
const planScreens = (files, orderTokens) => {
  const order = orderScreens(files, orderTokens);
  const cnt = new Map();
  const unrecognized = [];
  for (const name of order) {
    const base = String(name).split(/[\\/]/).pop().replace(/\.[A-Za-z0-9]+$/, '');
    const net = screenNetOf(base);
    if (!SCREEN_NETS.includes(net)) unrecognized.push(name);
    const g = netGroup(net) || 'без префикса';
    cnt.set(g, (cnt.get(g) || 0) + 1);
  }
  return { order, unrecognized, summary: [...cnt.entries()].map(([k, v]) => k + ': ' + v).join(' · ') };
};
/* одна группа = одна форма/отправка на сайте. Больше 6 файлов по соцсети —
   разбиваем на несколько действий по 6 (3 файла — одно действие на 3). */
const SCREEN_CHUNK = 6;
const groupOrder = fileOrder => {
  const g = [];
  for (const name of fileOrder) {
    const base = String(name).split(/[\\/]/).pop().replace(/\.[A-Za-z0-9]+$/, '');
    const net = netGroup(screenNetOf(base)) || '';
    const last = g[g.length - 1];
    if (last && last.net === net && last.items.length < SCREEN_CHUNK) last.items.push(name);
    else g.push({ net, items: [name] });
  }
  return g;
};
const screenResultComplete = (result, total) => !!(result && result.ok === true &&
  result.okCount === total && !result.failCount && !result.stopped);

/* ---------- цепочка аккаунтов ---------- */
const getChain = async () => (await sessionStore.get([SCREENS_CHAIN_KEY]))[SCREENS_CHAIN_KEY] || null;
const saveChain = st => sessionStore.set({ [SCREENS_CHAIN_KEY]: st });

let chainRunning = false;

const ensureEventTab = async eventUrl => {
  let [tab] = await chrome.tabs.query({ url: eventUrl + '*' });
  let created = false;
  if (!tab) { tab = await chrome.tabs.create({ url: eventUrl, active: true }); created = true; }
  else await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
  if (!created) await chrome.tabs.reload(tab.id).catch(() => {}); // новые куки аккаунта подхватит только после перезагрузки
  let alive = null;
  for (let i = 0; i < 20 && (!alive || alive.screensVersion !== '1.4.14'); i++) {
    await sleep(1000);
    alive = await tabSend(tab.id, { type: 'ping' });
    if (!alive && (i === 3 || i === 9)) await inject(tab.id);
  }
  if (!alive) throw new Error('вкладка события не отвечает — обнови её (F5) и нажми «Продолжить»');
  if (alive.screensVersion !== '1.4.14') throw new Error('Обнови вкладку события после перезагрузки расширения для исправленного нажатия кнопки участия');
  return tab.id;
};

/* Цепочка перезагружает вкладку события перед каждым аккаунтом. Если на ней ещё идёт прошлая
   задача скринов (воркер перезапустили посреди аккаунта, «Продолжить» нажали раньше времени),
   перезагрузка оборвёт отправку между кликом и подтверждением и группа зальётся повторно —
   ждём конца задачи. Затем даём вкладке сохранить ручную отправку зависшей группы. */
const quiesceScreensTabs = async eventUrl => {
  for (let n = 0; n < 720; n++) {
    const tabs = await chrome.tabs.query({ url: eventUrl + '*' }).catch(() => []);
    const pings = await Promise.all(tabs.map(t => tabSend(t.id, { type: 'ping' })));
    if (!pings.some(p => p && p.status && p.status.running && p.status.mode === 'screens')) {
      await Promise.all(tabs.map(t => Promise.race([tabSend(t.id, { type: 'screensSettle' }), sleep(15000)])));
      return;
    }
    const st = await getChain();
    if (!st || !st.running || st.stopped) return;
    await sleep(5000);
  }
};

const runScreensChain = async () => {
  if (chainRunning) return;
  chainRunning = true;
  try { chrome.alarms.create('vkScreensKeep', { periodInMinutes: 0.5 }); } catch (e) {}
  try {
    for (;;) {
      let st = await getChain();
      if (!st || !st.running || st.stopped) break;
      await quiesceScreensTabs(st.eventUrl);
      st = await getChain();
      if (!st || !st.running || st.stopped) break;
      const i = st.accountIdx | 0;
      if (i >= st.accounts.length) break;
      const acc = st.accounts[i];

      const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
      const full = list.find(a => a.id === acc.id);
      if (!full) throw new Error('аккаунт «' + acc.name + '» не найден в списке');
      const applied = await erApplyCookies(full);
      if (applied.deferred) throw erRateError('session', (await erRateState()).until);

      st.progress = st.progress || [];
      st.progress[i] = Object.assign({}, st.progress[i], { name: acc.name, inFlight: true, ts: Date.now() });
      await saveChain(st);

      const tabId = await ensureEventTab(st.eventUrl);
      const taskMsg = { type: 'screens', total: st.fileOrder.length, queueHash: st.queueHash, account: acc.name, accountId: acc.id, names: st.fileOrder, groups: groupOrder(st.fileOrder) };
      let r = await tabSend(tabId, taskMsg);
      if (r && r.business) {
        // на вкладке ещё живёт предыдущая задача (напр. воркера убили, а вкладка осталась) — ждём её конца
        let tries = 0;
        while (r && r.business && tries < 72) { await sleep(5000); r = await tabSend(tabId, taskMsg); tries++; }
      }
      if (!r) { await inject(tabId); await sleep(1000); r = await tabSend(tabId, taskMsg); }
      if (!r) throw new Error('вкладка события не отвечает');

      let doneOk = false;
      if (!r.stopped && !screenResultComplete(r, st.fileOrder.length)) {
        r.error = r.error || ('Подтверждено только ' + (r.okCount || 0) + '/' + st.fileOrder.length + ' скриншотов — переход к следующему аккаунту остановлен');
        st.progress[i] = { name: acc.name, ok: false, okCount: r.okCount | 0, failCount: r.failCount | 0, done: false, error: r.error || 'ошибка', ts: Date.now() };
        await saveChain(st);
        throw new Error('аккаунт «' + acc.name + '»: ' + (r.error || 'ошибка загрузки'));
      }
      doneOk = !r.stopped;
      st.progress[i] = { name: acc.name, ok: doneOk, okCount: r.okCount | 0, failCount: r.failCount | 0, done: doneOk, stopped: !!r.stopped, ts: Date.now() };
      st.accountIdx = doneOk ? i + 1 : i;
      await saveChain(st);
      if (!doneOk || (await getChain()).stopped) break;
      await sleep(1500);
    }

    const st = await getChain();
    if (st && st.running) {
      st.running = false;
      st.finished = st.accountIdx >= st.accounts.length;
      st.ts = Date.now();
      if (st.options && st.options.restoreFirst && st.accounts.length > 1) {
        const lastIdx = Math.min(st.accountIdx, st.accounts.length) - 1;
        if (lastIdx !== 0) {
          const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
          if (list[0]) {
            await erApplyCookies(list[0]).catch(e => console.warn('[screensChain] вернуть первый аккаунт не удалось:', e));
            try { const t = await chrome.tabs.query({ url: st.eventUrl + '*' }); if (t[0]) chrome.tabs.reload(t[0].id).catch(() => {}); } catch (e) {}
          }
        }
      }
      await saveChain(st);
    }
  } catch (e) {
    console.error('[screensChain]', e);
    const st = await getChain();
    if (st && st.running) {
      st.running = false;
      st.error = String((e && e.message) || e);
      st.ts = Date.now();
      await saveChain(st);
    }
  } finally {
    chainRunning = false;
    try { chrome.alarms.clear('vkScreensKeep'); } catch (e) {}
  }
};

/* воркер мог быть убит между аккаунтами: при каждом пробуждении (в т.ч. по
   keep-alive аларму) продолжаем цепочку с сохранённого места */
const maybeResumeChain = () => {
  (async () => {
    const st = await getChain();
    if (st && st.running && !st.stopped && !chainRunning && Date.now() - (st.ts || 0) < CHAIN_TTL) runScreensChain();
  })().catch(() => {});
};
maybeResumeChain();
try {
  chrome.alarms.onAlarm.addListener(al => { if (al && al.name === 'vkScreensKeep') maybeResumeChain(); });
} catch (e) {}

/* ============================================================
   ФОНОВОЕ ПРОДЛЕНИЕ СЕССИЙ ЕР (таймер chrome.alarms)
   Цель: refresh-токены аккаунтов, на которые давно не переключались, не должны протухать.
   Порядок для неактивного аккаунта:
     1) «отвязанный» refresh: запрос без кук (credentials: 'omit'), токен только в теле.
        Куки браузера и активная сессия вообще не трогаются.
     2) если сайт так не принимает — временная подмена кук (как при переключении)
        с обязательным возвратом исходной пары. Только когда не идёт заливка/скрины.
   Активный аккаунт продлевается своим обычным путём, и только если вкладка ЕР не открыта
   (иначе сайт продлевает его сам) и не идёт задача.
   ============================================================ */
const ER_BG_ALARM = 'erBgRefresh', ER_BG_KEY = 'erBgRefreshSettings', ER_BG_STATE_KEY = 'erBgRefreshState';
const ER_BG_DEFAULTS = { enabled: true, periodMin: 180 };
const ER_BG_MAX_AGE = 24 * 3600 * 1000; // даже со свежим access — продлить хотя бы раз в сутки
const erBgSettings = async () => ({ ...ER_BG_DEFAULTS, ...((await chrome.storage.local.get([ER_BG_KEY]))[ER_BG_KEY] || {}) });
const erBgPeriod = s => Math.min(1440, Math.max(30, Number(s.periodMin) || ER_BG_DEFAULTS.periodMin));

async function erBgSchedule(reset = false) {
  try {
    if (!chrome.alarms || typeof chrome.alarms.create !== 'function') return;
    const s = await erBgSettings();
    const existing = typeof chrome.alarms.get === 'function' ? await chrome.alarms.get(ER_BG_ALARM) : null;
    if (!s.enabled) { if (existing && chrome.alarms.clear) await chrome.alarms.clear(ER_BG_ALARM); return; }
    if (existing && !reset && existing.periodInMinutes === erBgPeriod(s)) return;
    if (existing && chrome.alarms.clear) await chrome.alarms.clear(ER_BG_ALARM);
    chrome.alarms.create(ER_BG_ALARM, { delayInMinutes: 2, periodInMinutes: erBgPeriod(s) });
  } catch (e) { console.warn('[erBg] таймер не поставлен', e); }
}

const erTasksBusy = async () => {
  const s = await chrome.storage.local.get(['vkExtStatusUpload', 'vkExtStatusScreens']);
  const fresh = st => !!(st && st.running && Date.now() - (st.ts || 0) < 180000);
  let chain = null; try { chain = await getChain(); } catch (e) {}
  return fresh(s.vkExtStatusUpload) || fresh(s.vkExtStatusScreens) || chainRunning || !!(chain && chain.running && !chain.stopped);
};

async function erRefreshDetached(acc) {
  const data = await erRequestRefresh(acc, 'omit');
  const token = data?.jwt?.token, refresh = data?.jwt?.refreshToken;
  const decoded = decodeJwt(token), expectedUid = erAccountUid(acc);
  if (typeof token !== 'string' || !token || typeof refresh !== 'string' || !refresh ||
      !decoded?.exp || decoded.exp <= Date.now() / 1000)
    throw Object.assign(new Error('Сайт вернул некорректную пару токенов'), { detachedUnsupported: true });
  if (expectedUid && decoded.uid && String(decoded.uid) !== expectedUid)
    throw Object.assign(new Error('Обновлённая сессия принадлежит другому аккаунту'), { rotated: true });
  // Старый refresh уже недействителен — сохраняем новую пару до любых проверок.
  await erPersistAccount(acc.id, { token, refresh, uid: expectedUid || String(decoded.uid || ''), tokenExp: decoded.exp,
    jwtExp: null, refreshExp: null, lastAuthRefreshAt: Date.now(), sessionPending: true });
  await erCommitRefresh(acc, refresh);
  try {
    const profile = await erAuthFetch('/api/v2/profile', { credentials: 'omit', headers: { Authorization: 'Bearer ' + token } });
    const uid = String(profile?.me?.id || '');
    if (!uid || (expectedUid && uid !== expectedUid)) throw new Error('Проверка пользователя обновлённой сессии не пройдена');
    await erPersistAccount(acc.id, { uid });
    await erRememberAccess({ ...acc, token }, token, uid);
  } catch (e) { throw Object.assign(e, { rotated: true }); }
}

// Refresh rejection alone does not invalidate an access token. Verify it without changing the shared jar.
async function erVerifyRefreshFallback(acc, failure) {
  if (failure.rotated || failure.stage !== 'refresh' || (![400, 401, 403].includes(failure.status) && !failure.refreshBlocked)) throw failure;
  const exp = decodeJwt(acc.token)?.exp;
  if (!exp || exp <= Date.now() / 1000) {
    if (![400, 401, 403].includes(failure.status)) throw failure;
    throw Object.assign(new Error('Нужен вход: токен доступа истёк, а сайт отклонил продление (refresh, HTTP ' + failure.status + ')'),
      { stage: 'refresh', status: failure.status, loginNeeded: true });
  }
  const profile = await erAuthFetch('/api/v2/profile', { credentials: 'omit', headers: { Authorization: 'Bearer ' + acc.token } });
  const uid = String(profile?.me?.id || '');
  if (!uid || !erAccountUid(acc) || uid !== erAccountUid(acc)) throw new Error('Проверка пользователя действующей сессии не пройдена');
  const warning = 'Сессия проверена сайтом и действует; refresh отклонён (HTTP ' + failure.status + '). Продление не подтверждено';
  await erRememberAccess(acc, acc.token, uid);
  await erPersistAccount(acc.id, { needsLogin: false, authError: null, authWarning: warning, lastAuthVerifiedAt: Date.now() });
}

let erBgRunning = false;
async function erBgTick(force = false) {
  if (erBgRunning) return { ok: false, error: 'продление уже идёт' };
  const s = await erBgSettings();
  if (!s.enabled && !force) return { ok: false, error: 'автопродление выключено' };
  erBgRunning = true;
  const report = { at: Date.now(), force, refreshed: 0, verified: 0, warnings: 0, skipped: 0, failed: 0, needLogin: 0, items: [] };
  const note = (a, result, extra = '') => report.items.push({ id: a.id, name: a.name, result, extra });
  try {
    const rate = await erRateState();
    if (rate.until > Date.now()) { report.note = 'сайт попросил паузу (429), продление отложено'; return report; }
    const busy = await erTasksBusy();
    let erTabs = [];
    try { erTabs = await chrome.tabs.query({ url: ['https://vverh-app.er.ru/*', 'https://*.er.ru/*'] }); } catch (e) {}
    try { await erAuthRun(erSyncCurrentCookies); } catch (e) {}
    const period = erBgPeriod(s) * 60;
    const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
    for (const a0 of list) {
      const now = Date.now() / 1000;
      if (!a0.refresh || (a0.refreshExp && a0.refreshExp <= now)) {
        const exp = decodeJwt(a0.token)?.exp || 0;
        if (exp && exp <= now) { report.needLogin++; note(a0, 'needLogin'); } else { report.skipped++; note(a0, 'noRefresh'); }
        continue;
      }
      const exp = decodeJwt(a0.token)?.exp || 0;
      const due = force || !exp || exp - now < period + 1800 || Date.now() - (a0.lastAuthRefreshAt || a0.cookiesUpdatedAt || 0) > ER_BG_MAX_AGE;
      if (!due) { report.skipped++; note(a0, 'fresh'); continue; }
      if (a0.active && (erTabs.length || busy)) { report.skipped++; note(a0, 'activeHandledBySite'); continue; }
      let mode = null;
      try {
        await erAuthRun(async () => {
          const cur = ((await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || []).find(x => x.id === a0.id);
          if (!cur || !cur.refresh) throw new Error('аккаунт изменился во время продления');
          const acc = { ...cur };
          try {
            if (acc.active) {
              await erRefreshAccount(acc); await erPersistAccount(acc.id, { sessionPending: false }); mode = 'active';
              return;
            }
            await erRefreshDetached(acc); mode = 'detached';
          } catch (e) {
            await erVerifyRefreshFallback(acc, e); mode = 'verified';
          }
        });
        await erPersistAccount(a0.id, { bgRefreshAt: Date.now(), bgRefreshError: null, bgRefreshMode: mode,
          ...(mode === 'verified' ? {} : { needsLogin: false, authError: null, authWarning: null }) });
        if (mode === 'verified') { report.verified++; report.warnings++; note(a0, 'verified', 'access действует; продление не подтверждено'); }
        else { report.refreshed++; note(a0, 'ok', mode); }
      } catch (e) {
        const msg = String((e && e.message) || e);
        if (e && e.deferred) { report.skipped++; note(a0, 'deferred', msg); }
        else {
          report.failed++; if (e.loginNeeded) report.needLogin++; note(a0, e.loginNeeded ? 'needLogin' : 'error', msg);
          try { await erPersistAccount(a0.id, { bgRefreshError: msg, bgRefreshFailedAt: Date.now(), authDiagnostic: erAuthDiagnostic(e), ...(e.loginNeeded ? { needsLogin: true } : {}) }); } catch (_) {}
        }
        if (e && e.status === 429) { report.note = 'сайт попросил паузу (429), остальные аккаунты — в следующий раз'; break; }
      }
      await sleep(3000 + Math.floor(Math.random() * 5000)); // не долбим сайт пачкой
    }
    return report;
  } finally {
    erBgRunning = false;
    report.finishedAt = Date.now();
    try { await chrome.storage.local.set({ [ER_BG_STATE_KEY]: report }); } catch (e) {}
  }
}

try {
  chrome.alarms?.onAlarm?.addListener(al => { if (al && al.name === ER_BG_ALARM) erBgTick().catch(e => console.warn('[erBg]', e)); });
} catch (e) {}
try { chrome.runtime?.onStartup?.addListener(() => erBgSchedule()); } catch (e) {}
try { chrome.runtime?.onInstalled?.addListener(() => erBgSchedule()); } catch (e) {}
erBgSchedule();

/* One writer prevents lost increments across tabs and account switches. */
const ensureReportObservers = async () => {
  if (!chrome.scripting?.executeScript || !chrome.tabs?.query) return;
  const tabs = await chrome.tabs.query({ url: 'https://vverh-app.er.ru/*' });
  await Promise.all(tabs.map(tab => chrome.scripting.executeScript({
    target: { tabId: tab.id }, files: ['report_counter.js']
  }).catch(() => {})));
};
try { chrome.runtime.onInstalled?.addListener(() => {
  ensureReportObservers().catch(e => console.warn('[reportCounter] ' + e.message));
}); } catch (e) {}

const REPORT_COUNTER_KEY = 'vkReportCounter';
const REPORT_RECEIPT_LIMIT = 4096;
let reportCounterWrites = Promise.resolve();
const readReportCounterState = async now => {
  const stored = (await chrome.storage.local.get([REPORT_COUNTER_KEY]))[REPORT_COUNTER_KEY];
  if (stored != null && (stored.version !== 1 || !Number.isSafeInteger(stored.total) || stored.total < 0 ||
    !Array.isArray(stored.receipts) || !Number.isFinite(stored.since)))
    throw new Error('Повреждены данные счётчика отчётов — итог не изменён');
  return stored || { version: 1, total: 0, since: now, receipts: [] };
};
const recordCreatedReport = (msg, sender) => {
  const run = reportCounterWrites.then(async () => {
    const url = new URL(sender.url || '');
    if (url.origin !== 'https://vverh-app.er.ru')
      throw new Error('Подтверждение отчёта пришло не со страницы события');
    const now = Date.now();
    if (!/^report-[a-zA-Z0-9-]{12,100}$/.test(String(msg.id || '')) ||
        !/^\d{1,20}$/.test(String(msg.eventId || '')) ||
        !Number.isFinite(msg.startedAt) || !Number.isFinite(msg.confirmedAt) ||
        msg.startedAt > msg.confirmedAt || msg.confirmedAt > now + 5000 ||
        now - msg.confirmedAt > 10 * 60 * 1000 || msg.confirmedAt - msg.startedAt > 5 * 60 * 1000)
      throw new Error('Некорректное или устаревшее подтверждение отчёта');
    const state = await readReportCounterState(now);
    if (state.resetAt && msg.confirmedAt <= state.resetAt)
      return { ok: true, added: false, total: state.total, reason: 'before-reset' };
    if (state.receipts.includes(msg.id)) return { ok: true, added: false, total: state.total };
    if (state.total === Number.MAX_SAFE_INTEGER) throw new Error('Достигнут предел счётчика отчётов');
    const next = { ...state, total: state.total + 1, updatedAt: now,
      receipts: [...state.receipts, msg.id].slice(-REPORT_RECEIPT_LIMIT) };
    await chrome.storage.local.set({ [REPORT_COUNTER_KEY]: next });
    return { ok: true, added: true, total: next.total };
  });
  reportCounterWrites = run.catch(() => {});
  return run;
};

// Reset uses the same writer queue as increments; old receipts cannot refill a cleared total.
const resetReportCounter = sender => {
  const run = reportCounterWrites.then(async () => {
    if (sender.id !== chrome.runtime.id ||
        String(sender.url || '').split(/[?#]/)[0] !== chrome.runtime.getURL('popup.html'))
      throw new Error('Сброс доступен только из панели расширения');
    const now = Date.now();
    const state = await readReportCounterState(now);
    const next = { ...state, total: 0, since: now, updatedAt: now, resetAt: now };
    await chrome.storage.local.set({ [REPORT_COUNTER_KEY]: next });
    return { ok: true, total: 0, since: now };
  });
  reportCounterWrites = run.catch(() => {});
  return run;
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'reportCounterReset') {
    resetReportCounter(sender)
      .then(sendResponse, e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'reportCounterRecord') {
    recordCreatedReport(msg, sender)
      .then(sendResponse, e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'uploadDraftMerge') {
    mergeUploadDraft(msg.links)
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'uploadDraftSet') {
    updateUploadDraft(msg.value, msg.base)
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'erBgGet') {
    Promise.all([erBgSettings(), chrome.storage.local.get([ER_BG_STATE_KEY]),
      (chrome.alarms && typeof chrome.alarms.get === 'function') ? chrome.alarms.get(ER_BG_ALARM) : null])
      .then(([settings, st, alarm]) => sendResponse({ ok: true, settings, running: erBgRunning,
        last: st[ER_BG_STATE_KEY] || null, next: alarm ? alarm.scheduledTime : null }))
      .catch(e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'erBgSet') {
    (async () => {
      const cur = await erBgSettings();
      const next = { enabled: msg.enabled === undefined ? cur.enabled : !!msg.enabled,
        periodMin: msg.periodMin === undefined ? cur.periodMin : erBgPeriod({ periodMin: msg.periodMin }) };
      await chrome.storage.local.set({ [ER_BG_KEY]: next });
      await erBgSchedule(true);
      return { ok: true, settings: next };
    })().then(sendResponse, e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'erBgNow') {
    erBgTick(true).then(r => sendResponse({ ok: true, report: r }), e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg && msg.type === 'vkApiSearch') {
    vkApiRequest(String(msg.token || '').trim(), msg.params || {})
      .then(sendResponse).catch(e => sendResponse({ error: { error_msg: String((e && e.message) || e) } }));
    return true;
  }
  if (msg && msg.type === 'vkApiStart') {
    runVkApiParse(msg).then(sendResponse).catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'vkApiStop') {
    vkApiStop = true;
    sendResponse({ ok: true });
    return true;
  }
  if (msg && msg.type === 'vkApiStatus') {
    chrome.storage.local.get([VK_API_STATUS_KEY, VK_API_RESULT_KEY])
      .then(data => sendResponse({ ok: true, status: data[VK_API_STATUS_KEY] || null,
        result: data[VK_API_RESULT_KEY] || null }))
      .catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'uploadToEvent') {
    uploadToEvent(msg).then(sendResponse).catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // асинхронный ответ
  }
  if (msg && msg.type === 'virtualCursor') {
    virtualCursor(msg, sender).then(sendResponse).catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'eventButtonClick') {
    eventButtonClick(msg, sender).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'eventButtonStop') { sendResponse(eventButtonStop(sender)); return; }
  if (msg && msg.type === 'erHarvestBg') {
    (msg.save ? erSaveHarvest(String(msg.name || '').trim()) : erHarvest()).then(r => sendResponse({ ok: true, ...r })).catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  if (msg && ['erExportAccountsBg', 'erImportAccountsBg'].includes(msg.type)) {
    (msg.type === 'erExportAccountsBg' ? erExportAccounts() : erImportAccounts(msg.accounts))
      .then(r => sendResponse({ ok: true, ...r })).catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'erSwitchBg') {
    (async () => {
      if (chainRunning || (await getChain())?.running) throw new Error('Сначала останови цепочку скриншотов перед ручным переключением аккаунта');
      const { [ER_ACCOUNTS_KEY]: list = [] } = await chrome.storage.local.get([ER_ACCOUNTS_KEY]);
      const acc = list.find(a => a.id === msg.id);
      if (!acc) throw new Error('аккаунт не найден');
      const applied = await erApplyCookies(acc);
      // перезагрузить активную вкладку er.ru, чтобы SPA подхватила новые куки
      let reloaded = false;
      if (msg.reload !== false && !applied.deferred) {
        const tabs = await chrome.tabs.query({ url: '*://*.er.ru/*' });
        const act = tabs.find(t => t.active) || tabs[0];
        if (act) { await chrome.tabs.reload(act.id); reloaded = true; }
      }
      sendResponse({ ok: true, name: acc.name, applied, refreshed: applied.refreshed, reload: reloaded });
    })().catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'erDetectBg') {
    erDetectCookies().then(r => sendResponse({ ok: true, ...r })).catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  /* ---------- СКРИНЫ: кэш файлов из папки ---------- */
  if (msg && msg.type === 'screensTest') {
    const d = msg.data;
    sendResponse({ ok: d instanceof ArrayBuffer && d.byteLength === 8, isAB: d instanceof ArrayBuffer, len: d ? d.byteLength : null });
    return;
  }
  if (msg && msg.type === 'screensMeta') {
    idbMeta()
      .then(m => sendResponse({ ok: true, dirName: m && m.dirName, pickedAt: m && m.pickedAt, files: (m && m.files) || [] }))
      .catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'screensCache') {
    (async () => {
      if ((await getChain())?.running) throw new Error('цепочка работает — останови её перед сменой папки');
      let data = msg.data;
      if (!(data instanceof ArrayBuffer)) {
        if (typeof msg.b64 === 'string' && msg.b64.length) data = b64toBuf(msg.b64);
        else throw new Error('некорректные данные: ожидался ArrayBuffer');
      }
      if (!data.byteLength) throw new Error('пустой файл: ' + msg.name);
      await idbPut('files', { name: String(msg.name), data, size: data.byteLength, mtime: Number(msg.mtime) || 0, ts: Date.now() });
      sendResponse({ ok: true, idx: msg.idx | 0, total: msg.total | 0 });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'screensCacheEnd') {
    (async () => {
      if ((await getChain())?.running) throw new Error('цепочка работает — останови её перед сменой папки');
      const files = (msg.files || []).map(f => ({ name: String(f.name), size: Number(f.size) || 0, mtime: Number(f.mtime) || 0 }));
      const seen = new Set(files.map(f => f.name));
      if (seen.size !== files.length) throw new Error('повторяющиеся пути файлов в папке — выбери папку заново');
      const all = (await idbAll('files')) || [];
      for (const rec of all) if (!seen.has(rec.name)) await idbDel('files', rec.name);
      await idbSetMeta({ dirName: String(msg.dirName || 'папка'), files, pickedAt: Date.now() });
      sendResponse({ ok: true, files: files.length });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'screensPlan') {
    (async () => {
      let files = msg.files;
      if (!Array.isArray(files) || !files.length) {
        const m = await idbMeta();
        files = (m && m.files) || [];
      }
      const { order, summary, unrecognized } = planScreens(files, msg.orderTokens);
      sendResponse({ ok: true, order, summary, unrecognized, groups: groupOrder(order), total: order.length });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  /* ---------- СКРИНЫ: цепочка по аккаунтам ---------- */
  if (msg && msg.type === 'screensStart') {
    (async () => {
      const prev = await getChain();
      if (prev && prev.running) throw new Error('цепочка уже работает — дождись или нажми «⏹»');
      const list = (await chrome.storage.local.get([ER_ACCOUNTS_KEY]))[ER_ACCOUNTS_KEY] || [];
      if (!list.length) throw new Error('нет аккаунтов ЕР — добавь хотя бы один в карточке «Аккаунты ЕР»');
      const meta = await idbMeta();
      if (!meta || !meta.files || !meta.files.length) throw new Error('нет закэшированных скриншотов — выбери папку кнопкой «📂 Выбрать папку»');
      const u = new URL(msg.eventUrl);
      if (!/(^|\.)er\.ru$/.test(u.hostname) || !/^\/events\/\d+/.test(u.pathname)) throw new Error('URL события должен быть вида …/events/XXXXX');
      const { order: fileOrder, unrecognized } = planScreens(meta.files, msg.orderTokens);
      if (unrecognized.length) throw new Error('Соцсеть не распознана в именах: ' + unrecognized.join(', ') + '. Подпиши файлы тг / вк / ок / макс и номером');
      const byName = new Map(meta.files.map(file => [file.name, file]));
      if (byName.size !== fileOrder.length) throw new Error('повторяющиеся пути файлов — выбери папку заново');
      for (const name of fileOrder) {
        const rec = await idbGet('files', name), expected = byName.get(name);
        if (!rec?.data?.byteLength || rec.data.byteLength !== expected.size || rec.mtime !== expected.mtime)
          throw new Error('неполный или изменённый кэш: ' + name + ' — выбери папку заново');
      }
      const accounts = list.map(a => ({ id: a.id, name: a.name }));
      if (msg.single) {
        // «только текущий аккаунт» — льём на один (активный; если его нет — первый)
        const ai = accounts.findIndex(a => a.id === (list.find(x => x.active) || {}).id);
        const pick = ai >= 0 ? accounts[ai] : accounts[0];
        accounts.length = 0;
        accounts.push(pick);
      } else if (msg.fromCurrent) {
        const ai = accounts.findIndex(a => a.id === (list.find(x => x.active) || {}).id);
        if (ai > 0) accounts.push(...accounts.splice(0, ai));
      }
      const chain = {
        eventUrl: msg.eventUrl, fileOrder,
        queueHash: hash36(JSON.stringify(fileOrder.map(name => [name, byName.get(name).size, byName.get(name).mtime]))),
        accounts, accountIdx: 0, progress: [],
        options: { restoreFirst: !!msg.restoreFirst, single: !!msg.single },
        running: true, stopped: false, finished: false, error: null,
        startedAt: Date.now(), ts: Date.now(),
      };
      await saveChain(chain);
      runScreensChain();
      sendResponse({ ok: true, accounts: accounts.length, files: fileOrder.length, single: !!msg.single });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'screensStop') {
    (async () => {
      const st = await getChain();
      if (st && st.running) { st.stopped = true; st.ts = Date.now(); await saveChain(st); }
      const tabs = await chrome.tabs.query({});
      for (const t of tabs) { try { chrome.tabs.sendMessage(t.id, { type: 'stop' }, () => void chrome.runtime.lastError); } catch (e) {} }
      sendResponse({ ok: true });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'screensResume') {
    (async () => {
      const st = await getChain();
      if (!st) throw new Error('нет цепочки — сначала нажми «🖼 Залить скрины»');
      if (st.running) throw new Error('цепочка уже работает');
      if (Date.now() - (st.ts || 0) > CHAIN_TTL) throw new Error('цепочка устарела — нажми «🖼 Залить скрины» заново');
      let i = 0;
      while (i < st.accounts.length && st.progress && st.progress[i] && st.progress[i].done) i++;
      if (i >= st.accounts.length) throw new Error('все аккаунты уже обработаны');
      st.accountIdx = i; st.running = true; st.stopped = false; st.error = null; st.finished = false; st.ts = Date.now();
      await saveChain(st);
      runScreensChain();
      sendResponse({ ok: true, from: i, account: st.accounts[i].name, total: st.accounts.length });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg && msg.type === 'screensFile') {
    (async () => {
      const st = await getChain();
      if (!st || st.queueHash !== msg.queueHash) throw new Error('нет активной очереди (цепочка перезапущена?)');
      const i = msg.i | 0;
      const name = st.fileOrder[i];
      if (!name) throw new Error('нет файла под номером ' + i + ' в очереди');
      const rec = await idbGet('files', name);
      if (!rec || !rec.data) throw new Error('файл «' + name + '» не в кэше — выбери папку заново в попапе');
      // data — ArrayBuffer (если сообщения идут structured-clone); b64 — если канал сериализует JSON
      if (msg.b64) sendResponse({ ok: true, name, b64: bufToB64(rec.data), mime: mimeOf(name), i, total: st.fileOrder.length });
      else sendResponse({ ok: true, name, data: rec.data, mime: mimeOf(name), i, total: st.fileOrder.length });
    })().catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
});
