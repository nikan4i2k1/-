/* probe-token.js — разведчик хранилища авторизации vverh-app.er.ru
   Как пользоваться:
     1. Зайди на https://vverh-app.er.ru/ и ВОЙДИ в аккаунт.
     2. F12 → Console → вставь весь этот файл целиком и Enter.
     3. Он выведет таблицу всех найденных токенов/сессий с точными ключами.
     4. Скопируй вывод и пришли — по нему я подгоню переключатель под реальное
        хранилище сайта (сейчас оно настроено эвристически). */
(() => {
  const JWT = /^[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+$/; // три base64url-сегмента
  const looksJwt = v => typeof v === 'string' && JWT.test(v.trim());
  const decode = tok => {
    try {
      const [, payload] = tok.split('.');
      const json = JSON.parse(decodeURIComponent(escape(atob(payload.replace(/-/g, '+').replace(/_/g, '/')))));
      return json;
    } catch (e) { return null; }
  };
  const KEYWORDS = /(token|auth|jwt|bearer|session|access|refresh|id_?tkn|credential|user)/i;

  const dumpStore = (name, store) => {
    const out = [];
    if (!store) return out;
    for (let i = 0; i < store.length; i++) {
      const key = store.key(i);
      let raw = '';
      try { raw = store.getItem(key) || ''; } catch (e) {}
      let val = raw, parsed = null;
      try { parsed = JSON.parse(raw); } catch (e) {}
      if (parsed && typeof parsed === 'object') val = JSON.stringify(parsed);
      const isJwt = looksJwt(raw) || (typeof parsed?.value === 'string' && looksJwt(parsed.value))
        || (typeof parsed?.accessToken === 'string' && looksJwt(parsed.accessToken))
        || (typeof parsed?.token === 'string' && looksJwt(parsed.token));
      const hit = isJwt || KEYWORDS.test(key);
      if (hit) out.push({ store: name, key, jwt: isJwt, len: String(val).length, sample: String(val).slice(0, 60), decoded: isJwt ? decode(String(raw).trim()) : null });
    }
    return out;
  };

  const cookies = document.cookie ? document.cookie.split('; ').map(c => {
    const idx = c.indexOf('='); const k = c.slice(0, idx); const v = c.slice(idx + 1);
    return { store: 'cookie', key: k, jwt: looksJwt(v), len: v.length, sample: v.slice(0, 60), decoded: looksJwt(v) ? decode(v) : null };
  }).filter(x => x.jwt || KEYWORDS.test(x.key)) : [];

  const found = [...dumpStore('localStorage', localStorage), ...dumpStore('sessionStorage', sessionStorage), ...cookies];

  console.log('%c=== Разведчик авторизации vverh-app.er.ru ===', 'font-weight:bold;font-size:14px');
  console.log(`URL: ${location.href}`);
  console.table(found.map(f => ({ хранилище: f.store, ключ: f.key, JWT: f.jwt ? 'да' : '', длина: f.len, начало: f.sample })));

  if (!found.length) {
    console.warn('Ничего похожего на токен не найдено. Возможно, авторизация по httpOnly-cookie (её не видно из JS) или site использует IndexedDB. Напиши — добавлю проверку IndexedDB.');
  } else {
    console.info('Подсказка: самый вероятный ключ для переключения —', found.find(f => f.jwt)?.key || found[0].key);
    window.__probeResult = found; // забрать из консоли: __probeResult
  }
  return found;
})();